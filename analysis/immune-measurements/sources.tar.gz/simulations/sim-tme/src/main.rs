//! Tumor Microenvironment Simulation
//!
//! Models two TME features:
//! A) Oxygen gradients — hypoxia protects tumor core from ferroptosis
//! B) Spatial immune zones — DAMP release from ferroptotic cells triggers
//!    local immune activation (ICD-to-kill coupling)
//!
//! Biology (cross-referenced against textbooks in books/ directory):
//! - O2 → basal ROS via mitochondrial ETC (Biology2e Ch.7-8)
//! - O2 penetration ~100-150μm (Anatomy & Physiology 2e, Vaupel 1989)
//! - DAMP release from ferroptotic cells triggers innate immunity
//!   (Biology2e Ch.42-43, Microbiology Ch.15-17, Krysko Nat Rev Cancer 2012)
//! - DC activation follows Michaelis-Menten kinetics (Chemistry2e Ch.12-14)
//! - Spatial immune model valid for resident T cell phase (0-48h);
//!   systemic lymph node priming (1-7 days) is NOT modeled
//!
//! Key finding: LP at death is ~10.0 for ALL treatments (threshold-locked),
//! so DAMP per dead cell is approximately equal. The immune differential
//! comes from kill DENSITY (SDT kills 88% = dense DAMP field) not DAMP
//! quality (which is similar across treatments). This is an honest finding
//! that corrects the initial hypothesis about ICD quality differences.
//!
//! Caveats:
//! - O2 modulates basal_ros only (conservative)
//! - SDT/PDT modeled as O2-independent (Type I mechanism, conservative)
//! - LP at death ~10.0 underestimates true DAMP quality differential by
//!   ~30-50% (biologically, SDT should drive LP to 15-20 post-threshold)
//! - DAMP clearance modeled as exponential decay (simplified)
//! - Immune kill is local/resident phase only (no systemic priming)
//!
//! Usage: `cargo run --release --bin sim-tme`

use std::fs;
use std::path::Path;

use rand::prelude::*;
use serde::Serialize;

use ferroptosis_core::biochem::{sim_cell_step, CellState};
use ferroptosis_core::cell::{norm, Treatment};
use ferroptosis_core::grid::{death_heatmap, depth_kill_curve, TumorGrid};
use ferroptosis_core::immune_spatial::{immune_kill_probability, DAMP_KILL_THRESHOLD};
use ferroptosis_core::io::{write_depth_curves_csv, write_heatmap_csv, write_json};
use ferroptosis_core::oxygen::o2_dependent_exo_factor;
use ferroptosis_core::params::{
    apply_param_overrides, param_overrides_from_env, Params, PhConfig, SpatialImmuneConfig,
    SpatialParams, StromalConfig,
};
use ferroptosis_core::ph::{iron_multiplier_from_ph, radial_ph_field_2d};
use ferroptosis_core::physics::local_ros_multiplier;
use ferroptosis_core::stromal::{stromal_adjacency_mask_2d, stromal_adjacent_kill_rate_2d};

const GRID_SIZE: usize = 500;
const CELL_SIZE_UM: f64 = 20.0;
const N_STEPS: u32 = 180;

/// Master RNG seed. Historically a hard-coded `42` with no replicate loop
/// anywhere, so every reported number in this engine is a SINGLE draw and the
/// manuscript quotes point estimates with no dispersion. Several headline
/// quantities rest on small event counts (the immune-coupling ratio has a
/// denominator of five simulated events), where one draw says very little.
///
/// `FERRO_SEED` overrides it so `scripts/seed_replication.py` can run the same
/// matrix across many seeds and report medians with bootstrap intervals.
/// Unset ⇒ 42 ⇒ byte-identical to every committed number and to the #253
/// production regression hash.
static SEED: std::sync::LazyLock<u64> =
    std::sync::LazyLock::new(|| match std::env::var("FERRO_SEED") {
        Ok(raw) => match raw.trim().parse::<u64>() {
            Ok(v) => {
                eprintln!("FERRO_SEED={v}: replicate run, NOT the committed baseline");
                v
            }
            Err(_) => {
                eprintln!("error: FERRO_SEED must be a u64, got {raw:?}");
                std::process::exit(2);
            }
        },
        Err(_) => 42,
    });

/// Largest grid (`n_cells = GRID_SIZE²`) for which the per-cell additive RNG seed
/// streams stay collision-free (#585). The per-cell seed is
/// `seed + offset + idx + step*stride` (biochem stride 1e6, immune 2e6) alongside
/// the init stream `seed + idx`; the FIRST aliasing onset is the init stream
/// colliding with the biochem step-0 stream once `idx` reaches 500_000 (grid >
/// 707). The production GRID_SIZE=500 (250 000 cells) is far below it, so the
/// reported numbers are uncorrupted — but this is the same latent foot-gun #578
/// fixed in sim-tme-3d (SplitMix64 hash mix). The compile-time assert below makes
/// a future GRID_SIZE bump past the threshold fail at BUILD time instead of
/// silently aliasing per-cell draws. The real fix (porting the hash mix) changes
/// this engine's output and so needs a maintainer-approved 2D manuscript
/// re-baseline; that is tracked in #585.
const SEED_ALIAS_FREE_MAX_CELLS: u64 = 500_000;
const _: () = assert!(
    (GRID_SIZE as u64) * (GRID_SIZE as u64) < SEED_ALIAS_FREE_MAX_CELLS,
    "GRID_SIZE too large: the additive per-cell RNG seed streams alias above ~500k \
     cells (#585) — keep GRID_SIZE < 708, or port the sim-tme-3d SplitMix64 seed \
     (#578) and re-baseline the 2D manuscript outputs."
);

/// O2 penetration lengths to sweep (μm).
/// Literature range: 100-150μm (Vaupel, Cancer Res 1989).
const O2_LAMBDAS: &[f64] = &[80.0, 100.0, 120.0, 150.0];

/// Fixed reference λ for zone boundary definitions (μm).
/// Zone kill rates use this CONSTANT regardless of the sweep λ, so the
/// sensitivity table compares a fixed anatomical region across conditions.
const ZONE_REF_LAMBDA: f64 = 120.0;

// ============================================================
// O2 field computation
// ============================================================

/// Compute steady-state O2 concentration for each tumor cell based on
/// distance from the tumor edge. Stromal cells (outside tumor) are
/// well-oxygenated; O2 decays exponentially into the tumor interior.
///
/// O2(d) = exp(-d / λ) where d = distance from tumor edge in μm.
///
/// Modifies `cell.basal_ros` in place: `basal_ros *= o2_factor`. Depth
/// math is sourced from [`TumorGrid::radial_depth_um`] (#224 item 1a).
/// Returns a Vec of (row, col, o2_factor) for heatmap generation.
fn apply_o2_gradient(grid: &mut TumorGrid, penetration_um: f64) -> Vec<(usize, usize, f64)> {
    let rows = grid.rows;
    let cols = grid.cols;
    let mut o2_map = Vec::with_capacity(rows * cols);

    for r in 0..rows {
        for c in 0..cols {
            let idx = r * cols + c;
            if !grid.cells[idx].is_tumor {
                o2_map.push((r, c, 1.0));
                continue;
            }
            let depth_from_edge_um = grid.radial_depth_um(r, c).max(0.0);
            let o2_factor = (-depth_from_edge_um / penetration_um).exp().clamp(0.0, 1.0);
            grid.cells[idx].cell.basal_ros *= o2_factor;
            o2_map.push((r, c, o2_factor));
        }
    }

    o2_map
}

// ============================================================
// O2 cycling helpers
// ============================================================

/// Precompute per-cell depth from tumor edge (micrometers) — non-tumor
/// cells get `0.0` (sentinel). The depth math is lifted to
/// [`TumorGrid::radial_depth_um`] (#224 item 1a); this wrapper just
/// applies sim-tme's `.max(0.0)` + non-tumor-zero convention.
///
/// **Sentinel note:** the `0.0` for non-tumor cells differs from the
/// signed depth `radial_depth_um` returns for those positions (which
/// is negative). Current consumers (`run_spatial_cycling`) gate on
/// `is_tumor` before reading `depths[idx]`, so the sentinel is
/// unobservable; a future consumer that iterates the full map should
/// be aware the value is `0`, not the signed off-grid depth.
fn compute_depth_map(grid: &TumorGrid) -> Vec<f64> {
    let cols = grid.cols;
    (0..grid.cells.len())
        .map(|idx| {
            if !grid.cells[idx].is_tumor {
                return 0.0;
            }
            let (r, c) = (idx / cols, idx % cols);
            grid.radial_depth_um(r, c).max(0.0)
        })
        .collect()
}

/// Square-wave O2 cycling: λ alternates between low (hypoxic) and
/// high (normoxic) on a fixed period. First half = normoxic, second half = hypoxic.
fn cycling_lambda(step: u32, period: u32, lambda_low: f64, lambda_high: f64) -> f64 {
    if (step % period) < period / 2 {
        lambda_high
    } else {
        lambda_low
    }
}

// ============================================================
// Spatial simulation (reuses sim-spatial's pattern)
// ============================================================

fn run_spatial(
    grid: &mut TumorGrid,
    tx: Treatment,
    params: &Params,
    spatial_params: &SpatialParams,
    seed: u64,
    // #358: per-cell O2 supply factor (`exp(-depth/λ)`, from `apply_o2_gradient`)
    // and the O2-dependence knob. `None` (uniform) or `sdt_o2_dependence == 0.0`
    // (the default) ⇒ the exo-ROS factor is exactly `1.0` ⇒ byte-identical to the
    // pre-#358 output. `> 0` makes a Type II fraction of the SDT/PDT exo-ROS scale
    // with local O2, so SDT loses efficacy in the hypoxic core (SONALA-001-like).
    o2_supply: Option<&[f64]>,
    sdt_o2_dependence: f64,
) {
    let base_ros = match tx {
        Treatment::SDT => params.sdt_ros,
        Treatment::PDT => params.pdt_ros,
        Treatment::RSL3 | Treatment::Control => 0.0,
        // Radiation is not wired into this binary's treatment array (#726
        // lands the engine layer only), so this arm is unreachable today. It
        // is 0.0 rather than a dose because radiation's exogenous ROS is
        // dose-driven and uncalibrated: `RadiationConfig::ros_per_gy` is the
        // knob, and wiring it here means re-running this binary's committed
        // matrix, which is its own change.
        Treatment::Radiation => 0.0,
        // Not wired into this binary. `sim-modality-panel` is the one that
        // runs these arms; here they would silently behave as Control, which
        // is why the arm is explicit rather than a `_ =>` catch-all -- a
        // wildcard would have absorbed every future variant too.
        Treatment::Immunotherapy
        | Treatment::AdoptiveCell
        | Treatment::OncolyticVirus
        | Treatment::Ablation
        | Treatment::AntibodyDrugConjugate
        | Treatment::Chemotherapy => 0.0,
    };

    let rows = grid.rows;
    let cols = grid.cols;
    let cell_size = grid.cell_size_um;

    // Initialize cell states with depth-dependent ROS
    for r in 0..rows {
        let ros_multiplier = local_ros_multiplier(r, cell_size, tx, spatial_params);
        for c in 0..cols {
            let exo_ros_peak = if tx == Treatment::Control || tx == Treatment::RSL3 {
                0.0
            } else {
                let mut rng = StdRng::seed_from_u64(seed.wrapping_add((r * cols + c) as u64));
                let peak = base_ros * ros_multiplier;
                let sampled = norm(&mut rng, peak, peak * 0.2).max(0.0);
                // #358: O2-dependent (Type II) attenuation of the exo-ROS yield.
                // `factor == 1.0` when O2-independent (default `dep == 0`) or no
                // supply field is supplied, so the sampled value is unchanged and
                // the RNG stream is untouched ⇒ byte-identical.
                let idx = r * cols + c;
                let factor =
                    o2_supply.map_or(1.0, |s| o2_dependent_exo_factor(s[idx], sdt_o2_dependence));
                sampled * factor
            };

            let gc = grid.get_mut(r, c);
            gc.state = CellState::from_cell_with_ros(&gc.cell, tx, params, exo_ros_peak);
            gc.extra_iron = 0.0;
            gc.newly_dead = false;
            // Init to NaN so any code path that reads `lp_at_grace_end` before
            // writing it (the grace-end write or the end-of-sim catch-all)
            // produces NaN downstream — calibration will trip instead of
            // silently using a stale value (#225 review).
            gc.lp_at_grace_end = f64::NAN;
        }
    }

    // 180-step loop with interleaved iron diffusion
    for step in 0..N_STEPS {
        for r in 0..rows {
            for c in 0..cols {
                let idx = r * cols + c;
                if !grid.cells[idx].is_tumor {
                    continue;
                }
                if grid.cells[idx].state.dead {
                    if let Some(ds) = grid.cells[idx].state.death_step {
                        if step >= ds + params.post_death_steps {
                            continue;
                        }
                    } else {
                        continue;
                    }
                }

                let mut rng = StdRng::seed_from_u64(
                    seed.wrapping_add(500_000)
                        .wrapping_add(idx as u64)
                        .wrapping_add(step as u64 * 1_000_000),
                );

                let extra_iron = grid.cells[idx].extra_iron;
                grid.cells[idx].extra_iron = 0.0;

                let gc = &mut grid.cells[idx];
                let died =
                    sim_cell_step(&mut gc.state, &gc.cell, params, step, extra_iron, &mut rng);

                if died {
                    gc.newly_dead = true;
                    gc.lp_at_grace_end = gc.state.lp;
                }
                // Update lp_at_grace_end during grace period
                if gc.state.dead {
                    gc.lp_at_grace_end = gc.state.lp;
                }
            }
        }

        grid.diffuse_iron(
            spatial_params.iron_release_per_death,
            spatial_params.neighbor_iron_fraction,
        );
    }
}

/// Run spatial simulation with per-step O2 cycling (square-wave).
///
/// `depths` and `original_ros` are precomputed from the grid before
/// any O2 modification. Each step, basal_ros is recomputed using the
/// cycling lambda for the current phase.
#[allow(clippy::too_many_arguments)]
fn run_spatial_cycling(
    grid: &mut TumorGrid,
    tx: Treatment,
    params: &Params,
    spatial_params: &SpatialParams,
    seed: u64,
    depths: &[f64],
    original_ros: &[f64],
    period: u32,
    lambda_low: f64,
    lambda_high: f64,
    // #358: O2-dependent SDT/PDT exo-ROS knob. The exo envelope is set once at
    // init, so it is attenuated by the normoxic-phase (λ_high) O2 supply; `0.0`
    // (default) ⇒ factor 1.0 ⇒ byte-identical.
    sdt_o2_dependence: f64,
) {
    let base_ros = match tx {
        Treatment::SDT => params.sdt_ros,
        Treatment::PDT => params.pdt_ros,
        Treatment::RSL3 | Treatment::Control => 0.0,
        // Radiation is not wired into this binary's treatment array (#726
        // lands the engine layer only), so this arm is unreachable today. It
        // is 0.0 rather than a dose because radiation's exogenous ROS is
        // dose-driven and uncalibrated: `RadiationConfig::ros_per_gy` is the
        // knob, and wiring it here means re-running this binary's committed
        // matrix, which is its own change.
        Treatment::Radiation => 0.0,
        // Not wired into this binary. `sim-modality-panel` is the one that
        // runs these arms; here they would silently behave as Control, which
        // is why the arm is explicit rather than a `_ =>` catch-all -- a
        // wildcard would have absorbed every future variant too.
        Treatment::Immunotherapy
        | Treatment::AdoptiveCell
        | Treatment::OncolyticVirus
        | Treatment::Ablation
        | Treatment::AntibodyDrugConjugate
        | Treatment::Chemotherapy => 0.0,
    };

    let rows = grid.rows;
    let cols = grid.cols;
    let cell_size = grid.cell_size_um;

    // Initialize cell states with depth-dependent ROS (use lambda_high for initial state)
    for r in 0..rows {
        let ros_multiplier = local_ros_multiplier(r, cell_size, tx, spatial_params);
        for c in 0..cols {
            let idx = r * cols + c;
            // Initial (normoxic-phase, λ_high) O2 supply at this depth: drives the
            // basal_ros init below and (#358) the O2-dependent exo-ROS attenuation.
            let o2_factor = (-depths[idx] / lambda_high).exp().clamp(0.0, 1.0);
            let exo_ros_peak = if tx == Treatment::Control || tx == Treatment::RSL3 {
                0.0
            } else {
                let mut rng = StdRng::seed_from_u64(seed.wrapping_add((r * cols + c) as u64));
                let peak = base_ros * ros_multiplier;
                let sampled = norm(&mut rng, peak, peak * 0.2).max(0.0);
                // `factor == 1.0` when off ⇒ byte-identical.
                sampled * o2_dependent_exo_factor(o2_factor, sdt_o2_dependence)
            };

            // Set initial basal_ros from the normoxic phase
            grid.cells[idx].cell.basal_ros = original_ros[idx] * o2_factor;

            let gc = grid.get_mut(r, c);
            gc.state = CellState::from_cell_with_ros(&gc.cell, tx, params, exo_ros_peak);
            gc.extra_iron = 0.0;
            gc.newly_dead = false;
            // Init to NaN so any code path that reads `lp_at_grace_end` before
            // writing it (the grace-end write or the end-of-sim catch-all)
            // produces NaN downstream — calibration will trip instead of
            // silently using a stale value (#225 review).
            gc.lp_at_grace_end = f64::NAN;
        }
    }

    // 180-step loop with per-step O2 cycling
    for step in 0..N_STEPS {
        // Update O2 field for this step's cycle phase
        let lambda = cycling_lambda(step, period, lambda_low, lambda_high);
        for idx in 0..grid.cells.len() {
            if grid.cells[idx].is_tumor && !grid.cells[idx].state.dead {
                let o2_factor = (-depths[idx] / lambda).exp().clamp(0.0, 1.0);
                grid.cells[idx].cell.basal_ros = original_ros[idx] * o2_factor;
            }
        }

        for r in 0..rows {
            for c in 0..cols {
                let idx = r * cols + c;
                if !grid.cells[idx].is_tumor {
                    continue;
                }
                if grid.cells[idx].state.dead {
                    if let Some(ds) = grid.cells[idx].state.death_step {
                        if step >= ds + params.post_death_steps {
                            continue;
                        }
                    } else {
                        continue;
                    }
                }

                let mut rng = StdRng::seed_from_u64(
                    seed.wrapping_add(500_000)
                        .wrapping_add(idx as u64)
                        .wrapping_add(step as u64 * 1_000_000),
                );

                let extra_iron = grid.cells[idx].extra_iron;
                grid.cells[idx].extra_iron = 0.0;

                let gc = &mut grid.cells[idx];
                let died =
                    sim_cell_step(&mut gc.state, &gc.cell, params, step, extra_iron, &mut rng);

                if died {
                    gc.newly_dead = true;
                    gc.lp_at_grace_end = gc.state.lp;
                }
                if gc.state.dead {
                    gc.lp_at_grace_end = gc.state.lp;
                }
            }
        }

        grid.diffuse_iron(
            spatial_params.iron_release_per_death,
            spatial_params.neighbor_iron_fraction,
        );
    }
}

// ============================================================
// Spatial immune coupling (Feature B)
// ============================================================
//
// `SpatialImmuneConfig` lifted to `ferroptosis-core::params` (#220).
// Use `SpatialImmuneConfig::for_2d()` for 2D defaults
// (damp_diffusion_fraction = 0.08, < 1/8 stability bound for the
// 8-Moore neighborhood returned by `TumorGrid::neighbors`).

// ============================================================
// Stromal protection (Feature C)
// ============================================================
//
// `StromalConfig` lifted to `ferroptosis-core::params` (#220).
// `stromal_adjacency_mask` + `stromal_adjacent_kill_rate` lifted to
// `ferroptosis-core::stromal::{stromal_adjacency_mask_2d,
// stromal_adjacent_kill_rate_2d}` (#224 item 1c). Call sites use the
// library names directly.

// ============================================================
// pH gradient and ion trapping (Feature D)
// ============================================================
//
// `PhConfig` lifted to `ferroptosis-core::params` (#220).
// Geometry-independent (same chemistry in 2D and 3D, see PR #221 Q4).

/// Compute steady-state pH field and apply iron modulation. pH math
/// is lifted to [`radial_ph_field_2d`] + [`iron_multiplier_from_ph`]
/// (#224 item 1b); this function is the binary-side orchestrator:
/// it threads the library output through sim-tme's iron mutation and
/// returns the (row, col, local_ph) heatmap consumers expect.
///
/// **Why the `is_tumor` gate on the iron mutation is retained even
/// though `iron_multiplier_from_ph(ph_edge, ph_edge, _) == 1.0`:**
/// the no-op identity holds for finite, well-behaved
/// `iron_ph_sensitivity`, but a pathological `+∞` would make the
/// multiplier `NaN` at non-tumor cells (`1.0 + ∞·0 = NaN`); the gate
/// also documents the original behavior unambiguously.
fn apply_ph_gradient(grid: &mut TumorGrid, cfg: &PhConfig) -> Vec<(usize, usize, f64)> {
    let cols = grid.cols;
    let ph_field = radial_ph_field_2d(grid, cfg.ph_edge, cfg.ph_core, cfg.lambda_ph_um);

    let mut ph_map = Vec::with_capacity(grid.cells.len());
    for (idx, &local_ph) in ph_field.iter().enumerate() {
        let (r, c) = (idx / cols, idx % cols);
        ph_map.push((r, c, local_ph));
        // Iron modulation: ferritin destabilization at low pH. Library
        // `iron_multiplier_from_ph` is `1.0 + sensitivity * (ph_edge - local_ph)`
        // — at local_ph = ph_edge (non-tumor cells) it's exactly 1.0, so
        // the multiply is a no-op there; the explicit is_tumor gate
        // preserves the previous behavior (skip the write on non-tumor
        // cells) without changing the numeric result.
        if grid.cells[idx].is_tumor {
            let mult = iron_multiplier_from_ph(local_ph, cfg.ph_edge, cfg.iron_ph_sensitivity);
            grid.cells[idx].cell.iron *= mult;
        }
    }
    ph_map
}

/// Run spatial sim WITH immune coupling: DAMP diffusion + immune kill.
/// Optionally applies CAF-mediated stromal protection and pH ion trapping.
/// Returns (ferroptosis_kills, immune_kills, final_damp_field).
#[allow(clippy::too_many_arguments)]
fn run_spatial_with_immune(
    grid: &mut TumorGrid,
    tx: Treatment,
    params: &Params,
    spatial_params: &SpatialParams,
    immune: &SpatialImmuneConfig,
    stromal: Option<(&[bool], &StromalConfig)>,
    ph: Option<(&[(usize, usize, f64)], &PhConfig)>,
    seed: u64,
    // #358: same O2-dependent SDT/PDT exo-ROS knob as `run_spatial`, so the
    // immune-on gradient rows stay consistent with the immune-off ones under
    // `--sdt-o2-dependence`. `None` / `0.0` ⇒ factor 1.0 ⇒ byte-identical.
    o2_supply: Option<&[f64]>,
    sdt_o2_dependence: f64,
) -> (usize, usize, Vec<f64>) {
    let base_ros = match tx {
        Treatment::SDT => params.sdt_ros,
        Treatment::PDT => params.pdt_ros,
        Treatment::RSL3 | Treatment::Control => 0.0,
        // Radiation is not wired into this binary's treatment array (#726
        // lands the engine layer only), so this arm is unreachable today. It
        // is 0.0 rather than a dose because radiation's exogenous ROS is
        // dose-driven and uncalibrated: `RadiationConfig::ros_per_gy` is the
        // knob, and wiring it here means re-running this binary's committed
        // matrix, which is its own change.
        Treatment::Radiation => 0.0,
        // Not wired into this binary. `sim-modality-panel` is the one that
        // runs these arms; here they would silently behave as Control, which
        // is why the arm is explicit rather than a `_ =>` catch-all -- a
        // wildcard would have absorbed every future variant too.
        Treatment::Immunotherapy
        | Treatment::AdoptiveCell
        | Treatment::OncolyticVirus
        | Treatment::Ablation
        | Treatment::AntibodyDrugConjugate
        | Treatment::Chemotherapy => 0.0,
    };

    let rows = grid.rows;
    let cols = grid.cols;
    let cell_size = grid.cell_size_um;
    let n_cells = rows * cols;

    // Initialize cell states
    for r in 0..rows {
        let ros_multiplier = local_ros_multiplier(r, cell_size, tx, spatial_params);
        for c in 0..cols {
            let exo_ros_peak = if tx == Treatment::Control || tx == Treatment::RSL3 {
                0.0
            } else {
                let mut rng = StdRng::seed_from_u64(seed.wrapping_add((r * cols + c) as u64));
                let peak = base_ros * ros_multiplier;
                let sampled = norm(&mut rng, peak, peak * 0.2).max(0.0);
                // #358: O2-dependent (Type II) attenuation, identical to
                // `run_spatial`. `factor == 1.0` when off ⇒ byte-identical.
                let idx = r * cols + c;
                let factor =
                    o2_supply.map_or(1.0, |s| o2_dependent_exo_factor(s[idx], sdt_o2_dependence));
                sampled * factor
            };
            let gc = grid.get_mut(r, c);
            gc.state = CellState::from_cell_with_ros(&gc.cell, tx, params, exo_ros_peak);
            gc.extra_iron = 0.0;
            gc.newly_dead = false;
            // Init to NaN so any code path that reads `lp_at_grace_end` before
            // writing it (the grace-end write or the end-of-sim catch-all)
            // produces NaN downstream — calibration will trip instead of
            // silently using a stale value (#225 review).
            gc.lp_at_grace_end = f64::NAN;
        }
    }

    // pH-dependent RSL3 ion trapping: partially restore GPX4 for cells in
    // acidic zones. Drug availability decreases at low pH (Henderson-Hasselbalch,
    // Chemistry2e Sec.14.2), reducing effective GPX4 inhibition.
    if let Some((ph_map, ph_cfg)) = &ph {
        if tx == Treatment::RSL3 {
            for &(r, c, local_ph) in ph_map.iter() {
                let idx = r * cols + c;
                if !grid.cells[idx].is_tumor {
                    continue;
                }
                let drug_factor = (1.0 - ph_cfg.ion_trap_sensitivity * (ph_cfg.ph_edge - local_ph))
                    .clamp(0.3, 1.0);
                // Correct GPX4: from (1-inhib) to (1-inhib*drug_factor)
                let correction =
                    (1.0 - params.rsl3_gpx4_inhib * drug_factor) / (1.0 - params.rsl3_gpx4_inhib);
                grid.cells[idx].state.gpx4 *= correction;
            }
        } else if ph_cfg.sensitizer_ion_trap_sensitivity > 0.0
            && (tx == Treatment::SDT || tx == Treatment::PDT)
        {
            // #SENS-SYM: the SENSITIZER is a systemically dosed small molecule and
            // faces the same acidity barrier the pharmacologic drug does. The
            // ultrasound/light field is pH-independent; the molecule that converts
            // it into ROS is not. Historically this branch did not exist, so the
            // sensitizer sat at uniform concentration everywhere while RSL3 was
            // penalised -- and that asymmetry, not the biology, produced part of
            // the reported cross-modality resistance gap.
            for &(r, c, local_ph) in ph_map.iter() {
                let idx = r * cols + c;
                if !grid.cells[idx].is_tumor {
                    continue;
                }
                let availability = (1.0
                    - ph_cfg.sensitizer_ion_trap_sensitivity * (ph_cfg.ph_edge - local_ph))
                    .clamp(0.3, 1.0);
                grid.cells[idx].state.exo_ros_peak *= availability;
            }
        }
    }

    // External DAMP field (not in GridCell — zero ferroptosis-core changes)
    let mut damp_field = vec![0.0_f64; n_cells];
    let mut damp_delta = vec![0.0_f64; n_cells]; // reused each step to avoid allocation churn
    let mut ferroptosis_kills = 0usize;
    let mut immune_kills = 0usize;
    let immune_start_step = 60_u32; // immune activation delay

    for step in 0..N_STEPS {
        // --- Ferroptosis biochemistry ---
        for r in 0..rows {
            for c in 0..cols {
                let idx = r * cols + c;
                if !grid.cells[idx].is_tumor {
                    continue;
                }
                if grid.cells[idx].state.dead {
                    // Post-death grace period: LP continues accumulating
                    if let Some(ds) = grid.cells[idx].state.death_step {
                        let grace_end = ds + params.post_death_steps;
                        if step == grace_end {
                            // Grace period just ended: release DAMP with accumulated LP
                            grid.cells[idx].lp_at_grace_end = grid.cells[idx].state.lp;
                            damp_field[idx] += grid.cells[idx].lp_at_grace_end * immune.damp_per_lp;
                        }
                        if step >= grace_end {
                            continue; // fully dead
                        }
                        // In grace period: fall through to sim_cell_step
                    } else {
                        continue;
                    }
                }

                let mut rng = StdRng::seed_from_u64(
                    seed.wrapping_add(500_000)
                        .wrapping_add(idx as u64)
                        .wrapping_add(step as u64 * 1_000_000),
                );

                let extra_iron = grid.cells[idx].extra_iron;
                grid.cells[idx].extra_iron = 0.0;

                let gc = &mut grid.cells[idx];
                let died =
                    sim_cell_step(&mut gc.state, &gc.cell, params, step, extra_iron, &mut rng);

                if died {
                    gc.newly_dead = true;
                    ferroptosis_kills += 1;
                    // DAMP release is deferred until the post-death grace
                    // period ends (emergent LP overshoot, issue #85). At
                    // that point `lp_at_grace_end` is set to the grace-end LP
                    // value just before being read for DAMP — see the
                    // grace-end block above. The moment-of-death write
                    // that used to live here was dead (always overwritten
                    // before read); removed in #220.
                    // Iron diffusion still happens immediately via newly_dead.
                }

                // CAF-mediated protection for alive cells only (not dead/grace period)
                if !died && !gc.state.dead {
                    if let Some((mask, cfg)) = &stromal {
                        if mask[idx] {
                            let gc = &mut grid.cells[idx];
                            gc.state.gsh =
                                (gc.state.gsh + cfg.gsh_boost_per_step).min(cfg.gsh_boost_cap);
                            gc.state.mufa_protection = (gc.state.mufa_protection
                                + cfg.mufa_boost_per_step)
                                .min(cfg.mufa_boost_cap);
                        }
                    }
                }
            }
        }

        // --- Iron diffusion ---
        grid.diffuse_iron(
            spatial_params.iron_release_per_death,
            spatial_params.neighbor_iron_fraction,
        );

        // --- DAMP diffusion (neighbor spread + clearance) ---
        damp_delta.fill(0.0);
        for r in 0..rows {
            for c in 0..cols {
                let idx = r * cols + c;
                let local = damp_field[idx];
                if local < 0.001 {
                    continue;
                }
                let share = local * immune.damp_diffusion_fraction;
                let (neighbors, count) = grid.neighbors(r, c);
                for &(nr, nc) in &neighbors[..count] {
                    damp_delta[nr * cols + nc] += share;
                }
                damp_delta[idx] -= share * count as f64;
            }
        }
        for i in 0..n_cells {
            damp_field[i] = (damp_field[i] + damp_delta[i]).max(0.0);
            // Clearance decay
            damp_field[i] *= 1.0 - immune.damp_clearance_rate;
        }

        // --- Immune kill (after delay) ---
        if step >= immune_start_step {
            let effective_brake = immune.effective_brake();
            for r in 0..rows {
                for c in 0..cols {
                    let idx = r * cols + c;
                    if grid.cells[idx].state.dead || !grid.cells[idx].is_tumor {
                        continue;
                    }

                    let local_damp = damp_field[idx];
                    if local_damp < DAMP_KILL_THRESHOLD {
                        continue;
                    }

                    // NaN-preserving cap (lifted via #220). Previously inline as
                    // `.min(0.99)`, which silently converted NaN inputs to 0.99
                    // — a near-certain kill probability. `immune_kill_probability`
                    // uses an explicit `if raw > 0.99` branch that preserves NaN.
                    let activation = local_damp / (local_damp + immune.dc_activation_kd);
                    let kill_prob = immune_kill_probability(
                        activation,
                        immune.immune_kill_rate,
                        effective_brake,
                    );

                    let mut rng = StdRng::seed_from_u64(
                        seed.wrapping_add(900_000_000)
                            .wrapping_add(idx as u64)
                            .wrapping_add(step as u64 * 2_000_000),
                    );
                    if rng.gen::<f64>() < kill_prob {
                        grid.cells[idx].state.dead = true;
                        immune_kills += 1;
                    }
                }
            }
        }
    }

    // Release DAMP for cells whose grace period extends past the simulation
    // (e.g., cells dying at step 176+ with 5 post-death steps).
    for idx in 0..n_cells {
        if grid.cells[idx].is_tumor && grid.cells[idx].state.dead {
            if let Some(ds) = grid.cells[idx].state.death_step {
                let grace_end = ds + params.post_death_steps;
                if grace_end >= N_STEPS {
                    // Grace period wasn't completed in the loop — release DAMP now
                    grid.cells[idx].lp_at_grace_end = grid.cells[idx].state.lp;
                    damp_field[idx] += grid.cells[idx].lp_at_grace_end * immune.damp_per_lp;
                }
            }
        }
    }

    (ferroptosis_kills, immune_kills, damp_field)
}

// ============================================================
// Output types
// ============================================================

/// Schema version for `tme_summary.json`. Bump when the output shape
/// changes; `scripts/generate_3d_comparison_table.py` cross-checks
/// this against `sim-tme-3d/summary.json`'s `schema_version` to catch
/// schema drift across the two binaries (#224 item 2).
const TME_SCHEMA_VERSION: u32 = 1;

/// Serialization-only view of `tme_summary.json`. Borrows the conditions
/// slice to avoid moving `all_results` out from under downstream uses
/// in the comparison-table block.
#[derive(Serialize)]
struct TmeSummary<'a> {
    /// Bumped when the shape of this JSON changes. Currently `1`.
    schema_version: u32,
    /// Per-condition results (the historical contents of this file —
    /// previously serialized as a bare array; envelope added in #224).
    conditions: &'a [ConditionResult],
}

#[derive(Serialize)]
struct ConditionResult {
    treatment: String,
    o2_condition: String,
    o2_lambda_um: Option<f64>,
    immune_mode: String,
    total_tumor: usize,
    total_dead: usize,
    ferroptosis_kills: Option<usize>,
    immune_kills: Option<usize>,
    overall_kill_rate: f64,
    normoxic_kill_rate: f64,
    transition_kill_rate: f64,
    hypoxic_kill_rate: f64,
    // lp_overshoot_multiplier removed — overshoot is now emergent from
    // ferroptosis-core post_death_steps (issue #85).
    /// Stromal protection mode: "off" or "stromal_on".
    #[serde(skip_serializing_if = "Option::is_none")]
    stromal_mode: Option<String>,
    /// Kill rate among stromal-adjacent tumor cells specifically.
    #[serde(skip_serializing_if = "Option::is_none")]
    stromal_adjacent_kill_rate: Option<f64>,
    /// Number of tumor cells receiving CAF protection.
    #[serde(skip_serializing_if = "Option::is_none")]
    stromal_adjacent_count: Option<usize>,
    /// CAF GSH boost rate per step (None when stromal is off).
    #[serde(skip_serializing_if = "Option::is_none")]
    stromal_gsh_boost: Option<f64>,
    /// CAF MUFA boost rate per step (None when stromal is off).
    #[serde(skip_serializing_if = "Option::is_none")]
    stromal_mufa_boost: Option<f64>,
    /// pH gradient mode: "off" or "ph_on".
    #[serde(skip_serializing_if = "Option::is_none")]
    ph_mode: Option<String>,
    /// pH iron sensitivity parameter (None when pH is off).
    #[serde(skip_serializing_if = "Option::is_none")]
    ph_iron_sensitivity: Option<f64>,
    /// pH ion trapping sensitivity (None when pH is off).
    #[serde(skip_serializing_if = "Option::is_none")]
    ph_ion_trap_sensitivity: Option<f64>,
    /// pH at tumor edge (None when pH is off).
    #[serde(skip_serializing_if = "Option::is_none")]
    ph_edge: Option<f64>,
    /// pH at tumor core (None when pH is off).
    #[serde(skip_serializing_if = "Option::is_none")]
    ph_core: Option<f64>,
    /// pH penetration length in μm (None when pH is off).
    #[serde(skip_serializing_if = "Option::is_none")]
    ph_lambda_um: Option<f64>,
}

/// Compute kill rates for three O2-defined zones:
/// - Normoxic shell: within `shell_depth_um` of tumor edge (O2 > 0.37)
/// - Transition zone: between shell and hypoxic core
/// - Hypoxic core: deeper than `3 * shell_depth_um` (O2 < 0.05)
///
/// Depth math is sourced from [`TumorGrid::radial_depth_um`] (#224 item 1a)
/// — the last call site in sim-tme that still inlined the `0.45` literal
/// before this commit.
///
/// Returns (normoxic_rate, transition_rate, hypoxic_rate).
fn zone_kill_rates(grid: &TumorGrid, shell_depth_um: f64) -> (f64, f64, f64) {
    let deep_threshold_um = shell_depth_um * 3.0;

    let (mut norm_dead, mut norm_total) = (0usize, 0usize);
    let (mut trans_dead, mut trans_total) = (0usize, 0usize);
    let (mut hyp_dead, mut hyp_total) = (0usize, 0usize);

    for r in 0..grid.rows {
        for c in 0..grid.cols {
            let gc = grid.get(r, c);
            if !gc.is_tumor {
                continue;
            }
            let depth_from_edge_um = grid.radial_depth_um(r, c).max(0.0);

            let (dead_count, total_count) = if depth_from_edge_um < shell_depth_um {
                (&mut norm_dead, &mut norm_total)
            } else if depth_from_edge_um < deep_threshold_um {
                (&mut trans_dead, &mut trans_total)
            } else {
                (&mut hyp_dead, &mut hyp_total)
            };

            *total_count += 1;
            if gc.state.dead {
                *dead_count += 1;
            }
        }
    }

    let rate = |d: usize, t: usize| if t > 0 { d as f64 / t as f64 } else { 0.0 };
    (
        rate(norm_dead, norm_total),
        rate(trans_dead, trans_total),
        rate(hyp_dead, hyp_total),
    )
}

// ============================================================
// Main
// ============================================================

fn main() {
    eprintln!("=== Tumor Microenvironment: Oxygen Gradients ===");
    eprintln!(
        "Grid: {}×{} ({:.1}mm × {:.1}mm)",
        GRID_SIZE,
        GRID_SIZE,
        GRID_SIZE as f64 * CELL_SIZE_UM / 1000.0,
        GRID_SIZE as f64 * CELL_SIZE_UM / 1000.0,
    );
    eprintln!("O2 penetration sweep: {:?} μm", O2_LAMBDAS);
    eprintln!("Caveats: O2 modulates basal_ros only (not Fenton/SDT); steady-state field\n");

    // Biochem parameter overrides (#331): a global-sensitivity / calibration
    // driver can perturb the biochemical rate constants via the
    // `FERRO_PARAM_OVERRIDES` env var (inline JSON or a file path) WITHOUT
    // recompiling. Unset ⇒ no overrides ⇒ byte-identical to the historical run.
    let mut params = Params::default();
    match param_overrides_from_env() {
        Ok(overrides) => {
            if !overrides.is_empty() {
                eprintln!(
                    "Applying {} biochem override(s) from FERRO_PARAM_OVERRIDES",
                    overrides.len()
                );
            }
            if let Err(name) = apply_param_overrides(&mut params, overrides) {
                eprintln!("error: FERRO_PARAM_OVERRIDES contains unknown parameter '{name}'");
                std::process::exit(2);
            }
        }
        Err(e) => {
            eprintln!("error: {e}");
            std::process::exit(2);
        }
    }
    let spatial_params = SpatialParams {
        cell_size_um: CELL_SIZE_UM,
        ..Default::default()
    };

    // #358: opt-in O2-dependent (Type II) SDT/PDT exo-ROS. `--sdt-o2-dependence
    // <f>` (default `0.0`) makes a fraction of the exogenous ROS yield scale with
    // local O2 in ALL gradient + O2-cycling conditions (immune-off, immune-on,
    // anti-PD-1, stromal, pH, and cycling; the uniform baseline has no gradient
    // so it is unaffected), so SDT loses efficacy in the hypoxic core (the
    // contested §7.1 leg). `0.0` reproduces the pre-#358 output exactly (the
    // committed `tme_summary.json` / figure fixture), so the default matrix stays
    // byte-identical; run with `--sdt-o2-dependence 1.0` to compute the
    // O2-dependent bound reported alongside the O2-independent one in §7.1.
    let cli_args: Vec<String> = std::env::args().collect();
    let o2dep_token_present = cli_args
        .iter()
        .any(|a| a == "--sdt-o2-dependence" || a.starts_with("--sdt-o2-dependence="));
    let o2dep_parsed: Option<f64> = cli_args
        .windows(2)
        .find(|w| w[0] == "--sdt-o2-dependence")
        .and_then(|w| w[1].parse::<f64>().ok())
        .or_else(|| {
            cli_args
                .iter()
                .find_map(|a| a.strip_prefix("--sdt-o2-dependence="))
                .and_then(|v| v.parse::<f64>().ok())
        });
    // Reject non-finite (NaN/inf would survive `clamp` and propagate into the
    // exo-ROS factor); warn if the flag was given but unusable.
    if o2dep_token_present && o2dep_parsed.map_or(true, |v| !v.is_finite()) {
        eprintln!(
            "WARNING: --sdt-o2-dependence present but value missing/unparseable/non-finite; \
             falling back to 0.0 (O2-independent, byte-identical default)."
        );
    }
    let sdt_o2_dependence: f64 = o2dep_parsed
        .filter(|v| v.is_finite())
        .unwrap_or(0.0)
        .clamp(0.0, 1.0);
    if sdt_o2_dependence > 0.0 {
        eprintln!(
            "O2-dependent SDT/PDT exo-ROS ENABLED (dependence={sdt_o2_dependence:.2}); \
             output is the O2-dependent bound, NOT the committed default."
        );
    }

    let treatments = [
        (Treatment::Control, "Control"),
        (Treatment::RSL3, "RSL3"),
        (Treatment::SDT, "SDT"),
    ];

    let output_dir = Path::new("output/tme");
    fs::create_dir_all(output_dir).expect("Failed to create output directory");

    // Remove stale legacy files from previous naming convention (_immune.csv → _immune_run.csv)
    for name in &[
        "death_control_immune.csv",
        "death_rsl3_immune.csv",
        "death_sdt_immune.csv",
    ] {
        let p = output_dir.join(name);
        if p.exists() {
            let _ = fs::remove_file(&p);
        }
    }

    let mut all_results: Vec<ConditionResult> = Vec::new();
    let mut all_depth_curves: Vec<(String, Vec<(f64, f64, usize)>)> = Vec::new();

    // --- Baseline: uniform O2 (no gradient) ---
    eprintln!("=== Baseline (uniform O2) ===\n");
    for (tx, tx_name) in &treatments {
        let mut grid = TumorGrid::generate(GRID_SIZE, GRID_SIZE, CELL_SIZE_UM, *SEED);
        // Uniform O2: no supply field, so the O2-dependence knob is inert here
        // (a uniform field would be all-1.0 ⇒ factor 1.0 anyway).
        run_spatial(
            &mut grid,
            *tx,
            &params,
            &spatial_params,
            SEED.wrapping_add((*tx as u64) * 10_000_000),
            None,
            sdt_o2_dependence,
        );

        let census = grid.census();
        let overall = census.total_dead as f64 / census.total_tumor.max(1) as f64;
        let (norm_r, trans_r, hyp_r) = zone_kill_rates(&grid, ZONE_REF_LAMBDA);
        eprintln!(
            "  {}: overall={:.1}%, normoxic={:.1}%, transition={:.1}%, hypoxic={:.1}%",
            tx_name,
            overall * 100.0,
            norm_r * 100.0,
            trans_r * 100.0,
            hyp_r * 100.0
        );

        all_results.push(ConditionResult {
            treatment: tx_name.to_string(),
            o2_condition: "uniform".to_string(),
            o2_lambda_um: None,
            immune_mode: "off".to_string(),
            total_tumor: census.total_tumor,
            total_dead: census.total_dead,
            ferroptosis_kills: None,
            immune_kills: None,
            overall_kill_rate: overall,
            normoxic_kill_rate: norm_r,
            transition_kill_rate: trans_r,
            hypoxic_kill_rate: hyp_r,
            stromal_mode: None,
            stromal_adjacent_kill_rate: None,
            stromal_adjacent_count: None,
            stromal_gsh_boost: None,
            stromal_mufa_boost: None,
            ph_mode: None,
            ph_iron_sensitivity: None,
            ph_ion_trap_sensitivity: None,
            ph_edge: None,
            ph_core: None,
            ph_lambda_um: None,
        });

        let label = format!("{}_uniform", tx_name);
        all_depth_curves.push((label, depth_kill_curve(&grid)));

        let heatmap = death_heatmap(&grid);
        let path = output_dir.join(format!("death_{}_uniform.csv", tx_name.to_lowercase()));
        write_heatmap_csv(&path, &heatmap).expect("Failed to write heatmap");
    }

    // --- O2 gradient conditions ---
    for &lambda in O2_LAMBDAS {
        eprintln!("\n=== O2 gradient (λ = {} μm) ===\n", lambda);

        for (tx, tx_name) in &treatments {
            let mut grid = TumorGrid::generate(GRID_SIZE, GRID_SIZE, CELL_SIZE_UM, *SEED);

            // Apply O2 gradient BEFORE simulation (modifies cell.basal_ros)
            let o2_map = apply_o2_gradient(&mut grid, lambda);
            // #358: the same per-cell O2 supply (`exp(-depth/λ)`) that attenuates
            // basal_ros, flattened in idx order, so `run_spatial` can optionally
            // attenuate the SDT/PDT exo-ROS by it (O2-dependent / Type II SDT).
            // Inert when `sdt_o2_dependence == 0.0` (the byte-identical default).
            let o2_supply: Vec<f64> = o2_map.iter().map(|&(_, _, f)| f).collect();

            run_spatial(
                &mut grid,
                *tx,
                &params,
                &spatial_params,
                SEED.wrapping_add((*tx as u64) * 10_000_000),
                Some(&o2_supply),
                sdt_o2_dependence,
            );

            let census = grid.census();
            let overall = census.total_dead as f64 / census.total_tumor.max(1) as f64;
            let (norm_r, trans_r, hyp_r) = zone_kill_rates(&grid, ZONE_REF_LAMBDA);
            eprintln!(
                "  {}: overall={:.1}%, normoxic={:.1}%, transition={:.1}%, hypoxic={:.1}%",
                tx_name,
                overall * 100.0,
                norm_r * 100.0,
                trans_r * 100.0,
                hyp_r * 100.0
            );

            all_results.push(ConditionResult {
                treatment: tx_name.to_string(),
                o2_condition: format!("gradient_{}um", lambda as u64),
                o2_lambda_um: Some(lambda),
                immune_mode: "off".to_string(),
                total_tumor: census.total_tumor,
                total_dead: census.total_dead,
                ferroptosis_kills: None,
                immune_kills: None,
                overall_kill_rate: overall,
                normoxic_kill_rate: norm_r,
                transition_kill_rate: trans_r,
                hypoxic_kill_rate: hyp_r,
                stromal_mode: None,
                stromal_adjacent_kill_rate: None,
                stromal_adjacent_count: None,
                stromal_gsh_boost: None,
                stromal_mufa_boost: None,
                ph_mode: None,
                ph_iron_sensitivity: None,
                ph_ion_trap_sensitivity: None,
                ph_edge: None,
                ph_core: None,
                ph_lambda_um: None,
            });

            let label = format!("{}_{}", tx_name, lambda as u64);
            all_depth_curves.push((label, depth_kill_curve(&grid)));

            // Save heatmaps for the default lambda (120μm) only to avoid file bloat
            if (lambda - 120.0).abs() < 1.0 {
                let death_hm = death_heatmap(&grid);
                let path =
                    output_dir.join(format!("death_{}_o2gradient.csv", tx_name.to_lowercase()));
                write_heatmap_csv(&path, &death_hm).expect("Failed to write heatmap");

                // O2 heatmap
                let mut o2_hm = ndarray::Array2::<u8>::zeros((grid.rows, grid.cols));
                for &(r, c, o2) in &o2_map {
                    o2_hm[[r, c]] = (o2 * 255.0).round() as u8;
                }
                let path = output_dir.join("o2_field.csv");
                write_heatmap_csv(&path, &o2_hm).expect("Failed to write O2 heatmap");
            }
        }
    }

    // --- O2 cycling condition (square-wave, λ=80↔150μm, period=60 steps) ---
    {
        let cycle_period: u32 = 60;
        let lambda_low = 80.0_f64;
        let lambda_high = 150.0_f64;
        eprintln!(
            "\n=== O2 cycling (square-wave λ={}↔{}μm, period={} steps) ===\n",
            lambda_low as u64, lambda_high as u64, cycle_period
        );

        for (tx, tx_name) in &treatments {
            let mut grid = TumorGrid::generate(GRID_SIZE, GRID_SIZE, CELL_SIZE_UM, *SEED);
            let depths = compute_depth_map(&grid);
            let original_ros: Vec<f64> = grid.cells.iter().map(|gc| gc.cell.basal_ros).collect();

            run_spatial_cycling(
                &mut grid,
                *tx,
                &params,
                &spatial_params,
                SEED.wrapping_add((*tx as u64) * 10_000_000),
                &depths,
                &original_ros,
                cycle_period,
                lambda_low,
                lambda_high,
                sdt_o2_dependence,
            );

            let census = grid.census();
            let overall = census.total_dead as f64 / census.total_tumor.max(1) as f64;
            let (norm_r, trans_r, hyp_r) = zone_kill_rates(&grid, ZONE_REF_LAMBDA);
            eprintln!(
                "  {}: overall={:.1}%, normoxic={:.1}%, transition={:.1}%, hypoxic={:.1}%",
                tx_name,
                overall * 100.0,
                norm_r * 100.0,
                trans_r * 100.0,
                hyp_r * 100.0
            );

            all_results.push(ConditionResult {
                treatment: tx_name.to_string(),
                o2_condition: format!(
                    "cycling_{}_{}_p{}",
                    lambda_low as u64, lambda_high as u64, cycle_period
                ),
                o2_lambda_um: None,
                immune_mode: "off".to_string(),
                total_tumor: census.total_tumor,
                total_dead: census.total_dead,
                ferroptosis_kills: None,
                immune_kills: None,
                overall_kill_rate: overall,
                normoxic_kill_rate: norm_r,
                transition_kill_rate: trans_r,
                hypoxic_kill_rate: hyp_r,
                stromal_mode: None,
                stromal_adjacent_kill_rate: None,
                stromal_adjacent_count: None,
                stromal_gsh_boost: None,
                stromal_mufa_boost: None,
                ph_mode: None,
                ph_iron_sensitivity: None,
                ph_ion_trap_sensitivity: None,
                ph_edge: None,
                ph_core: None,
                ph_lambda_um: None,
            });

            all_depth_curves.push((
                format!("{}_{}", tx_name, "cycling"),
                depth_kill_curve(&grid),
            ));
        }
    }

    // --- Compute stromal adjacency mask (used by both Feature B and C) ---
    // Mask is grid-geometry-dependent, not treatment-dependent.
    let mask_grid = TumorGrid::generate(GRID_SIZE, GRID_SIZE, CELL_SIZE_UM, *SEED);
    let stromal_mask = stromal_adjacency_mask_2d(&mask_grid);
    let stromal_adj_count = stromal_mask.iter().filter(|&&b| b).count();

    // --- Immune coupling (Feature B) at λ=120μm ---
    let immune_modes: Vec<(&str, SpatialImmuneConfig)> = vec![
        ("immune_on", SpatialImmuneConfig::for_2d()),
        (
            "immune_anti_pd1",
            SpatialImmuneConfig::for_2d().with_anti_pd1(),
        ),
    ];

    eprintln!("\n=== Spatial Immune Coupling (O2 gradient λ=120μm) ===");
    eprintln!("NOTE: LP overshoot multiplier applied (SDT/PDT: 2.0×, RSL3/Control: 1.05×).");
    eprintln!("DAMP differential comes from both kill DENSITY and per-cell DAMP quality.");
    eprintln!("Immune model: resident T cell phase only (0-48h), not systemic.\n");

    for (immune_label, immune_cfg) in &immune_modes {
        eprintln!(
            "--- Immune mode: {} (brake={:.0}%) ---\n",
            immune_label,
            immune_cfg.effective_brake() * 100.0
        );

        for (tx, tx_name) in &treatments {
            let mut grid = TumorGrid::generate(GRID_SIZE, GRID_SIZE, CELL_SIZE_UM, *SEED);
            // #358: capture the per-cell O2 supply so the immune-on gradient
            // SDT exo-ROS gets the same O2-dependent attenuation as the
            // immune-off gradient conditions (consistent under the flag).
            let o2_supply: Vec<f64> = apply_o2_gradient(&mut grid, 120.0)
                .iter()
                .map(|&(_, _, f)| f)
                .collect();

            let (ferr_kills, imm_kills, final_damp) = run_spatial_with_immune(
                &mut grid,
                *tx,
                &params,
                &spatial_params,
                immune_cfg,
                None,
                None,
                SEED.wrapping_add((*tx as u64) * 10_000_000),
                Some(&o2_supply),
                sdt_o2_dependence,
            );

            let census = grid.census();
            let overall = census.total_dead as f64 / census.total_tumor.max(1) as f64;
            let (norm_r, trans_r, hyp_r) = zone_kill_rates(&grid, ZONE_REF_LAMBDA);
            let adj_rate_baseline = stromal_adjacent_kill_rate_2d(&grid, &stromal_mask);
            eprintln!(
                "  {}: overall={:.1}% (ferr={}, immune={}), hypoxic={:.1}%, stromal_adj={:.1}%",
                tx_name,
                overall * 100.0,
                ferr_kills,
                imm_kills,
                hyp_r * 100.0,
                adj_rate_baseline * 100.0
            );

            // Export DAMP and immune-kill heatmaps for the first immune mode only
            if *immune_label == "immune_on" {
                // DAMP concentration heatmap (scaled to u8 for CSV export)
                let damp_max = final_damp.iter().cloned().fold(0.0_f64, f64::max).max(1.0);
                let mut damp_hm = ndarray::Array2::<u8>::zeros((grid.rows, grid.cols));
                for r in 0..grid.rows {
                    for c in 0..grid.cols {
                        let val = final_damp[r * grid.cols + c] / damp_max;
                        damp_hm[[r, c]] = (val * 255.0).round() as u8;
                    }
                }
                let path = output_dir.join(format!("damp_field_{}.csv", tx_name.to_lowercase()));
                write_heatmap_csv(&path, &damp_hm).expect("Failed to write DAMP heatmap");

                // Final death map for the immune-enabled run (same encoding as other
                // death heatmaps: 0=stromal, 1=dead tumor, 2=alive tumor; does NOT
                // distinguish immune kills from ferroptotic kills)
                let death_hm = death_heatmap(&grid);
                let path =
                    output_dir.join(format!("death_{}_immune_run.csv", tx_name.to_lowercase()));
                write_heatmap_csv(&path, &death_hm).expect("Failed to write death heatmap");
            }

            all_results.push(ConditionResult {
                treatment: tx_name.to_string(),
                o2_condition: "gradient_120um".to_string(),
                o2_lambda_um: Some(120.0),
                immune_mode: immune_label.to_string(),
                total_tumor: census.total_tumor,
                total_dead: census.total_dead,
                ferroptosis_kills: Some(ferr_kills),
                immune_kills: Some(imm_kills),
                overall_kill_rate: overall,
                normoxic_kill_rate: norm_r,
                transition_kill_rate: trans_r,
                hypoxic_kill_rate: hyp_r,
                stromal_mode: Some("off".to_string()),
                stromal_adjacent_kill_rate: Some(adj_rate_baseline),
                stromal_adjacent_count: Some(stromal_adj_count),
                stromal_gsh_boost: None,
                stromal_mufa_boost: None,
                ph_mode: None,
                ph_iron_sensitivity: None,
                ph_ion_trap_sensitivity: None,
                ph_edge: None,
                ph_core: None,
                ph_lambda_um: None,
            });

            let label = format!("{}_120_{}", tx_name, immune_label);
            all_depth_curves.push((label, depth_kill_curve(&grid)));
        }
        eprintln!();
    }

    // --- Stromal protection (Feature C) at λ=120μm with immune_on ---
    let stromal_cfg = StromalConfig::default();

    eprintln!("\n=== Stromal Protection / CAF-Mediated Shielding (O2 gradient λ=120μm) ===");
    eprintln!(
        "Stromal-adjacent tumor cells: {} ({:.1}% of tumor)",
        stromal_adj_count,
        stromal_adj_count as f64 / mask_grid.census().total_tumor as f64 * 100.0
    );
    eprintln!(
        "CAF boost: GSH +{:.3}/step (cap {:.0}), MUFA +{:.4}/step (cap {:.2})",
        stromal_cfg.gsh_boost_per_step,
        stromal_cfg.gsh_boost_cap,
        stromal_cfg.mufa_boost_per_step,
        stromal_cfg.mufa_boost_cap
    );
    eprintln!("All parameters ESTIMATED (no textbook coverage). Refs: PMID 34373744, 31813804.\n");

    let stromal_immune_modes: Vec<(&str, SpatialImmuneConfig)> = vec![
        ("immune_on", SpatialImmuneConfig::for_2d()),
        (
            "immune_anti_pd1",
            SpatialImmuneConfig::for_2d().with_anti_pd1(),
        ),
    ];

    for (immune_label, immune_cfg) in &stromal_immune_modes {
        eprintln!(
            "--- Stromal ON + {} (brake={:.0}%) ---\n",
            immune_label,
            immune_cfg.effective_brake() * 100.0
        );

        for (tx, tx_name) in &treatments {
            let mut grid = TumorGrid::generate(GRID_SIZE, GRID_SIZE, CELL_SIZE_UM, *SEED);
            // #358: capture O2 supply for the consistent O2-dependent SDT path.
            let o2_supply: Vec<f64> = apply_o2_gradient(&mut grid, 120.0)
                .iter()
                .map(|&(_, _, f)| f)
                .collect();

            let (ferr_kills, imm_kills, _final_damp) = run_spatial_with_immune(
                &mut grid,
                *tx,
                &params,
                &spatial_params,
                &immune_cfg,
                Some((&stromal_mask, &stromal_cfg)),
                None,
                SEED.wrapping_add((*tx as u64) * 10_000_000),
                Some(&o2_supply),
                sdt_o2_dependence,
            );

            let census = grid.census();
            let overall = census.total_dead as f64 / census.total_tumor.max(1) as f64;
            let (norm_r, trans_r, hyp_r) = zone_kill_rates(&grid, ZONE_REF_LAMBDA);
            let adj_rate = stromal_adjacent_kill_rate_2d(&grid, &stromal_mask);
            eprintln!("  {}: overall={:.1}% (ferr={}, immune={}), normoxic={:.1}%, hypoxic={:.1}%, stromal_adj={:.1}%",
                tx_name, overall * 100.0, ferr_kills, imm_kills,
                norm_r * 100.0, hyp_r * 100.0, adj_rate * 100.0);

            // Export death heatmap for stromal_on + immune_on
            if *immune_label == "immune_on" {
                let death_hm = death_heatmap(&grid);
                let path = output_dir.join(format!("death_{}_stromal.csv", tx_name.to_lowercase()));
                write_heatmap_csv(&path, &death_hm).expect("Failed to write stromal death heatmap");
            }

            all_results.push(ConditionResult {
                treatment: tx_name.to_string(),
                o2_condition: "gradient_120um".to_string(),
                o2_lambda_um: Some(120.0),
                immune_mode: immune_label.to_string(),
                total_tumor: census.total_tumor,
                total_dead: census.total_dead,
                ferroptosis_kills: Some(ferr_kills),
                immune_kills: Some(imm_kills),
                overall_kill_rate: overall,
                normoxic_kill_rate: norm_r,
                transition_kill_rate: trans_r,
                hypoxic_kill_rate: hyp_r,
                stromal_mode: Some("stromal_on".to_string()),
                stromal_adjacent_kill_rate: Some(adj_rate),
                stromal_adjacent_count: Some(stromal_adj_count),
                stromal_gsh_boost: Some(stromal_cfg.gsh_boost_per_step),
                stromal_mufa_boost: Some(stromal_cfg.mufa_boost_per_step),
                ph_mode: None,
                ph_iron_sensitivity: None,
                ph_ion_trap_sensitivity: None,
                ph_edge: None,
                ph_core: None,
                ph_lambda_um: None,
            });

            let label = format!("{}_120_{}_stromal", tx_name, immune_label);
            all_depth_curves.push((label, depth_kill_curve(&grid)));
        }
        eprintln!();
    }

    // Export stromal adjacency mask as heatmap (0=stromal, 1=adjacent tumor, 2=non-adjacent tumor)
    {
        let mut mask_hm = ndarray::Array2::<u8>::zeros((mask_grid.rows, mask_grid.cols));
        for r in 0..mask_grid.rows {
            for c in 0..mask_grid.cols {
                let idx = r * mask_grid.cols + c;
                if !mask_grid.cells[idx].is_tumor {
                    mask_hm[[r, c]] = 0;
                } else if stromal_mask[idx] {
                    mask_hm[[r, c]] = 1;
                } else {
                    mask_hm[[r, c]] = 2;
                }
            }
        }
        let path = output_dir.join("stromal_mask.csv");
        write_heatmap_csv(&path, &mask_hm).expect("Failed to write stromal mask");
    }

    // --- pH gradient (Feature D) at λ=120μm with immune_on ---
    // #SENS-SYM: `FERRO_SENSITIZER_ION_TRAP` gives the SDT/PDT sensitizer the same
    // acidity barrier RSL3 faces. Unset (or 0.0) reproduces the historical
    // asymmetric behaviour byte-identically; set it equal to
    // `ion_trap_sensitivity` (0.4) for the symmetric run.
    let mut ph_cfg = PhConfig::default();
    if let Ok(raw) = std::env::var("FERRO_SENSITIZER_ION_TRAP") {
        match raw.trim().parse::<f64>() {
            Ok(v) if (0.0..=1.0).contains(&v) => {
                ph_cfg.sensitizer_ion_trap_sensitivity = v;
                eprintln!(
                    "FERRO_SENSITIZER_ION_TRAP={v}: sensitizer faces the pH barrier \
                     (RSL3 ion_trap_sensitivity={})",
                    ph_cfg.ion_trap_sensitivity
                );
            }
            _ => {
                eprintln!(
                    "error: FERRO_SENSITIZER_ION_TRAP must be a number in [0,1], got {raw:?}"
                );
                std::process::exit(2);
            }
        }
    }
    let ph_cfg = ph_cfg;
    let immune_for_ph = SpatialImmuneConfig::for_2d();

    eprintln!("\n=== pH Gradient / Ion Trapping (O2 gradient λ=120μm, immune_on) ===");
    eprintln!(
        "pH range: {:.1} (edge) → {:.1} (core), λ_pH={:.0}μm",
        ph_cfg.ph_edge, ph_cfg.ph_core, ph_cfg.lambda_ph_um
    );
    eprintln!(
        "Iron sensitivity: {:.1} (→ {:.2}× at pH {:.1})",
        ph_cfg.iron_ph_sensitivity,
        1.0 + ph_cfg.iron_ph_sensitivity * (ph_cfg.ph_edge - ph_cfg.ph_core),
        ph_cfg.ph_core
    );
    eprintln!(
        "Ion trapping: {:.1} (→ {:.0}% drug loss at pH {:.1}, RSL3 only)",
        ph_cfg.ion_trap_sensitivity,
        ph_cfg.ion_trap_sensitivity * (ph_cfg.ph_edge - ph_cfg.ph_core) * 100.0,
        ph_cfg.ph_core
    );
    eprintln!("All parameters ESTIMATED. Henderson-Hasselbalch: Chemistry2e Sec.14.2.");
    eprintln!("Warburg effect, ferritin iron release: primary literature only.\n");

    for (tx, tx_name) in &treatments {
        let mut grid = TumorGrid::generate(GRID_SIZE, GRID_SIZE, CELL_SIZE_UM, *SEED);
        // #358: capture O2 supply for the consistent O2-dependent SDT path.
        let o2_supply: Vec<f64> = apply_o2_gradient(&mut grid, 120.0)
            .iter()
            .map(|&(_, _, f)| f)
            .collect();
        let ph_map = apply_ph_gradient(&mut grid, &ph_cfg);

        let (ferr_kills, imm_kills, _final_damp) = run_spatial_with_immune(
            &mut grid,
            *tx,
            &params,
            &spatial_params,
            &immune_for_ph,
            None,
            Some((&ph_map, &ph_cfg)),
            SEED.wrapping_add((*tx as u64) * 10_000_000),
            Some(&o2_supply),
            sdt_o2_dependence,
        );

        let census = grid.census();
        let overall = census.total_dead as f64 / census.total_tumor.max(1) as f64;
        let (norm_r, trans_r, hyp_r) = zone_kill_rates(&grid, ZONE_REF_LAMBDA);
        let adj_rate = stromal_adjacent_kill_rate_2d(&grid, &stromal_mask);
        eprintln!(
            "  {}: overall={:.1}% (ferr={}, immune={}), normoxic={:.1}%, hypoxic={:.1}%",
            tx_name,
            overall * 100.0,
            ferr_kills,
            imm_kills,
            norm_r * 100.0,
            hyp_r * 100.0
        );

        // Export death heatmap
        let death_hm = death_heatmap(&grid);
        let path = output_dir.join(format!("death_{}_ph.csv", tx_name.to_lowercase()));
        write_heatmap_csv(&path, &death_hm).expect("Failed to write pH death heatmap");

        all_results.push(ConditionResult {
            treatment: tx_name.to_string(),
            o2_condition: "gradient_120um".to_string(),
            o2_lambda_um: Some(120.0),
            immune_mode: "immune_on".to_string(),
            total_tumor: census.total_tumor,
            total_dead: census.total_dead,
            ferroptosis_kills: Some(ferr_kills),
            immune_kills: Some(imm_kills),
            overall_kill_rate: overall,
            normoxic_kill_rate: norm_r,
            transition_kill_rate: trans_r,
            hypoxic_kill_rate: hyp_r,
            stromal_mode: None,
            stromal_adjacent_kill_rate: Some(adj_rate),
            stromal_adjacent_count: Some(stromal_adj_count),
            stromal_gsh_boost: None,
            stromal_mufa_boost: None,
            ph_mode: Some("ph_on".to_string()),
            ph_iron_sensitivity: Some(ph_cfg.iron_ph_sensitivity),
            ph_ion_trap_sensitivity: Some(ph_cfg.ion_trap_sensitivity),
            ph_edge: Some(ph_cfg.ph_edge),
            ph_core: Some(ph_cfg.ph_core),
            ph_lambda_um: Some(ph_cfg.lambda_ph_um),
        });

        let label = format!("{}_120_immune_on_ph", tx_name);
        all_depth_curves.push((label, depth_kill_curve(&grid)));
    }
    eprintln!();

    // Export pH field heatmap
    {
        let mut ph_vis_grid = TumorGrid::generate(GRID_SIZE, GRID_SIZE, CELL_SIZE_UM, *SEED);
        let ph_map_vis = apply_ph_gradient(&mut ph_vis_grid, &ph_cfg);
        let mut ph_hm = ndarray::Array2::<u8>::zeros((GRID_SIZE, GRID_SIZE));
        for &(r, c, ph) in &ph_map_vis {
            // Map pH 6.5-7.4 to 0-255
            let normed =
                ((ph - ph_cfg.ph_core) / (ph_cfg.ph_edge - ph_cfg.ph_core)).clamp(0.0, 1.0);
            ph_hm[[r, c]] = (normed * 255.0).round() as u8;
        }
        let path = output_dir.join("ph_field.csv");
        write_heatmap_csv(&path, &ph_hm).expect("Failed to write pH heatmap");
    }

    // --- Write aggregated outputs ---
    let curves_path = output_dir.join("depth_kill_curves.csv");
    write_depth_curves_csv(&curves_path, &all_depth_curves).expect("Failed to write depth curves");

    let summary_path = output_dir.join("tme_summary.json");
    let summary = TmeSummary {
        schema_version: TME_SCHEMA_VERSION,
        conditions: &all_results,
    };
    write_json(&summary_path, &summary).expect("Failed to write summary");

    // --- Print comparison table ---
    eprintln!("\n=== Comparison Table ===\n");
    eprintln!(
        "{:<10} {:<20} {:<18} {:<12} {:<8} {:>10} {:>10} {:>10} {:>10}",
        "Treatment",
        "O2 Condition",
        "Immune",
        "Stromal",
        "pH",
        "Overall",
        "Normoxic",
        "Transit.",
        "Hypoxic"
    );
    eprintln!("{}", "-".repeat(120));
    for r in &all_results {
        let stromal_label = r.stromal_mode.as_deref().unwrap_or("off");
        let ph_label = r.ph_mode.as_deref().unwrap_or("off");
        eprintln!(
            "{:<10} {:<20} {:<18} {:<12} {:<8} {:>9.1}% {:>9.1}% {:>9.1}% {:>9.1}%",
            r.treatment,
            r.o2_condition,
            r.immune_mode,
            stromal_label,
            ph_label,
            r.overall_kill_rate * 100.0,
            r.normoxic_kill_rate * 100.0,
            r.transition_kill_rate * 100.0,
            r.hypoxic_kill_rate * 100.0,
        );
    }

    // --- Sensitivity check: is the SDT-vs-RSL3 differential robust? ---
    eprintln!("\n=== Sensitivity: SDT advantage over RSL3 in hypoxic zone ===\n");
    eprintln!(
        "{:<10} {:>15} {:>15} {:>15}",
        "λ (μm)", "RSL3 hypoxic", "SDT hypoxic", "SDT/RSL3 ratio"
    );
    eprintln!("{}", "-".repeat(57));
    for &lambda in O2_LAMBDAS {
        let cond = format!("gradient_{}um", lambda as u64);
        let rsl3_hyp = all_results
            .iter()
            .find(|r| r.treatment == "RSL3" && r.o2_condition == cond)
            .map(|r| r.hypoxic_kill_rate)
            .unwrap_or(0.0);
        let sdt_hyp = all_results
            .iter()
            .find(|r| r.treatment == "SDT" && r.o2_condition == cond)
            .map(|r| r.hypoxic_kill_rate)
            .unwrap_or(0.0);
        let ratio = if rsl3_hyp > 0.001 {
            sdt_hyp / rsl3_hyp
        } else {
            f64::INFINITY
        };
        eprintln!(
            "{:<10} {:>14.1}% {:>14.1}% {:>15.1}×",
            lambda,
            rsl3_hyp * 100.0,
            sdt_hyp * 100.0,
            ratio
        );
    }

    eprintln!("\nZone definitions (fixed at λ_ref = {ZONE_REF_LAMBDA}μm): normoxic = within {ZONE_REF_LAMBDA}μm of edge, transition = {ZONE_REF_LAMBDA}-{}μm, hypoxic = deeper than {}μm.", ZONE_REF_LAMBDA * 3.0, ZONE_REF_LAMBDA * 3.0);
    eprintln!("If SDT/RSL3 ratio is consistently >1 across all λ values,");
    eprintln!("the finding is robust: SDT maintains efficacy in hypoxia better than RSL3.");

    eprintln!("\nOutputs saved to {}/", output_dir.display());
}

#[cfg(test)]
mod tests {
    use super::*;

    /// #358: the O2-dependence knob. With `sdt_o2_dependence == 0.0` (the default
    /// feeding the committed §7.1 numbers) the SDT exo-ROS is unattenuated, so the
    /// result is identical whether or not a supply field is passed (the knob is
    /// inert, the byte-identity invariant). With `1.0` (full Type II) the exo-ROS
    /// scales with local O2, so the hypoxic-core SDT kill collapses, quantifying
    /// how much the §7.1 "SDT holds in hypoxia" claim depends on O2-independence.
    #[test]
    fn o2_dependent_sdt_collapses_hypoxic_kill() {
        let sp = SpatialParams {
            cell_size_um: CELL_SIZE_UM,
            ..Default::default()
        };
        let params = Params::default();
        let seed = SEED.wrapping_add((Treatment::SDT as u64) * 10_000_000);
        // 100x100 (2 mm): tumor radius (~450 µm) comfortably exceeds 3λ (=360 µm
        // at λ=120), so there is a genuine hypoxic core for O2-dependence to bite.
        let mk = || TumorGrid::generate(100, 100, CELL_SIZE_UM, seed);
        let kill = |g: &TumorGrid| {
            let c = g.census();
            c.total_dead as f64 / c.total_tumor.max(1) as f64
        };

        // O2-independent (dep=0), WITH a supply field.
        let mut g0 = mk();
        let supply0: Vec<f64> = apply_o2_gradient(&mut g0, ZONE_REF_LAMBDA)
            .iter()
            .map(|&(_, _, f)| f)
            .collect();
        run_spatial(
            &mut g0,
            Treatment::SDT,
            &params,
            &sp,
            seed,
            Some(&supply0),
            0.0,
        );
        let kill0 = kill(&g0);

        // dep=0 with NO supply field must give the SAME kills (knob-off identity).
        let mut gn = mk();
        apply_o2_gradient(&mut gn, ZONE_REF_LAMBDA);
        run_spatial(&mut gn, Treatment::SDT, &params, &sp, seed, None, 0.0);
        assert_eq!(
            kill0,
            kill(&gn),
            "sdt_o2_dependence=0 must be byte-identical with/without a supply field"
        );

        // O2-dependent (dep=1.0): the SDT exo-ROS scales with local O2.
        let mut g1 = mk();
        let supply1: Vec<f64> = apply_o2_gradient(&mut g1, ZONE_REF_LAMBDA)
            .iter()
            .map(|&(_, _, f)| f)
            .collect();
        run_spatial(
            &mut g1,
            Treatment::SDT,
            &params,
            &sp,
            seed,
            Some(&supply1),
            1.0,
        );
        let kill1 = kill(&g1);

        assert!(
            kill0 > 0.5,
            "O2-independent SDT should kill most of the gradient tumor; got {kill0:.3}"
        );
        assert!(
            kill1 < kill0 * 0.3,
            "O2-dependent SDT must collapse vs the O2-independent bound: \
             dep=1 kill={kill1:.3} should be far below dep=0 kill={kill0:.3}"
        );
    }

    /// #SENS-SYM: the sensitizer must be able to face the same acidity barrier
    /// the drug faces.
    ///
    /// The pH block used to be gated on `tx == Treatment::RSL3`, so the
    /// sonosensitizer sat at uniform concentration everywhere while RSL3 was
    /// penalised -- and part of the reported cross-modality resistance gap came
    /// from that modelling choice rather than from biology. SDT and PDT both
    /// require a systemically dosed sensitizer (the lead clinical agent,
    /// SONALA-001, is 5-ALA); the ultrasound FIELD is pH-independent, the
    /// molecule that converts it into ROS is not.
    ///
    /// Guards both halves: `0.0` is inert (byte-identical to the historical
    /// behaviour) and a non-zero value measurably lowers SDT kill.
    #[test]
    fn sensitizer_ion_trapping_lowers_sdt_kill_and_zero_is_inert() {
        let sp = SpatialParams {
            cell_size_um: CELL_SIZE_UM,
            ..Default::default()
        };
        let params = Params::default();
        let immune = SpatialImmuneConfig::for_2d();
        let seed = SEED.wrapping_add((Treatment::SDT as u64) * 10_000_000);
        let kill = |g: &TumorGrid| {
            let c = g.census();
            c.total_dead as f64 / c.total_tumor.max(1) as f64
        };

        let run = |sens: f64| {
            let mut cfg = PhConfig::default();
            cfg.sensitizer_ion_trap_sensitivity = sens;
            let mut g = TumorGrid::generate(100, 100, CELL_SIZE_UM, seed);
            let ph_map = apply_ph_gradient(&mut g, &cfg);
            run_spatial_with_immune(
                &mut g,
                Treatment::SDT,
                &params,
                &sp,
                &immune,
                None,
                Some((&ph_map, &cfg)),
                seed,
                None,
                0.0,
            );
            kill(&g)
        };

        let baseline = run(0.0);
        let inert_again = run(0.0);
        let symmetric = run(0.4);

        assert_eq!(
            baseline, inert_again,
            "sensitizer_ion_trap_sensitivity=0.0 must be deterministic and inert"
        );
        assert!(
            baseline > 0.5,
            "SDT should kill most of the tumor without a sensitizer penalty; got {baseline:.3}"
        );
        assert!(
            symmetric < baseline * 0.9,
            "giving the sensitizer the drug's acidity barrier must measurably lower SDT \
             kill: symmetric={symmetric:.3} vs asymmetric={baseline:.3}"
        );
    }
}
