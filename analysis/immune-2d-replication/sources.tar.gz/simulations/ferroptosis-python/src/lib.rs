//! Python bindings for ferroptosis-core.
//!
//! Exposes a functional, dict-based API designed for Python researchers.
//! No classes to learn — just functions that take strings and keyword
//! arguments, returning dicts.
//!
//! ```python
//! import ferroptosis_core as fc
//!
//! stats = fc.sim_batch("Persister", "RSL3", n=1000, seed=42)
//! print(f"Death rate: {stats['death_rate']:.1%}")
//! ```

use std::collections::HashMap;

use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::PyDict;
use rand::prelude::*;
use rayon::prelude::*;

use ::ferroptosis_core::biochem::sim_cell as rust_sim_cell;
use ::ferroptosis_core::cell::{gen_cell, Phenotype, Treatment};
use ::ferroptosis_core::params::Params;
use ::ferroptosis_core::stats::wilson_ci;

// ============================================================
// Enum parsing
// ============================================================

fn parse_phenotype(s: &str) -> PyResult<Phenotype> {
    match s {
        "Glycolytic" => Ok(Phenotype::Glycolytic),
        "OXPHOS" => Ok(Phenotype::OXPHOS),
        "Persister" => Ok(Phenotype::Persister),
        "PersisterNrf2" | "Persister+NRF2" => Ok(Phenotype::PersisterNrf2),
        "Stromal" => Ok(Phenotype::Stromal),
        _ => Err(PyValueError::new_err(format!(
            "Unknown phenotype '{}'. Valid: Glycolytic, OXPHOS, Persister, PersisterNrf2, Stromal",
            s
        ))),
    }
}

/// Every treatment name `parse_treatment` accepts.
///
/// NOT every `Treatment` variant: `Radiation` is excluded on purpose, because
/// this entry point cannot deliver it (see the match arm below).
///
/// Kept beside the match and asserted against it, because the error message
/// quoting a hand-typed list is how a binding ends up accepting a name it
/// calls invalid.
const TREATMENT_NAMES: [&str; 4] = ["Control", "RSL3", "SDT", "PDT"];

fn parse_treatment(s: &str) -> PyResult<Treatment> {
    match s {
        "Control" => Ok(Treatment::Control),
        "RSL3" => Ok(Treatment::RSL3),
        "SDT" => Ok(Treatment::SDT),
        "PDT" => Ok(Treatment::PDT),
        // `Treatment::Radiation` and `Treatment::Chemotherapy` are
        // deliberately NOT accepted here. `sim_cell` takes no dose, no
        // alpha/beta, no depth, no drug class and no phase distribution, so a
        // cell built through this entry point for either would be
        // bit-identical to Control at every seed while advertising a
        // modality. That is the
        // layer-without-a-caller shape this project keeps finding, and a
        // public surface is the worst place for it. The name is admitted once
        // the binding grows a dose argument.
        // The valid list is DERIVED from the arms above rather than typed:
        // the first version hard-coded it, so adding an arm shipped a binding
        // that ACCEPTS the new name while telling the caller it is invalid.
        _ => Err(PyValueError::new_err(format!(
            "Unknown treatment '{}'. Valid: {}",
            s,
            TREATMENT_NAMES.join(", ")
        ))),
    }
}

// NOTE: this crate is a pyo3 cdylib and cannot run `cargo test` -- the test
// harness links without the Python symbols and aborts on `_PyBool_Type`. The
// both-directions check on TREATMENT_NAMES therefore lives in
// `test_bindings.py`, which runs against the BUILT module and is the only
// place that can exercise the binding at all.
fn parse_context(s: &str) -> PyResult<Params> {
    match s {
        "2d" | "default" => Ok(Params::default()),
        "invivo" | "in-vivo" | "in_vivo" => Ok(Params::invivo()),
        _ => Err(PyValueError::new_err(format!(
            "Unknown context '{}'. Valid: 2d, invivo",
            s
        ))),
    }
}

// ============================================================
// Params helpers
// ============================================================

fn params_to_dict(py: Python<'_>, params: &Params) -> PyResult<Py<PyDict>> {
    let dict = PyDict::new(py);
    dict.set_item("fenton_rate", params.fenton_rate)?;
    dict.set_item("gsh_scav_efficiency", params.gsh_scav_efficiency)?;
    dict.set_item("gsh_km", params.gsh_km)?;
    dict.set_item("nrf2_gsh_rate", params.nrf2_gsh_rate)?;
    dict.set_item("lp_rate", params.lp_rate)?;
    dict.set_item("lp_propagation", params.lp_propagation)?;
    dict.set_item("gpx4_rate", params.gpx4_rate)?;
    dict.set_item("fsp1_rate", params.fsp1_rate)?;
    dict.set_item("scd_mufa_rate", params.scd_mufa_rate)?;
    dict.set_item("scd_mufa_max", params.scd_mufa_max)?;
    dict.set_item("initial_mufa_protection", params.initial_mufa_protection)?;
    dict.set_item("scd_mufa_decay", params.scd_mufa_decay)?;
    dict.set_item("gpx4_degradation_by_ros", params.gpx4_degradation_by_ros)?;
    dict.set_item("gpx4_nrf2_upregulation", params.gpx4_nrf2_upregulation)?;
    dict.set_item("sdt_ros", params.sdt_ros)?;
    dict.set_item("pdt_ros", params.pdt_ros)?;
    dict.set_item("rsl3_gpx4_inhib", params.rsl3_gpx4_inhib)?;
    dict.set_item("gsh_max", params.gsh_max)?;
    dict.set_item(
        "gpx4_nrf2_target_multiplier",
        params.gpx4_nrf2_target_multiplier,
    )?;
    dict.set_item("death_threshold", params.death_threshold)?;
    Ok(dict.into())
}

fn validate_params(params: &Params) -> PyResult<()> {
    let checks: &[(&str, f64, f64, f64)] = &[
        ("fenton_rate", params.fenton_rate, 0.0, 10.0),
        ("gsh_scav_efficiency", params.gsh_scav_efficiency, 0.0, 1.0),
        ("gsh_km", params.gsh_km, 0.0, 100.0),
        ("lp_rate", params.lp_rate, 0.0, 10.0),
        ("lp_propagation", params.lp_propagation, 0.0, 10.0),
        ("gpx4_rate", params.gpx4_rate, 0.0, 10.0),
        ("fsp1_rate", params.fsp1_rate, 0.0, 10.0),
        ("rsl3_gpx4_inhib", params.rsl3_gpx4_inhib, 0.0, 1.0),
        ("erastin_xc_inhib", params.erastin_xc_inhib, 0.0, 1.0),
        (
            "transsulfuration_floor",
            params.transsulfuration_floor,
            0.0,
            1.0,
        ),
        ("gsh_max", params.gsh_max, 0.0, 100.0),
        ("death_threshold", params.death_threshold, 0.0, 1000.0),
        ("sdt_ros", params.sdt_ros, 0.0, 100.0),
        ("pdt_ros", params.pdt_ros, 0.0, 100.0),
        ("nrf2_gsh_rate", params.nrf2_gsh_rate, 0.0, 10.0),
        (
            "gpx4_degradation_by_ros",
            params.gpx4_degradation_by_ros,
            0.0,
            1.0,
        ),
        (
            "gpx4_nrf2_upregulation",
            params.gpx4_nrf2_upregulation,
            0.0,
            1.0,
        ),
        (
            "gpx4_nrf2_target_multiplier",
            params.gpx4_nrf2_target_multiplier,
            0.0,
            100.0,
        ),
        ("scd_mufa_rate", params.scd_mufa_rate, 0.0, 1.0),
        ("scd_mufa_max", params.scd_mufa_max, 0.0, 1.0),
        ("scd_mufa_decay", params.scd_mufa_decay, 0.0, 1.0),
        (
            "initial_mufa_protection",
            params.initial_mufa_protection,
            0.0,
            1.0,
        ),
    ];
    for (name, val, lo, hi) in checks {
        if *val < *lo || *val > *hi {
            return Err(PyValueError::new_err(format!(
                "Parameter '{}' = {} is out of range [{}, {}]",
                name, val, lo, hi
            )));
        }
    }
    Ok(())
}

fn apply_overrides(params: &mut Params, overrides: &HashMap<String, f64>) -> PyResult<()> {
    // Delegate to the single name->field mapping in ferroptosis-core (#331) so
    // the binding and the simulation binaries override the SAME parameters.
    ::ferroptosis_core::params::apply_param_overrides(
        params,
        overrides.iter().map(|(k, v)| (k.as_str(), *v)),
    )
    .map_err(|name| {
        PyValueError::new_err(format!(
            "Unknown parameter '{}'. Use default_params() to see valid names.",
            name
        ))
    })
}

// ============================================================
// Python API
// ============================================================

/// Return default parameter values as a dict.
#[pyfunction]
fn default_params(py: Python<'_>) -> PyResult<Py<PyDict>> {
    params_to_dict(py, &Params::default())
}

/// Return in-vivo parameter values (with SCD1/MUFA protection) as a dict.
#[pyfunction]
fn invivo_params(py: Python<'_>) -> PyResult<Py<PyDict>> {
    params_to_dict(py, &Params::invivo())
}

/// Simulate a single cell and return the outcome as a dict.
///
/// Args:
///     phenotype: "Glycolytic", "OXPHOS", "Persister", "PersisterNrf2", or "Stromal"
///     treatment: "Control", "RSL3", "SDT", or "PDT"
///     seed: RNG seed for reproducibility
///     context: "2d" (default) or "invivo" (enables SCD1/MUFA protection)
///     **kwargs: parameter overrides (e.g., rsl3_gpx4_inhib=0.5)
///
/// Returns:
///     dict with keys: dead (bool), lp, gsh, gpx4 (floats)
#[pyfunction]
#[pyo3(signature = (phenotype, treatment, seed, context="2d", **kwargs))]
fn sim_cell(
    py: Python<'_>,
    phenotype: &str,
    treatment: &str,
    seed: u64,
    context: &str,
    kwargs: Option<HashMap<String, f64>>,
) -> PyResult<Py<PyDict>> {
    let pheno = parse_phenotype(phenotype)?;
    let tx = parse_treatment(treatment)?;
    let mut params = parse_context(context)?;
    if let Some(overrides) = &kwargs {
        apply_overrides(&mut params, overrides)?;
    }
    validate_params(&params)?;

    let mut cell_rng = StdRng::seed_from_u64(seed);
    let cell = gen_cell(pheno, &mut cell_rng);
    let mut sim_rng = StdRng::seed_from_u64(seed.wrapping_add(1));
    let (dead, lp, gsh, gpx4) = rust_sim_cell(&cell, tx, &params, &mut sim_rng);

    let dict = PyDict::new(py);
    dict.set_item("dead", dead)?;
    dict.set_item("lp", lp)?;
    dict.set_item("gsh", gsh)?;
    dict.set_item("gpx4", gpx4)?;
    Ok(dict.into())
}

/// Simulate a population of cells and return aggregate statistics.
///
/// Runs n cells in parallel (via rayon) and returns death rate with
/// Wilson confidence intervals and mean final pathway states.
///
/// Args:
///     phenotype: "Glycolytic", "OXPHOS", "Persister", "PersisterNrf2", or "Stromal"
///     treatment: "Control", "RSL3", "SDT", or "PDT"
///     n: number of cells to simulate
///     seed: RNG seed for reproducibility
///     context: "2d" (default) or "invivo" (enables SCD1/MUFA protection)
///     **kwargs: parameter overrides (e.g., rsl3_gpx4_inhib=0.5)
///
/// Returns:
///     dict with keys: death_rate, ci_low, ci_high, n_dead, n_cells,
///                     mean_lp, mean_gsh, mean_gpx4
#[pyfunction]
#[pyo3(signature = (phenotype, treatment, n, seed, context="2d", **kwargs))]
fn sim_batch(
    py: Python<'_>,
    phenotype: &str,
    treatment: &str,
    n: usize,
    seed: u64,
    context: &str,
    kwargs: Option<HashMap<String, f64>>,
) -> PyResult<Py<PyDict>> {
    let pheno = parse_phenotype(phenotype)?;
    let tx = parse_treatment(treatment)?;
    if n == 0 {
        return Err(PyValueError::new_err("n must be > 0"));
    }
    let mut params = parse_context(context)?;
    if let Some(overrides) = &kwargs {
        apply_overrides(&mut params, overrides)?;
    }
    validate_params(&params)?;

    // Compute per-cell outcomes in parallel (deterministic per-cell RNG), then
    // reduce in a FIXED index order. Float addition is not associative, so the
    // previous rayon fold/reduce made mean_lp/gsh/gpx4 depend on thread scheduling
    // — not bit-reproducible despite the public seed-for-reproducibility contract
    // (#531). rayon `collect()` preserves index order, so summing the collected Vec
    // is deterministic; n_dead was already order-independent. The O(1)-memory fold
    // is traded for an O(n) buffer (the means are not figure-critical and this
    // keeps a fixed seed bitwise reproducible).
    // `detach` is the PyO3 0.28 replacement for the removed `allow_threads`.
    let outcomes: Vec<(bool, f64, f64, f64)> = py.detach(|| {
        (0..n)
            .into_par_iter()
            .map(|i| {
                let cell_seed = seed.wrapping_add((i as u64) * 2);
                let mut cell_rng = StdRng::seed_from_u64(cell_seed);
                let cell = gen_cell(pheno, &mut cell_rng);
                let mut sim_rng = StdRng::seed_from_u64(cell_seed.wrapping_add(1));
                rust_sim_cell(&cell, tx, &params, &mut sim_rng)
            })
            .collect()
    });
    let n_dead = outcomes.iter().filter(|(d, ..)| *d).count();
    let sum_lp = outcomes.iter().map(|(_, l, _, _)| l).sum::<f64>();
    let sum_gsh = outcomes.iter().map(|(_, _, g, _)| g).sum::<f64>();
    let sum_gpx4 = outcomes.iter().map(|(_, _, _, p)| p).sum::<f64>();

    let nf = n as f64;
    let death_rate = n_dead as f64 / nf;
    let (ci_low, ci_high) = wilson_ci(n, n_dead);
    let mean_lp = sum_lp / nf;
    let mean_gsh = sum_gsh / nf;
    let mean_gpx4 = sum_gpx4 / nf;

    let dict = PyDict::new(py);
    dict.set_item("death_rate", death_rate)?;
    dict.set_item("ci_low", ci_low)?;
    dict.set_item("ci_high", ci_high)?;
    dict.set_item("n_dead", n_dead)?;
    dict.set_item("n_cells", n)?;
    dict.set_item("mean_lp", mean_lp)?;
    dict.set_item("mean_gsh", mean_gsh)?;
    dict.set_item("mean_gpx4", mean_gpx4)?;
    Ok(dict.into())
}

// ============================================================
// Module registration
// ============================================================

#[pymodule]
fn ferroptosis_core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(default_params, m)?)?;
    m.add_function(wrap_pyfunction!(invivo_params, m)?)?;
    m.add_function(wrap_pyfunction!(sim_cell, m)?)?;
    m.add_function(wrap_pyfunction!(sim_batch, m)?)?;
    Ok(())
}
