//! 3D spheroid radial cell biology (#197).
//!
//! `TumorGrid3D::generate` assigns phenotypes by a coarse core/periphery split
//! with random rolls. A real spheroid is more structured: a proliferating,
//! well-nourished **glycolytic rim**, a quiescent **OXPHOS** intermediate
//! zone, and a hypoxic, nutrient-deprived **persister-like core**. And within a
//! phenotype the cascade itself is position-dependent — peripheral cells
//! accumulate more MUFA, core cells start GSH-poor (cysteine-limited) and
//! iron-rich (HIF-driven import). This module makes those gradients explicit,
//! to be run with [`Params::spheroid`](crate::params::Params::spheroid).
//!
//! ## Design: opt-in re-assignment via an independent RNG (byte-identity)
//!
//! [`apply_radial_cells_3d`] **re-generates** each tumor cell with its
//! radial-position phenotype, drawing from its own per-cell `StdRng` seeded
//! from `seed` — it never touches `TumorGrid3D::generate`'s stream, so a
//! consumer that doesn't opt in keeps the random grid and stays byte-identical.
//! The phenotype change rewrites the cell's biochemical draw (unlike the
//! parameter-only `clonal`/`vasculature` layers), so this is a deliberate
//! "different tumor model", not a perturbation of the default one. Position-
//! dependent MUFA is a `CellState` value the consumer applies after init via
//! [`radial_mufa_protection`] (it needs the freshly-initialized state, and
//! relies on `Params::spheroid`'s partially-active SCD1 to persist).

use crate::cell::{gen_cell, Phenotype};
use crate::grid::{TumorGrid3D, TUMOR_RADIUS_FRACTION};
use rand::prelude::*;

/// Radial structure + gradient strengths for a spheroid. The phenotype-zone
/// thresholds are **cumulative-VOLUME fractions** (0 = center, 1 = whole
/// tumor); the gradient endpoints below are still keyed on radial position
/// (0 = center/core, 1 = surface), since diffusion gradients are radial.
#[derive(Clone, Copy, Debug)]
pub struct SpheroidConfig {
    /// Cells whose cumulative volume fraction (frac³) is at/above this are
    /// Glycolytic (the proliferating rim). So the rim occupies the outer
    /// `1 − glycolytic_frac` of the tumor *volume*.
    pub glycolytic_frac: f64,
    /// Cumulative volume fraction at/above which (and below `glycolytic_frac`)
    /// cells are OXPHOS; below it, the Persister-like core. So the core
    /// occupies the inner `oxphos_frac` of the tumor *volume*.
    pub oxphos_frac: f64,
    /// Per-cell MUFA carrying **cap** at the surface (high) and core (low) —
    /// the `cell.mufa_cap` `update_mufa_protection` saturates toward, so the
    /// position-dependent MUFA is durable (#270), not a transient initial
    /// condition that converges to the uniform M_ss. The same radial value also
    /// seeds the initial `state.mufa_protection`.
    pub mufa_surface: f64,
    pub mufa_core: f64,
    /// Initial-GSH multiplier at the core (cysteine-limited; < 1). Surface = 1.
    pub gsh_core_factor: f64,
    /// Labile-iron multiplier at the core (HIF-driven import; > 1). Surface = 1.
    pub iron_core_factor: f64,
}

impl SpheroidConfig {
    /// Literature-informed defaults: by VOLUME, a thin glycolytic rim (~27%), an
    /// OXPHOS intermediate zone (~34%), and a large persister-like core (~39%) —
    /// the Browning-2021 limiting structure (see the zone-geometry note below).
    /// Biochemical gradients are placeholders pending calibration: MUFA 0.25→0.05
    /// surface→core; core GSH ×0.5; core iron ×1.6.
    ///
    /// MUFA is now a **durable** position-dependent axis (#270): `mufa_surface`
    /// / `mufa_core` are the per-cell MUFA carrying caps (`cell.mufa_cap`), so
    /// `update_mufa_protection` relaxes each cell toward a steady state that
    /// scales with its cap instead of every cell converging to the global
    /// uniform M_ss. (Previously these set only the *initial* `state.mufa_protection`,
    /// which relaxed back — the #197-review transience caveat, resolved here.)
    /// `iron_core_factor` (a static `cell.iron` scale) is likewise durable;
    /// `gsh_core_factor` sets the *initial* GSH, which then evolves under NRF2
    /// resynthesis. Values remain placeholders pending calibration.
    ///
    /// **Zone geometry (#270): volume-based, literature-grounded.** The
    /// thresholds are cumulative-VOLUME fractions, and the defaults come from
    /// the limiting spheroid structure measured by Browning et al. (eLife 2021,
    /// DOI 10.7554/eLife.73020): a necrotic core at ~73% of the outer radius and
    /// a proliferative/inhibited boundary at ~90% (a thin ~35 µm rim). Converting
    /// those radial boundaries to volume fractions (∝ r³): the persister-like
    /// core is the inner 0.73³ ≈ 0.39 of the tumor *volume* (`oxphos_frac`), and
    /// the glycolytic rim is the outer 1 − 0.90³ ≈ 0.27 (`glycolytic_frac` = 0.73).
    /// This fixes the previous inversion (radial thresholds gave a ~4 %-volume
    /// core and a ~71 %-volume rim). The *radial structure* is now grounded; the
    /// per-zone *biochemical* gradients (MUFA/GSH/iron) remain placeholders
    /// pending histology calibration. Two scoping caveats: (1) these are the
    /// *limiting* (large-spheroid) proportions applied size-independently — real
    /// zone fractions shrink with spheroid diameter (small spheroids have little
    /// or no necrotic core). [`SizeAwareZones`] (#333) now provides the size-aware
    /// variant that ramps both zone thresholds from zero (small, all-proliferating,
    /// no core) up to these limiting fractions, reducing to this fixed structure at
    /// large radius; the fixed path here is unchanged (byte-identical). (2) the
    /// gradient *strengths* below are still uncalibrated.
    pub fn literature() -> Self {
        SpheroidConfig {
            // Volume fractions: rim begins at 0.90³≈0.73 of volume; core is the
            // inner 0.73³≈0.39 (Browning 2021 eLife limiting structure).
            glycolytic_frac: 0.73,
            oxphos_frac: 0.39,
            // Per-cell MUFA caps (#270): rim saturates near the global cap,
            // core saturates lower → durable rim-vs-core MUFA spread.
            mufa_surface: 0.25,
            mufa_core: 0.05,
            gsh_core_factor: 0.5,
            iron_core_factor: 1.6,
        }
    }
}

/// Size-aware zone thresholds (#333): make the persister-core and glycolytic-rim
/// volume thresholds depend on the absolute spheroid radius, instead of applying
/// the limiting (large-spheroid) proportions size-independently.
///
/// The #333 structure validation found the fixed thresholds match the Browning
/// 2021 confocal data only for radius ≳ 300 µm; below that, real spheroids are
/// mostly proliferating with little or no necrotic core (the fixed model
/// over-predicts the core: median necrotic-boundary error ~0.73 for R < 300 µm).
/// This ramps each base threshold from 0 (a small, all-proliferating spheroid with
/// NO persister core) up to its base value, reducing EXACTLY to the fixed
/// [`SpheroidConfig`] thresholds at large radius (so the validated large-spheroid
/// structure is preserved). The rim begins thinning before the core necroses, so
/// the rim ramp has an earlier onset than the core ramp.
///
/// Parameters are first-order fits to the Browning 2021 size-binned medians (the
/// committed `analysis/calibration/spheroid-structure-validation.json`), and are
/// weakly constrained (four size bins, the largest with n=1). The radii (µm) below
/// are the onset (zone begins to appear) and full (reaches the limiting structure)
/// radii for each boundary. Opt-in: nothing constructs this by default, so the
/// matrix and the fixed spheroid path stay byte-identical.
#[derive(Clone, Copy, Debug)]
pub struct SizeAwareZones {
    /// Radius (µm) at which the glycolytic rim begins thinning toward its limiting
    /// (thin) fraction. Below it the whole spheroid is proliferating rim.
    pub rim_onset_um: f64,
    /// Radius (µm) at which the rim reaches its limiting fraction.
    pub rim_full_um: f64,
    /// Radius (µm) at which a persister/necrotic core first appears.
    pub core_onset_um: f64,
    /// Radius (µm) at which the core reaches its limiting fraction.
    pub core_full_um: f64,
}

impl SizeAwareZones {
    /// First-order fit to the Browning 2021 size-binned structure: the rim begins
    /// thinning near R ≈ 200 µm and saturates by ≈ 370 µm; the necrotic core
    /// appears near R ≈ 280 µm (where ~half of spheroids have a core) and saturates
    /// by ≈ 400 µm. These reproduce the bin medians markedly better than the fixed
    /// thresholds for R < 300 µm (necrotic core ~0 instead of 0.73) while matching
    /// them for R ≳ 350 µm; they are weakly constrained (four bins) placeholders.
    pub fn literature() -> Self {
        SizeAwareZones {
            rim_onset_um: 200.0,
            rim_full_um: 370.0,
            core_onset_um: 280.0,
            core_full_um: 400.0,
        }
    }

    /// Size-adjusted `(glycolytic_frac, oxphos_frac)` for a spheroid of radius
    /// `r_um`, scaling the base config's limiting thresholds by a 0→1 onset→full
    /// ramp per boundary. At `r_um ≤ onset` the zone is absent (frac 0); at
    /// `r_um ≥ full` it equals the base (limiting) value, so this reduces exactly
    /// to the fixed thresholds for large spheroids.
    pub fn effective_fracs(&self, base: &SpheroidConfig, r_um: f64) -> (f64, f64) {
        let ramp = |onset: f64, full: f64| -> f64 {
            if full <= onset {
                return 1.0;
            }
            ((r_um - onset) / (full - onset)).clamp(0.0, 1.0)
        };
        let glycolytic_frac = base.glycolytic_frac * ramp(self.rim_onset_um, self.rim_full_um);
        let oxphos_frac = base.oxphos_frac * ramp(self.core_onset_um, self.core_full_um);
        (glycolytic_frac, oxphos_frac)
    }
}

/// Spheroid radius in µm for a grid, mirroring [`radial_fraction_3d`]'s geometry:
/// `min(dims) × TUMOR_RADIUS_FRACTION` cells, times the physical cell size.
pub fn tumor_radius_um(grid: &TumorGrid3D, cell_um: f64) -> f64 {
    (grid.rows.min(grid.cols).min(grid.layers) as f64) * TUMOR_RADIUS_FRACTION * cell_um
}

/// Radial fraction of a cell: `0.0` at the spheroid center, `1.0` at the
/// surface (clamped). Geometry matches `TumorGrid3D::generate` (center =
/// dims/2, radius = min(dims) × `TUMOR_RADIUS_FRACTION`).
pub fn radial_fraction_3d(grid: &TumorGrid3D, idx: usize) -> f64 {
    let (r, c, l) = grid.coords(idx);
    let center = (
        grid.rows as f64 / 2.0,
        grid.cols as f64 / 2.0,
        grid.layers as f64 / 2.0,
    );
    let tumor_radius = (grid.rows.min(grid.cols).min(grid.layers) as f64) * TUMOR_RADIUS_FRACTION;
    let dist = ((r as f64 - center.0).powi(2)
        + (c as f64 - center.1).powi(2)
        + (l as f64 - center.2).powi(2))
    .sqrt();
    (dist / tumor_radius).clamp(0.0, 1.0)
}

/// Phenotype for a cell at radial fraction `frac`: glycolytic rim → OXPHOS mid
/// → persister-like core.
///
/// The thresholds are **cumulative-VOLUME fractions** (#270), not raw radial
/// fractions. A cell at radial fraction `frac` sits at cumulative volume
/// fraction `frac³` measured from the center (volume of a sphere ∝ r³), so we
/// compare `frac³` against the volume-fraction thresholds. This makes the zone
/// *volumes* match the config (the previous radial-fraction thresholds gave an
/// inverted distribution — a ~4 %-volume core and a ~71 %-volume rim).
///
/// `frac³` is the *continuous*-sphere volume fraction; the discrete lattice
/// cell-*count* within a given radius only approximates it (most loosely in the
/// small core, where few cells exist), so the realized count fractions sit near,
/// not exactly at, the configured volume fractions.
pub fn radial_phenotype(frac: f64, cfg: &SpheroidConfig) -> Phenotype {
    let vol_frac = frac.clamp(0.0, 1.0).powi(3);
    if vol_frac >= cfg.glycolytic_frac {
        Phenotype::Glycolytic
    } else if vol_frac >= cfg.oxphos_frac {
        Phenotype::OXPHOS
    } else {
        Phenotype::Persister
    }
}

#[inline]
fn lerp_core_surface(core: f64, surface: f64, frac: f64) -> f64 {
    core + (surface - core) * frac.clamp(0.0, 1.0)
}

/// Position-dependent MUFA level: high at the surface, low at the core. Used
/// for **both** the per-cell MUFA cap (`cell.mufa_cap`, set in
/// [`apply_radial_cells_3d`] so the value is durable, #270) and the consumer's
/// initial `state.mufa_protection`.
pub fn radial_mufa_protection(frac: f64, cfg: &SpheroidConfig) -> f64 {
    lerp_core_surface(cfg.mufa_core, cfg.mufa_surface, frac)
}

/// Initial-GSH multiplier: `gsh_core_factor` (< 1) at the core, 1.0 at surface.
pub fn radial_gsh_factor(frac: f64, cfg: &SpheroidConfig) -> f64 {
    lerp_core_surface(cfg.gsh_core_factor, 1.0, frac)
}

/// Labile-iron multiplier: `iron_core_factor` (> 1) at the core, 1.0 at surface.
pub fn radial_iron_factor(frac: f64, cfg: &SpheroidConfig) -> f64 {
    lerp_core_surface(cfg.iron_core_factor, 1.0, frac)
}

/// Re-assign every tumor cell radially: re-generate it with its
/// radial-position phenotype (per-cell independent RNG), then scale `cell.gsh`
/// (core-low) and `cell.iron` (core-high) by the radial gradients and set the
/// per-cell `cell.mufa_cap` (rim-high, core-low; #270) so the position-dependent
/// MUFA is **durable** — the MUFA steady state scales with this cap rather than
/// every cell converging to the global uniform M_ss. Non-tumor (stromal) cells
/// are left untouched. Deterministic given `(grid dims, cfg, seed)`. The
/// consumer still sets the *initial* `state.mufa_protection` after state init
/// via [`radial_mufa_protection`] (the same radial value the cap uses), so the
/// cell both starts at and relaxes toward its position-dependent level.
pub fn apply_radial_cells_3d(grid: &mut TumorGrid3D, cfg: &SpheroidConfig, seed: u64) {
    for idx in 0..grid.cells.len() {
        if !grid.cells[idx].is_tumor {
            continue;
        }
        let frac = radial_fraction_3d(grid, idx); // immutable borrow ends here
        let pheno = radial_phenotype(frac, cfg);
        let mut rng = StdRng::seed_from_u64(seed.wrapping_add(idx as u64));
        let mut cell = gen_cell(pheno, &mut rng);
        cell.gsh *= radial_gsh_factor(frac, cfg);
        cell.iron *= radial_iron_factor(frac, cfg);
        cell.mufa_cap = Some(radial_mufa_protection(frac, cfg));
        grid.cells[idx].cell = cell;
        grid.cells[idx].phenotype = pheno;
    }
}

/// Size-aware variant of [`apply_radial_cells_3d`] (#333): derive the grid's
/// spheroid radius (`cell_um` µm per cell) and scale the zone thresholds via
/// `size_aware`, so a small spheroid is mostly proliferating with no persister
/// core and a large one reproduces the fixed limiting structure. The biochemical
/// gradients (MUFA/GSH/iron) are radial-position based and so are size-independent,
/// so this just builds a size-adjusted [`SpheroidConfig`] and reuses the fixed
/// apply path; at a radius `≥` the full radii it is identical to
/// `apply_radial_cells_3d(grid, base_cfg, seed)`.
pub fn apply_radial_cells_sized_3d(
    grid: &mut TumorGrid3D,
    base_cfg: &SpheroidConfig,
    size_aware: &SizeAwareZones,
    cell_um: f64,
    seed: u64,
) {
    let r_um = tumor_radius_um(grid, cell_um);
    let (glycolytic_frac, oxphos_frac) = size_aware.effective_fracs(base_cfg, r_um);
    let eff = SpheroidConfig {
        glycolytic_frac,
        oxphos_frac,
        ..*base_cfg
    };
    apply_radial_cells_3d(grid, &eff, seed);
}

#[cfg(test)]
mod tests {
    use super::*;

    fn cfg() -> SpheroidConfig {
        SpheroidConfig::literature()
    }

    #[test]
    fn phenotype_zones_are_volume_based_rim_to_core() {
        let c = cfg();
        // Thresholds are cumulative-VOLUME fractions (#270): a cell at radial
        // fraction r sits at volume fraction r³. With the Browning-2021 limiting
        // structure (core 0.73 of radius → 0.39 of volume; rim begins 0.90 of
        // radius → 0.73 of volume), the core spans radius up to ~0.73R.
        assert_eq!(radial_phenotype(0.95, &c), Phenotype::Glycolytic); // r=0.95 → vol 0.86 ≥ 0.73: rim
        assert_eq!(radial_phenotype(0.80, &c), Phenotype::OXPHOS); // r=0.80 → vol 0.51: mid
        assert_eq!(radial_phenotype(0.50, &c), Phenotype::Persister); // r=0.50 → vol 0.125 < 0.39: core (was OXPHOS pre-#270)
        assert_eq!(radial_phenotype(0.10, &c), Phenotype::Persister); // deep core
                                                                      // The radial zone boundaries are the cube-roots of the volume thresholds.
        let core_radius = c.oxphos_frac.cbrt();
        let rim_radius = c.glycolytic_frac.cbrt();
        assert!(
            (core_radius - 0.73).abs() < 0.02,
            "core radius ~0.73R, got {core_radius}"
        );
        assert!(
            (rim_radius - 0.90).abs() < 0.02,
            "rim begins ~0.90R, got {rim_radius}"
        );
        // The core is now a substantial volume fraction (the bug was ~4%).
        assert!(
            c.oxphos_frac > 0.30,
            "persister core should be a substantial volume fraction, got {}",
            c.oxphos_frac
        );
    }

    #[test]
    fn gradients_have_correct_direction_and_endpoints() {
        let c = cfg();
        // Surface endpoints are the neutral values; core endpoints are the cfg.
        assert!((radial_gsh_factor(1.0, &c) - 1.0).abs() < 1e-12);
        assert!((radial_iron_factor(1.0, &c) - 1.0).abs() < 1e-12);
        assert!((radial_gsh_factor(0.0, &c) - c.gsh_core_factor).abs() < 1e-12);
        assert!((radial_iron_factor(0.0, &c) - c.iron_core_factor).abs() < 1e-12);
        // Core is GSH-poor (<1) and iron-rich (>1); MUFA higher at surface.
        assert!(radial_gsh_factor(0.0, &c) < radial_gsh_factor(1.0, &c));
        assert!(radial_iron_factor(0.0, &c) > radial_iron_factor(1.0, &c));
        assert!(radial_mufa_protection(1.0, &c) > radial_mufa_protection(0.0, &c));
    }

    #[test]
    fn radial_fraction_is_zero_at_center_and_high_at_surface() {
        let g = TumorGrid3D::generate(40, 40, 40, 20.0, 42);
        let center_idx = g.flat_index(20, 20, 20);
        // A near-surface tumor cell: scan a ray out from center along +row.
        let mut surface_idx = center_idx;
        for r in 20..40 {
            let i = g.flat_index(r, 20, 20);
            if g.cells[i].is_tumor {
                surface_idx = i;
            }
        }
        assert!(radial_fraction_3d(&g, center_idx) < 0.1);
        assert!(radial_fraction_3d(&g, surface_idx) > radial_fraction_3d(&g, center_idx));
    }

    #[test]
    fn re_assignment_is_deterministic_and_radial() {
        let mut a = TumorGrid3D::generate(30, 30, 30, 20.0, 42);
        let mut b = TumorGrid3D::generate(30, 30, 30, 20.0, 42);
        apply_radial_cells_3d(&mut a, &cfg(), 7);
        apply_radial_cells_3d(&mut b, &cfg(), 7);
        // Deterministic: same seed → identical phenotypes + cell draws.
        let phenos_a: Vec<_> = a.cells.iter().map(|gc| gc.phenotype).collect();
        let phenos_b: Vec<_> = b.cells.iter().map(|gc| gc.phenotype).collect();
        assert_eq!(phenos_a, phenos_b);
        // The center tumor cell is Persister-like; a surface tumor cell is not.
        let center = a.flat_index(15, 15, 15);
        assert_eq!(a.cells[center].phenotype, Phenotype::Persister);
        // Stromal (non-tumor) cells are untouched.
        for gc in &a.cells {
            if !gc.is_tumor {
                assert_eq!(gc.phenotype, Phenotype::Stromal);
            }
        }
    }

    #[test]
    fn size_aware_fracs_ramp_from_zero_to_the_fixed_limit() {
        let base = cfg();
        let sa = SizeAwareZones::literature();
        // Small spheroid (below both onsets): no core, no thinned rim → both 0.
        let (g_small, o_small) = sa.effective_fracs(&base, 150.0);
        assert_eq!((g_small, o_small), (0.0, 0.0));
        // Large spheroid (above both full radii): reduces EXACTLY to the fixed
        // limiting thresholds, so the validated large-R structure is preserved.
        let (g_big, o_big) = sa.effective_fracs(&base, 600.0);
        assert!((g_big - base.glycolytic_frac).abs() < 1e-12);
        assert!((o_big - base.oxphos_frac).abs() < 1e-12);
        // Monotone non-decreasing in radius; the core appears no earlier than the
        // rim begins thinning (rim onset < core onset).
        let (g_mid, o_mid) = sa.effective_fracs(&base, 330.0);
        assert!(g_mid > 0.0 && g_mid <= base.glycolytic_frac);
        assert!(o_mid >= 0.0 && o_mid < base.oxphos_frac);
        assert!(sa.rim_onset_um < sa.core_onset_um);
    }

    #[test]
    fn size_aware_small_spheroid_has_no_persister_core_large_matches_fixed() {
        // Small spheroid: 16³ grid at 20 µm/cell → R ≈ 16·0.45·20 = 144 µm, below
        // the core onset, so it should be all-proliferating with NO persister core.
        let mut small = TumorGrid3D::generate(16, 16, 16, 20.0, 42);
        apply_radial_cells_sized_3d(&mut small, &cfg(), &SizeAwareZones::literature(), 20.0, 7);
        let persisters = small
            .cells
            .iter()
            .filter(|gc| gc.is_tumor && gc.phenotype == Phenotype::Persister)
            .count();
        assert_eq!(
            persisters, 0,
            "small spheroid should have no persister core"
        );

        // Large spheroid: 60³ → R ≈ 540 µm, above both full radii, so the size-aware
        // apply is byte-identical to the fixed apply (effective fracs == base).
        let mut sized = TumorGrid3D::generate(60, 60, 60, 20.0, 42);
        let mut fixed = TumorGrid3D::generate(60, 60, 60, 20.0, 42);
        apply_radial_cells_sized_3d(&mut sized, &cfg(), &SizeAwareZones::literature(), 20.0, 7);
        apply_radial_cells_3d(&mut fixed, &cfg(), 7);
        let p_sized: Vec<_> = sized.cells.iter().map(|gc| gc.phenotype).collect();
        let p_fixed: Vec<_> = fixed.cells.iter().map(|gc| gc.phenotype).collect();
        assert_eq!(p_sized, p_fixed, "large spheroid: size-aware == fixed");
        // And the large spheroid DOES have a persister core (sanity).
        assert!(p_sized.iter().any(|&p| p == Phenotype::Persister));
    }

    #[test]
    fn tumor_radius_um_matches_generation_geometry() {
        let g = TumorGrid3D::generate(60, 60, 60, 20.0, 42);
        // 60 · TUMOR_RADIUS_FRACTION(0.45) · 20 µm = 540 µm (the sim-tme-3d radius).
        assert!((tumor_radius_um(&g, 20.0) - 540.0).abs() < 1e-9);
    }

    /// #270 wiring: `apply_radial_cells_3d` sets the per-cell MUFA cap radially
    /// (core-low, rim-high) and leaves stromal cells uncapped (`None`), so the
    /// durable-MUFA mechanism gets a per-cell cap to act on.
    #[test]
    fn apply_sets_radial_mufa_cap_core_below_rim() {
        let mut g = TumorGrid3D::generate(40, 40, 40, 20.0, 42);
        apply_radial_cells_3d(&mut g, &cfg(), 7);

        // A core tumor cell and a near-surface tumor cell along +row from center.
        let center = g.flat_index(20, 20, 20);
        let mut surface = center;
        for r in 20..40 {
            let i = g.flat_index(r, 20, 20);
            if g.cells[i].is_tumor {
                surface = i;
            }
        }
        let core_cap = g.cells[center]
            .cell
            .mufa_cap
            .expect("core tumor cell is capped");
        let rim_cap = g.cells[surface]
            .cell
            .mufa_cap
            .expect("rim tumor cell is capped");
        assert!(
            core_cap < rim_cap,
            "core MUFA cap should be below rim: core={core_cap}, rim={rim_cap}"
        );
        // Caps lie within the configured [core, surface] band.
        let c = cfg();
        assert!(core_cap >= c.mufa_core - 1e-9 && rim_cap <= c.mufa_surface + 1e-9);
        // Stromal (non-tumor) cells are left uncapped.
        for gc in &g.cells {
            if !gc.is_tumor {
                assert!(gc.cell.mufa_cap.is_none(), "stroma stays uncapped");
            }
        }
    }
}
