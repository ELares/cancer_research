//! Drug penetration modeling for tissue-specific pharmacokinetics.
//!
//! Models how drug concentration drops with distance from the nearest
//! blood vessel using an exponential decay approximation of the Krogh
//! cylinder steady-state solution.
//!
//! The key equation: `C(r) = C₀ × exp(-r / λ)` where `λ = √(D/k)` is
//! the penetration length, `D` is the effective diffusion coefficient,
//! and `k` is the total clearance rate (cellular uptake + metabolism).
//!
//! # References
//!
//! - Minchinton AI, Tannock IF. "Drug penetration in solid tumours."
//!   Nature Reviews Cancer 6:583-592, 2006.
//! - Thurber GM, et al. "Antibody tumor penetration." Advanced Drug
//!   Delivery Reviews 60:1421-1434, 2008.
//! - El-Kareh AW, Secomb TW. "A mathematical model for comparison of
//!   bolus injection, continuous infusion, and liposomal delivery of
//!   doxorubicin." Neoplasia 2:325-338, 2000.

use serde::{Deserialize, Serialize};

/// Drug physicochemical and pharmacokinetic parameters.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct DrugParams {
    /// Effective diffusion coefficient in tissue (cm²/s).
    /// Depends on drug molecular weight, charge, and tissue density.
    /// Small molecules (~500 Da): 1-10 × 10⁻⁷ cm²/s.
    /// Antibodies (~150 kDa): 0.1-1 × 10⁻⁷ cm²/s.
    pub diffusion_coeff_cm2_s: f64,

    /// Cellular uptake rate (1/s). How fast cells internalize the drug.
    pub uptake_rate: f64,

    /// Extracellular metabolism/degradation rate (1/s).
    pub metabolism_rate: f64,

    /// Drug-intrinsic bioavailability at the vessel wall (normalized, 0-1).
    /// Accounts for plasma protein binding and endothelial exclusion
    /// specific to the drug molecule. Set to 1.0 for freely permeable
    /// small molecules. This is multiplied by the tissue's vascular
    /// permeability to get the interstitial concentration, so do NOT
    /// duplicate the tissue permeability factor here.
    pub vessel_wall_conc: f64,

    /// Human-readable name for output.
    pub name: &'static str,
}

/// Tissue-specific transport parameters affecting drug penetration.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct TissueParams {
    /// Mean inter-vessel distance (μm). Determines how far a drug must
    /// diffuse to reach the most remote cells. Inversely related to
    /// vascular density. Typical: 100-300μm in solid tumors.
    pub inter_vessel_distance_um: f64,

    /// Vascular permeability factor (0-1). Fraction of vessel-wall
    /// concentration that reaches the interstitium. Reduced by tight
    /// junctions (BBB), elevated interstitial fluid pressure, etc.
    pub vascular_permeability: f64,

    /// ECM-mediated diffusion-barrier tortuosity (#315). A dense, assembled
    /// extracellular matrix (desmoplastic stroma) impedes interstitial drug
    /// diffusion, lowering the effective diffusion coefficient and so the
    /// penetration length: `λ_eff = λ / sqrt(tortuosity)`. `1.0` ⇒ no barrier
    /// (identity), so the default tissues stay byte-identical to the pre-#315
    /// model; `> 1.0` models an ECM-dense / desmoplastic tissue (e.g.
    /// pancreatic) where drug penetrates less. The magnitude is an UNCALIBRATED
    /// placeholder encoding the documented direction (denser ECM ⇒ shorter
    /// penetration); calibrate vs ECM-density-resolved interstitial-diffusivity
    /// measurements. Refs: Netti et al., Cancer Res 2000 (PMID 10811131, ECM
    /// assembly governs interstitial transport); Provenzano et al., Cancer Cell
    /// 2012 (PMID 22439937, stromal ablation removes physical drug barriers).
    #[serde(default = "default_ecm_tortuosity")]
    pub ecm_tortuosity: f64,

    /// Human-readable name for output.
    pub name: &'static str,
}

/// Default ECM tortuosity (1.0 = no barrier / identity). A free function so
/// `#[serde(default)]` fills the field when deserializing pre-#315
/// `TissueParams` that lack it.
fn default_ecm_tortuosity() -> f64 {
    1.0
}

/// Characteristic penetration length (μm).
///
/// This is the distance at which drug concentration drops to 1/e (~37%)
/// of its vessel-wall value. Determined by the balance between diffusion
/// (spreading the drug) and clearance (cells consuming it).
///
/// `λ = √(D / k_total)` where `k_total = uptake_rate + metabolism_rate`.
pub fn penetration_length_um(drug: &DrugParams) -> f64 {
    let k_total = drug.uptake_rate + drug.metabolism_rate;
    if k_total <= 0.0 {
        return f64::INFINITY;
    }
    // Convert D from cm²/s to μm²/s (1 cm = 10⁴ μm, so 1 cm² = 10⁸ μm²)
    let d_um2_s = drug.diffusion_coeff_cm2_s * 1e8;
    (d_um2_s / k_total).sqrt()
}

/// Drug concentration at radial distance `r_um` (μm) from the nearest vessel.
///
/// Returns normalized concentration in [0, 1]. Uses the exponential decay
/// approximation of the Krogh cylinder steady-state solution, which is valid
/// when the vessel radius is much smaller than the tissue radius (typically
/// R_vessel ≈ 5-10μm vs R_tissue ≈ 50-150μm).
///
/// `C(r) = C_vessel × permeability × exp(-r / λ_eff)`, where the ECM tortuosity
/// shortens the penetration length: `λ_eff = λ / sqrt(tissue.ecm_tortuosity)`
/// (#315). With the default `ecm_tortuosity = 1.0`, `λ_eff = λ` and this is
/// byte-identical to the pre-#315 model.
pub fn concentration_at_distance(r_um: f64, drug: &DrugParams, tissue: &TissueParams) -> f64 {
    let lambda = penetration_length_um(drug) / tissue.ecm_tortuosity.sqrt();
    let c0 = drug.vessel_wall_conc * tissue.vascular_permeability;
    (c0 * (-r_um / lambda).exp()).min(1.0)
}

/// Maximum distance from a vessel (half the inter-vessel distance).
pub fn max_distance_um(tissue: &TissueParams) -> f64 {
    tissue.inter_vessel_distance_um / 2.0
}

/// Compute the concentration profile across the full radial range.
///
/// Returns `n_bins` evenly spaced `(distance_um, concentration)` pairs
/// from 0 to `max_distance_um`.
pub fn concentration_profile(
    drug: &DrugParams,
    tissue: &TissueParams,
    n_bins: usize,
) -> Vec<(f64, f64)> {
    let r_max = max_distance_um(tissue);
    (0..n_bins)
        .map(|i| {
            let r = r_max * i as f64 / (n_bins - 1).max(1) as f64;
            (r, concentration_at_distance(r, drug, tissue))
        })
        .collect()
}

// ============================================================
// Drug Presets
// ============================================================

/// RSL3-like small molecule GPX4 inhibitor.
///
/// MW ~500 Da. Moderate diffusion, moderate cellular uptake.
/// Penetration length ~100-120μm in well-vascularized tissue.
pub fn rsl3_like() -> DrugParams {
    DrugParams {
        // Small molecule in tissue: D ≈ 5 × 10⁻⁷ cm²/s
        // Ref: El-Kareh & Secomb 2000 (doxorubicin range 1-8 × 10⁻⁷)
        diffusion_coeff_cm2_s: 5.0e-7,
        // Moderate uptake: cells internalize but don't trap heavily
        uptake_rate: 0.004,
        // Low extracellular metabolism for a stable small molecule
        metabolism_rate: 0.001,
        // Freely permeable small molecule
        vessel_wall_conc: 1.0,
        name: "RSL3-like",
    }
}

/// Doxorubicin-like transport profile (penetration calibration reference).
///
/// Uses doxorubicin's well-characterized transport parameters
/// (MW ~540 Da, D ≈ 3×10⁻⁷ cm²/s, high uptake from DNA trapping)
/// to validate that the exponential model produces a penetration
/// length in the published 40-80μm range (Minchinton & Tannock 2006).
///
/// **Important:** This is a transport-only reference. The cell-level
/// pharmacology still uses the RSL3/GPX4-inhibition pathway, not
/// doxorubicin's actual mechanism (DNA intercalation, topoisomerase II).
/// Comparative kill rates between this and `rsl3_like()` reflect only
/// differences in tissue penetration depth, not drug mechanism.
pub fn doxorubicin_transport_reference() -> DrugParams {
    DrugParams {
        // Doxorubicin D ≈ 3 × 10⁻⁷ cm²/s in tissue
        // Ref: El-Kareh & Secomb 2000
        diffusion_coeff_cm2_s: 3.0e-7,
        // High uptake due to DNA binding/trapping
        uptake_rate: 0.01,
        // Moderate metabolism
        metabolism_rate: 0.002,
        // Freely permeable
        vessel_wall_conc: 1.0,
        name: "Doxorubicin-transport",
    }
}

/// Published EPR tumour accumulation for a long-circulating nanocarrier,
/// as a percentage of the injected dose per gram of tumour.
///
/// "over 5% of the injected dose per gram tumor at 48 h" for redox
/// nanoparticles in C26 tumours (PMID 29914561, `corpus/by-pmid/29914561.md`).
///
/// **This is the number a nanoparticle arm has to be honest about, and it is
/// the reason the arm is a TRANSPORT change rather than a new death route.**
/// Nanocarriers do not kill differently; they arrive differently. A few
/// percent of the injected dose reaching the tumour is simultaneously a large
/// improvement over free drug and a small absolute number, and any model
/// implying otherwise is wrong about the modality.
pub const NANOCARRIER_TUMOUR_ID_PER_G_PCT: f64 = 5.0;

/// Liposomal-nanocarrier transport profile (#797's second-largest absent
/// mechanism: 36,788 census articles, 182 trials).
///
/// A nanocarrier changes three transport quantities at once and NOTHING about
/// cell-level pharmacology, which is why this belongs here rather than as a
/// `Treatment` variant:
///
/// * **Diffusion falls by roughly an order of magnitude.** A ~100 nm liposome
///   is two to three orders of magnitude larger than a small molecule, and
///   `D` scales inversely with hydrodynamic radius (Stokes-Einstein). Taken as
///   `3e-8 cm²/s` against doxorubicin's `3e-7`.
/// * **Uptake falls**, because a carrier must be endocytosed and then release
///   its payload rather than diffusing across a membrane.
/// * **Metabolism falls**, which is the point of encapsulation: the payload
///   is protected in transit.
///
/// The NET effect is the modality's actual trade-off, and the model has to
/// show it rather than assert it: the penetration length
/// `λ = √(D/k)` can go either way, because both numerator and denominator
/// shrink. `nanocarrier_penetration_tradeoff_is_measured_not_assumed` computes
/// which way it goes instead of a comment claiming a direction.
///
/// **Transport-only, exactly like [`doxorubicin_transport_reference`].** The
/// cell-level pharmacology is still the RSL3/GPX4 pathway, so a comparison
/// between this and a free drug reflects DELIVERY and nothing else. Saying so
/// is not a caveat, it is the finding: this project's own penetration work
/// shows delivery already dominates the in-vitro-to-in-vivo gap.
pub fn liposomal_nanocarrier() -> DrugParams {
    DrugParams {
        // ~100 nm carrier: an order of magnitude below a small molecule.
        diffusion_coeff_cm2_s: 3.0e-8,
        // Endocytosis-limited rather than diffusion-limited.
        uptake_rate: 0.002,
        // Encapsulation protects the payload in transit.
        metabolism_rate: 0.0002,
        // EPR extravasation is the carrier's whole delivery mechanism and it
        // is INEFFICIENT: `NANOCARRIER_TUMOUR_ID_PER_G_PCT` of the injected
        // dose per gram. Expressed here as a fraction so the vessel-wall
        // concentration carries the published number rather than a guess.
        vessel_wall_conc: NANOCARRIER_TUMOUR_ID_PER_G_PCT / 100.0,
        name: "Liposomal-nanocarrier",
    }
}

/// Antibody-drug-conjugate transport profile (the taxonomy's highest trial
/// share: 6,019 census articles and 9.6% of them carrying a trial type).
///
/// An ADC is a ~150 kDa antibody carrying a cytotoxic payload, and its
/// transport is the OPPOSITE trade-off to the nanocarrier above. The carrier
/// buys SELECTIVITY — the antibody binds a tumour antigen — and pays for it in
/// penetration, because a full IgG diffuses roughly an order of magnitude more
/// slowly than a small molecule and BINDS the first antigen it meets.
///
/// That last part is the modality's defining problem and it is not a general
/// carrier effect: the binding-site barrier. High-affinity antibodies are
/// consumed by the perivascular cells and never reach the core, which is why
/// ADC penetration is worse than affinity alone would suggest. It appears here
/// as a HIGH uptake rate — the module's `uptake_rate` is exactly "how fast
/// cells remove drug from the interstitium", which is what antigen binding
/// does — rather than as a new term, because inventing one would assert a
/// mechanism this model cannot separate from uptake.
///
/// Diffusion is the published antibody figure this module already documents at
/// the top of [`DrugParams`]: 0.1–1 × 10⁻⁷ cm²/s for a ~150 kDa protein,
/// against 1–10 × 10⁻⁷ for a small molecule.
///
/// **Transport-only**, exactly like the two profiles beside it: the payload's
/// pharmacology is still the RSL3/GPX4 pathway, so a comparison against a free
/// drug reflects DELIVERY and nothing else. `NANOCARRIER_TUMOUR_ID_PER_G_PCT`
/// has no ADC equivalent in this project's corpus, so `vessel_wall_conc` stays
/// at the freely-permeable 1.0 rather than carrying a number nobody published
/// here — the CALIBRATION_STATUS row says which quantities are anchored and
/// which are order-of-magnitude reasoning.
pub fn antibody_drug_conjugate() -> DrugParams {
    DrugParams {
        // ~150 kDa IgG: the low end of this module's documented antibody range.
        diffusion_coeff_cm2_s: 1.0e-8,
        // The binding-site barrier: antigen binding removes drug from the
        // interstitium fast, which is why perivascular cells consume it.
        uptake_rate: 0.02,
        // Conjugation protects the payload in transit, as for the liposome.
        metabolism_rate: 0.0005,
        // No published ADC vessel-wall fraction in this corpus; left at the
        // freely-permeable default rather than guessed.
        vessel_wall_conc: 1.0,
        name: "Antibody-drug-conjugate",
    }
}

// ============================================================
// Tissue Presets
// ============================================================

/// Well-vascularized epithelial tissue (breast, lung, colorectal).
///
/// Dense capillary network, moderate permeability.
/// Inter-vessel distance ~100-150μm.
pub fn epithelial_well_vascularized() -> TissueParams {
    TissueParams {
        inter_vessel_distance_um: 120.0,
        vascular_permeability: 0.8,
        ecm_tortuosity: 1.0,
        name: "Epithelial (well-vascularized)",
    }
}

/// Poorly vascularized epithelial tissue (pancreatic, some liver).
///
/// Sparse vasculature, high interstitial fluid pressure, low permeability.
/// Inter-vessel distance ~200-300μm.
/// Ref: Olive et al., Science 2009 (pancreatic desmoplasia)
pub fn epithelial_poorly_vascularized() -> TissueParams {
    TissueParams {
        inter_vessel_distance_um: 250.0,
        vascular_permeability: 0.4,
        // Kept at identity (1.0) for byte-identity; pancreatic desmoplasia is
        // the natural candidate for tortuosity > 1 once ECM-density data exists
        // (Olive 2009; Provenzano 2012, PMID 22439937).
        ecm_tortuosity: 1.0,
        name: "Epithelial (poorly-vascularized)",
    }
}

/// CNS/neuroectodermal tissue (glioblastoma).
///
/// Blood-brain barrier severely restricts drug entry. Even disrupted BBB
/// in tumor core has much lower permeability than systemic vasculature.
/// Inter-vessel distance moderate but permeability very low.
/// Ref: Sarkaria et al., Neuro-Oncology 2018 (BBB and drug delivery)
pub fn neuroectodermal_cns() -> TissueParams {
    TissueParams {
        inter_vessel_distance_um: 150.0,
        vascular_permeability: 0.15,
        ecm_tortuosity: 1.0,
        name: "Neuroectodermal (CNS/BBB)",
    }
}

#[cfg(test)]
mod tests {

    /// The nanocarrier trade-off, MEASURED rather than asserted.
    ///
    /// A carrier changes three transport quantities at once and the net
    /// direction is not obvious: `λ = √(D/k)` has a shrinking numerator
    /// (diffusion falls with size) AND a shrinking denominator (encapsulation
    /// protects the payload). A comment claiming a direction would be a guess.
    ///
    /// It comes out NEGATIVE, and that is the field's actual tension: EPR
    /// improves tumour ACCUMULATION while size hurts intratumoral
    /// PENETRATION. The model reproduces it without being told to, which is
    /// the only kind of agreement worth reporting.
    #[test]
    fn nanocarrier_penetration_tradeoff_is_measured_not_assumed() {
        let free = doxorubicin_transport_reference();
        let carrier = liposomal_nanocarrier();
        let (l_free, l_carrier) = (
            penetration_length_um(&free),
            penetration_length_um(&carrier),
        );

        // Each input moved in the direction the doc comment claims, so the
        // net result is attributable rather than coincidental.
        assert!(carrier.diffusion_coeff_cm2_s < free.diffusion_coeff_cm2_s);
        assert!(carrier.uptake_rate < free.uptake_rate);
        assert!(carrier.metabolism_rate < free.metabolism_rate);

        assert!(
            l_carrier < l_free,
            "the carrier now penetrates FURTHER ({l_carrier:.1} um vs \
             {l_free:.1}); the trade-off the module documents has reversed \
             and the prose must be re-derived, not the test relaxed"
        );
        // And the effect is real, not a rounding difference.
        assert!(
            l_free / l_carrier > 1.2,
            "the penetration difference is {:.2}x, too small to support the \
             'delivery dominates' reading",
            l_free / l_carrier
        );
        // The other half of the trade-off: the carrier arrives at the vessel
        // wall at the PUBLISHED fraction, which is small in absolute terms.
        assert!((carrier.vessel_wall_conc - NANOCARRIER_TUMOUR_ID_PER_G_PCT / 100.0).abs() < 1e-12);
        assert!(
            carrier.vessel_wall_conc < 0.1,
            "EPR delivery is a few percent of the injected dose; a model with \
             it near 1.0 is not describing this modality"
        );
        assert!(carrier.vessel_wall_conc < free.vessel_wall_conc);
    }

    /// The four transport profiles order by CARRIER SIZE, and the ADC is the
    /// extreme -- which is the binding-site barrier, not a general carrier
    /// effect.
    ///
    /// Measured across the whole set rather than pairwise, because the claim
    /// the module makes is about an ordering and a pairwise test would let two
    /// profiles swap without noticing.
    #[test]
    fn the_transport_profiles_order_by_delivery_penalty() {
        let profiles = [
            ("RSL3-like", rsl3_like()),
            ("Doxorubicin", doxorubicin_transport_reference()),
            ("Liposomal", liposomal_nanocarrier()),
            ("ADC", antibody_drug_conjugate()),
        ];
        let lambdas: Vec<(&str, f64)> = profiles
            .iter()
            .map(|(n, d)| (*n, penetration_length_um(d)))
            .collect();
        for w in lambdas.windows(2) {
            assert!(
                w[0].1 > w[1].1,
                "{} penetrates {:.1} um and {} {:.1}; the documented ordering \
                 by carrier size has broken",
                w[0].0,
                w[0].1,
                w[1].0,
                w[1].1
            );
        }
        // The ADC is not merely last, it is an order of magnitude short of the
        // free drug -- the binding-site barrier is a different regime, not a
        // worse version of the same one.
        let (free, adc) = (lambdas[0].1, lambdas[3].1);
        assert!(
            free / adc > 10.0,
            "the ADC penetrates {adc:.1} um against the free drug's \
             {free:.1}, a ratio of {:.1}; the binding-site barrier should be \
             an order of magnitude",
            free / adc
        );
        // And it is UPTAKE that puts it there, not diffusion alone: hold
        // uptake at the free drug's value and the gap must shrink sharply.
        let mut relaxed = antibody_drug_conjugate();
        relaxed.uptake_rate = rsl3_like().uptake_rate;
        relaxed.metabolism_rate = rsl3_like().metabolism_rate;
        let relaxed_lambda = penetration_length_um(&relaxed);
        assert!(
            relaxed_lambda > adc * 1.5,
            "removing the binding-site uptake barely moved penetration \
             ({relaxed_lambda:.1} vs {adc:.1}), so the module's explanation \
             of the barrier does not match its own numbers"
        );
        // Every profile still reaches SOMEWHERE: a zero would make the
        // ordering trivially true and the model useless.
        for (n, l) in &lambdas {
            assert!(*l > 1.0, "{n} penetrates {l} um, which is not a model");
        }
    }

    /// Concentration at depth must fall for BOTH, and faster for the carrier.
    ///
    /// The penetration length alone is a summary; this is the profile the
    /// consumer actually reads.
    #[test]
    fn the_carrier_profile_falls_faster_at_every_depth() {
        let tissue = epithelial_well_vascularized();
        let free = doxorubicin_transport_reference();
        let carrier = liposomal_nanocarrier();
        let mut ratio_prev = 0.0_f64;
        for r in [10.0_f64, 25.0, 50.0, 100.0] {
            let cf = concentration_at_distance(r, &free, &tissue);
            let cc = concentration_at_distance(r, &carrier, &tissue);
            assert!(cf > 0.0 && cc > 0.0, "at {r} um");
            assert!(cc < cf, "the carrier exceeds the free drug at {r} um");
            // The GAP must widen with depth -- that is what "falls faster"
            // means, and a constant offset would satisfy `cc < cf` without it.
            let ratio = cf / cc;
            assert!(
                ratio > ratio_prev,
                "the free/carrier ratio is not growing with depth at {r} um: \
                 {ratio} vs {ratio_prev}"
            );
            ratio_prev = ratio;
        }
    }
    use super::*;

    #[test]
    fn concentration_at_vessel_wall_is_c0() {
        let drug = rsl3_like();
        let tissue = epithelial_well_vascularized();
        let c = concentration_at_distance(0.0, &drug, &tissue);
        let expected = drug.vessel_wall_conc * tissue.vascular_permeability;
        assert!(
            (c - expected).abs() < 1e-10,
            "At r=0: expected {expected}, got {c}"
        );
    }

    #[test]
    fn concentration_decays_with_distance() {
        let drug = rsl3_like();
        let tissue = epithelial_well_vascularized();
        let c_near = concentration_at_distance(10.0, &drug, &tissue);
        let c_far = concentration_at_distance(100.0, &drug, &tissue);
        assert!(
            c_far < c_near,
            "Concentration should decrease with distance"
        );
    }

    #[test]
    fn concentration_near_zero_at_large_distance() {
        let drug = rsl3_like();
        let tissue = epithelial_well_vascularized();
        let c = concentration_at_distance(1000.0, &drug, &tissue);
        assert!(
            c < 0.01,
            "Concentration at 1mm should be negligible, got {c}"
        );
    }

    #[test]
    fn penetration_length_scales_with_sqrt_d_over_k() {
        let drug1 = DrugParams {
            diffusion_coeff_cm2_s: 4.0e-7,
            uptake_rate: 0.004,
            metabolism_rate: 0.0,
            vessel_wall_conc: 1.0,
            name: "test1",
        };
        // 4× diffusion should give 2× penetration length (sqrt scaling)
        let drug2 = DrugParams {
            diffusion_coeff_cm2_s: 16.0e-7,
            ..drug1.clone()
        };
        let ratio = penetration_length_um(&drug2) / penetration_length_um(&drug1);
        assert!(
            (ratio - 2.0).abs() < 0.01,
            "λ should scale as √D: ratio={ratio}"
        );
    }

    #[test]
    fn doxorubicin_transport_penetration_matches_literature() {
        // Minchinton & Tannock 2006: doxorubicin penetrates ~40-80μm
        let drug = doxorubicin_transport_reference();
        let lambda = penetration_length_um(&drug);
        assert!(
            lambda > 30.0 && lambda < 120.0,
            "Doxorubicin transport λ should be ~50-80μm, got {lambda:.1}μm"
        );
    }

    #[test]
    fn bbb_reduces_effective_concentration() {
        let drug = rsl3_like();
        let normal = epithelial_well_vascularized();
        let cns = neuroectodermal_cns();
        let c_normal = concentration_at_distance(50.0, &drug, &normal);
        let c_cns = concentration_at_distance(50.0, &drug, &cns);
        assert!(
            c_cns < c_normal * 0.5,
            "BBB should substantially reduce concentration: normal={c_normal:.3}, cns={c_cns:.3}"
        );
    }

    #[test]
    fn profile_has_correct_length() {
        let drug = rsl3_like();
        let tissue = epithelial_well_vascularized();
        let profile = concentration_profile(&drug, &tissue, 50);
        assert_eq!(profile.len(), 50);
        assert!(
            (profile[0].0 - 0.0).abs() < 1e-10,
            "First point should be at r=0"
        );
        let r_max = max_distance_um(&tissue);
        assert!(
            (profile[49].0 - r_max).abs() < 1e-10,
            "Last point should be at r_max"
        );
    }

    #[test]
    fn zero_clearance_gives_infinite_penetration() {
        let drug = DrugParams {
            diffusion_coeff_cm2_s: 5.0e-7,
            uptake_rate: 0.0,
            metabolism_rate: 0.0,
            vessel_wall_conc: 1.0,
            name: "no-clearance",
        };
        let lambda = penetration_length_um(&drug);
        assert!(
            lambda.is_infinite(),
            "Zero clearance should give infinite penetration"
        );
    }

    #[test]
    fn ecm_tortuosity_shortens_penetration() {
        let drug = rsl3_like();
        let base = epithelial_well_vascularized(); // ecm_tortuosity = 1.0
                                                   // Identity: an explicit tortuosity of 1.0 is byte-identical to the base.
        let id = TissueParams {
            ecm_tortuosity: 1.0,
            ..epithelial_well_vascularized()
        };
        assert_eq!(
            concentration_at_distance(60.0, &drug, &base),
            concentration_at_distance(60.0, &drug, &id),
            "ecm_tortuosity = 1.0 must be the identity"
        );
        // Denser ECM (tortuosity > 1) shortens the effective penetration length,
        // so less drug reaches a cell at depth (the documented direction).
        let dense = TissueParams {
            ecm_tortuosity: 4.0,
            ..epithelial_well_vascularized()
        };
        let c_base = concentration_at_distance(60.0, &drug, &base);
        let c_dense = concentration_at_distance(60.0, &drug, &dense);
        assert!(
            c_dense < c_base,
            "ECM tortuosity must reduce drug at depth: base={c_base:.4}, dense={c_dense:.4}"
        );
        // Tortuosity only affects the decay, not the vessel-wall (r=0) value.
        assert_eq!(
            concentration_at_distance(0.0, &drug, &base),
            concentration_at_distance(0.0, &drug, &dense),
            "tortuosity must not change the vessel-wall concentration (r=0)"
        );
    }
}
