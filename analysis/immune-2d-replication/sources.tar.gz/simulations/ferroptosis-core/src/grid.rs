//! Tumor grids for the spatial simulation.
//!
//! Provides tumor architecture generation, neighbor iteration, and iron
//! diffusion. The 2D model ([`TumorGrid`], 8-Moore neighbors, circular
//! tumor) is the established default used by `sim-spatial` and `sim-tme`.
//! The 3D model ([`TumorGrid3D`], 26-Moore neighbors, spherical tumor)
//! provides foundational infrastructure for the spheroid-validation series
//! (#185–#197). #185 (struct) and #186 (signed radial depth + paired 3D
//! energy-physics dispatcher in [`crate::physics`]) are landed; the consuming
//! binary is `sim-tme-3d` (#195), which carries the downstream analytics
//! (volumetric heatmaps, zone census). The standalone sim-spatial-3d (#194)
//! was closed as superseded.

use ndarray::Array2;
use rand::prelude::*;
use serde::Serialize;

use crate::biochem::CellState;
use crate::cell::{gen_cell, Cell, Phenotype};

/// Fraction of the smallest grid dimension used for the tumor sphere/circle
/// radius (in lattice cells). Shared by [`TumorGrid3D::generate`] and
/// [`TumorGrid3D::radial_depth_um`] so geometry stays in sync — changing
/// this value moves both the generated tumor and the depth-from-surface
/// reference together. (The 2D [`TumorGrid::generate`] uses the same
/// numeric value inline; if it ever needs to vary independently we can
/// split the constants.)
///
/// **Public**: downstream binaries (sim-tme-3d) compute
/// `tumor_radius_um = grid_dim × TUMOR_RADIUS_FRACTION × cell_size_um`
/// for output metadata; exporting the constant prevents the drift hazard
/// of binaries hardcoding a stale `0.45` literal that diverges from the
/// generated geometry.
pub const TUMOR_RADIUS_FRACTION: f64 = 0.45;

/// A single cell in the spatial grid.
#[derive(Clone, Debug, Serialize)]
pub struct GridCell {
    pub cell: Cell,
    pub phenotype: Phenotype,
    pub state: CellState,
    pub is_tumor: bool,
    /// Extra iron from neighbor deaths, accumulated between timesteps.
    pub extra_iron: f64,
    /// LP captured at the end of the post-death grace period (for DAMP
    /// calculation). The value is read `post_death_steps` after a cell dies,
    /// not at the instant of death, so it is named for the grace-end (renamed
    /// from the misleading `lp_at_death` in #314).
    pub lp_at_grace_end: f64,
    /// Whether this cell just died this step (for diffusion).
    pub newly_dead: bool,
}

/// 2D tumor grid.
pub struct TumorGrid {
    pub cells: Vec<GridCell>,
    pub rows: usize,
    pub cols: usize,
    pub cell_size_um: f64,
}

impl TumorGrid {
    /// Generate a heterogeneous tumor grid.
    ///
    /// Layout:
    /// - Circular tumor centered in grid
    /// - Core (inner 60%): Glycolytic 80%, OXPHOS 15%, Persister 5%
    /// - Periphery (outer 40%): OXPHOS 70%, Glycolytic 20%, Persister 8%, PersisterNrf2 2%
    /// - 10-20 persister cluster seeds scattered throughout
    /// - Border: Stromal cells
    pub fn generate(rows: usize, cols: usize, cell_size_um: f64, seed: u64) -> Self {
        let mut rng = StdRng::seed_from_u64(seed);
        let center_r = rows as f64 / 2.0;
        let center_c = cols as f64 / 2.0;
        let tumor_radius = (rows.min(cols) as f64) * 0.45;
        let core_radius = tumor_radius * 0.6;

        // Generate persister cluster centers
        let n_clusters = 10 + (rng.gen_range(0..11) as usize);
        let cluster_centers: Vec<(f64, f64)> = (0..n_clusters)
            .map(|_| {
                let angle = rng.gen::<f64>() * std::f64::consts::TAU;
                let dist = rng.gen::<f64>().sqrt() * tumor_radius * 0.9;
                (center_r + angle.sin() * dist, center_c + angle.cos() * dist)
            })
            .collect();
        let cluster_radius = 4.0; // cells

        let mut cells = Vec::with_capacity(rows * cols);

        for r in 0..rows {
            for c in 0..cols {
                let dr = r as f64 - center_r;
                let dc = c as f64 - center_c;
                let dist = (dr * dr + dc * dc).sqrt();

                // Check if in a persister cluster
                let in_cluster = cluster_centers.iter().any(|(cr, cc)| {
                    let d = ((r as f64 - cr).powi(2) + (c as f64 - cc).powi(2)).sqrt();
                    d <= cluster_radius
                });

                let (phenotype, is_tumor) = if dist > tumor_radius {
                    (Phenotype::Stromal, false)
                } else if in_cluster {
                    // Persister clusters are pure persister
                    (Phenotype::Persister, true)
                } else if dist <= core_radius {
                    // Core: mostly glycolytic
                    let roll: f64 = rng.gen();
                    if roll < 0.80 {
                        (Phenotype::Glycolytic, true)
                    } else if roll < 0.95 {
                        (Phenotype::OXPHOS, true)
                    } else {
                        (Phenotype::Persister, true)
                    }
                } else {
                    // Periphery: mostly OXPHOS
                    let roll: f64 = rng.gen();
                    if roll < 0.70 {
                        (Phenotype::OXPHOS, true)
                    } else if roll < 0.90 {
                        (Phenotype::Glycolytic, true)
                    } else if roll < 0.98 {
                        (Phenotype::Persister, true)
                    } else {
                        (Phenotype::PersisterNrf2, true)
                    }
                };

                let cell = gen_cell(phenotype, &mut rng);
                // State will be initialized later when treatment is applied
                let state = CellState {
                    gsh: cell.gsh,
                    gpx4: cell.gpx4,
                    fsp1: cell.fsp1,
                    mufa_protection: 0.0,
                    lp: 0.0,
                    dead: false,
                    death_step: None,
                    exo_ros_peak: 0.0,
                    persister_fraction: 0.0,
                    persister_reversible: 0.0,
                    persister_locked: 0.0,
                    persister_cum_exposure: 0.0,
                    escrt_budget_used: 0.0,
                };

                cells.push(GridCell {
                    cell,
                    phenotype,
                    state,
                    is_tumor,
                    extra_iron: 0.0,
                    lp_at_grace_end: 0.0,
                    newly_dead: false,
                });
            }
        }

        TumorGrid {
            cells,
            rows,
            cols,
            cell_size_um,
        }
    }

    /// Access cell at (row, col).
    #[inline]
    pub fn get(&self, r: usize, c: usize) -> &GridCell {
        &self.cells[r * self.cols + c]
    }

    /// Mutable access to cell at (row, col).
    #[inline]
    pub fn get_mut(&mut self, r: usize, c: usize) -> &mut GridCell {
        &mut self.cells[r * self.cols + c]
    }

    /// Signed radial depth from the disc surface in micrometers.
    ///
    /// `depth = (tumor_radius_lattice − distance_from_center) × cell_size_um`
    ///
    /// 2D analog of [`TumorGrid3D::radial_depth_um`]. **Positive inside
    /// the disc, negative outside, zero at the surface.** No `.max(0.0)`
    /// — clamping is a caller concern (sim-tme's `compute_depth_map`
    /// applies it after this call).
    ///
    /// **Geometry:** matches [`TumorGrid::generate`] — disc center at
    /// `(rows/2, cols/2)` (lattice-centered, no voxel offset),
    /// `tumor_radius = min(rows, cols) × TUMOR_RADIUS_FRACTION`. Both
    /// `generate` and this method share the same constant so the
    /// generated geometry and the depth-from-surface reference can't
    /// drift.
    ///
    /// **Not bounds-checked:** matching [`get`](Self::get)'s contract,
    /// the caller is expected to pass `(r, c)` within the grid.
    /// Out-of-range indices give nonsense distances but won't panic.
    /// Matches the 3D analog [`TumorGrid3D::radial_depth_um`]'s contract.
    ///
    /// **Perf note (mirrors 3D analog):** the three constants
    /// `center_{r,c}` and `tumor_radius` depend only on grid
    /// dimensions and are recomputed every call. `#[inline]` lets the
    /// compiler hoist them at a single call site, but a per-cell
    /// sweep over hundreds of thousands of cells should precompute
    /// them once outside the loop (or store them on the struct) to
    /// avoid `usize::min` + cast + multiply per cell. Cheap to
    /// address when a consumer needs it.
    #[inline]
    pub fn radial_depth_um(&self, r: usize, c: usize) -> f64 {
        let center_r = self.rows as f64 / 2.0;
        let center_c = self.cols as f64 / 2.0;
        let tumor_radius = (self.rows.min(self.cols) as f64) * TUMOR_RADIUS_FRACTION;
        let dr = r as f64 - center_r;
        let dc = c as f64 - center_c;
        let dist = (dr * dr + dc * dc).sqrt();
        (tumor_radius - dist) * self.cell_size_um
    }

    /// Return indices of Moore neighborhood (8-neighbors) for cell (r, c).
    /// Respects grid boundaries (no wrapping).
    /// Returns (array, count) — use `&result[..count]` to iterate.
    /// Zero-allocation: uses a stack-allocated fixed-size array.
    pub fn neighbors(&self, r: usize, c: usize) -> ([(usize, usize); 8], usize) {
        let mut result = [(0usize, 0usize); 8];
        let mut count = 0;
        for dr in [-1_i64, 0, 1] {
            for dc in [-1_i64, 0, 1] {
                if dr == 0 && dc == 0 {
                    continue;
                }
                let nr = r as i64 + dr;
                let nc = c as i64 + dc;
                if nr >= 0 && nr < self.rows as i64 && nc >= 0 && nc < self.cols as i64 {
                    result[count] = (nr as usize, nc as usize);
                    count += 1;
                }
            }
        }
        (result, count)
    }

    /// Distribute iron from newly dead cells to their living neighbors.
    /// Each living neighbor receives `neighbor_iron_fraction` of the released iron.
    pub fn diffuse_iron(&mut self, iron_per_death: f64, neighbor_fraction: f64) {
        // Collect positions of newly dead cells
        let dead_positions: Vec<(usize, usize)> = (0..self.rows)
            .flat_map(|r| (0..self.cols).map(move |c| (r, c)))
            .filter(|&(r, c)| self.get(r, c).newly_dead)
            .collect();

        // Distribute iron to living neighbors
        for (r, c) in dead_positions {
            let (neighbors, count) = self.neighbors(r, c);
            for &(nr, nc) in &neighbors[..count] {
                let neighbor = self.get_mut(nr, nc);
                if !neighbor.state.dead {
                    neighbor.extra_iron += iron_per_death * neighbor_fraction;
                }
            }
            // Clear newly_dead flag
            self.get_mut(r, c).newly_dead = false;
        }
    }

    /// Count cells by phenotype and alive/dead status.
    pub fn census(&self) -> GridCensus {
        let mut census = GridCensus::default();
        for gc in &self.cells {
            if !gc.is_tumor {
                census.stromal += 1;
                continue;
            }
            census.total_tumor += 1;
            if gc.state.dead {
                census.total_dead += 1;
                match gc.phenotype {
                    Phenotype::Glycolytic => census.glycolytic_dead += 1,
                    Phenotype::OXPHOS => census.oxphos_dead += 1,
                    Phenotype::Persister => census.persister_dead += 1,
                    Phenotype::PersisterNrf2 => census.persister_nrf2_dead += 1,
                    Phenotype::Stromal => {}
                }
            }
            match gc.phenotype {
                Phenotype::Glycolytic => census.glycolytic += 1,
                Phenotype::OXPHOS => census.oxphos += 1,
                Phenotype::Persister => census.persister += 1,
                Phenotype::PersisterNrf2 => census.persister_nrf2 += 1,
                Phenotype::Stromal => {}
            }
        }
        census
    }
}

/// Summary statistics of grid composition.
#[derive(Default, Debug, serde::Serialize)]
pub struct GridCensus {
    pub total_tumor: usize,
    pub total_dead: usize,
    pub stromal: usize,
    pub glycolytic: usize,
    pub glycolytic_dead: usize,
    pub oxphos: usize,
    pub oxphos_dead: usize,
    pub persister: usize,
    pub persister_dead: usize,
    pub persister_nrf2: usize,
    pub persister_nrf2_dead: usize,
}

/// Compute death rate by depth (row).
/// Returns Vec of (depth_um, death_rate, total_cells) for each row.
pub fn depth_kill_curve(grid: &TumorGrid) -> Vec<(f64, f64, usize)> {
    (0..grid.rows)
        .map(|r| {
            let depth_um = r as f64 * grid.cell_size_um;
            let mut total = 0usize;
            let mut dead = 0usize;
            for c in 0..grid.cols {
                let gc = grid.get(r, c);
                if gc.is_tumor {
                    total += 1;
                    if gc.state.dead {
                        dead += 1;
                    }
                }
            }
            let rate = if total > 0 {
                dead as f64 / total as f64
            } else {
                0.0
            };
            (depth_um, rate, total)
        })
        .collect()
}

/// Export death map as a 2D array (0 = alive/stromal, 1 = dead tumor, 2 = alive tumor).
pub fn death_heatmap(grid: &TumorGrid) -> Array2<u8> {
    Array2::from_shape_fn((grid.rows, grid.cols), |(r, c)| {
        let gc = grid.get(r, c);
        if !gc.is_tumor {
            0
        } else if gc.state.dead {
            1
        } else {
            2
        }
    })
}

// =====================================================================
// 3D tumor grid (#185 foundational infrastructure for spheroid modeling)
// =====================================================================

/// 3D tumor grid — additive analog of [`TumorGrid`] with the same
/// `GridCell` element type, spherical tumor geometry, and 26-Moore
/// neighbors.
///
/// **Design choice:** This is a new struct rather than extending
/// `TumorGrid` with an optional z-dimension. The decision is documented
/// in #185 — 2D physics, 2D test snapshots, and all 2D consumers
/// (sim-spatial, sim-tme) keep their existing `TumorGrid` semantics
/// bit-for-bit. The two types share `GridCell` and `GridCensus`; any
/// common abstraction can land as a trait when patterns emerge.
///
/// **Memory (measured, #192):** `size_of::<GridCell>() = 144 B`. Peak
/// process RSS for a sim-tme-3d run: 100³ ≈ 163 MB, 150³ ≈ 546 MB,
/// 200³ ≈ 1.29 GB (dense — fits the 2 GB budget with headroom). Tests
/// use ≤ 20³. See sim-tme-3d's `--bench` + the README "Performance &
/// scalability" section.
///
/// **Storage:** flat `Vec<GridCell>` indexed as
/// `r * cols * layers + c * layers + l` — row-major (C-order) with
/// strides `(cols*layers, layers, 1)`. The `l` axis has stride 1, so
/// `for r { for c { for l { ... } } }` is cache-friendly. Extends
/// `TumorGrid`'s row-major `r * cols + c` to a third dimension.
pub struct TumorGrid3D {
    pub cells: Vec<GridCell>,
    pub rows: usize,
    pub cols: usize,
    pub layers: usize,
    pub cell_size_um: f64,
}

impl TumorGrid3D {
    /// Generate a heterogeneous spherical tumor grid (3D analog of
    /// [`TumorGrid::generate`]).
    ///
    /// Layout:
    /// - Spherical tumor centered in `(rows/2, cols/2, layers/2)` with
    ///   radius = `min(rows, cols, layers) * TUMOR_RADIUS_FRACTION`
    ///   (currently 0.45; same constant used by
    ///   [`TumorGrid3D::radial_depth_um`])
    /// - Core (inner 60% of tumor radius): Glycolytic 80%, OXPHOS 15%, Persister 5%
    /// - Periphery (outer 40%): OXPHOS 70%, Glycolytic 20%, Persister 8%, PersisterNrf2 2%
    /// - 10–20 persister cluster seeds scattered uniformly by volume
    /// - Outside tumor sphere: Stromal cells
    ///
    /// Deterministic from `seed`.
    ///
    /// **Geometry:** cell positions are lattice-centered (`r` etc. are
    /// treated as continuous coords with no `+ 0.5` voxel offset), so
    /// the cell at `(rows/2, cols/2, layers/2)` sits exactly at the
    /// sphere center when dimensions are even. Same convention as
    /// `TumorGrid::generate`.
    ///
    /// **Memory (measured, #192):** `size_of::<GridCell>() = 144 B`; a
    /// `100³` grid run peaks ≈ 163 MB RSS, `200³` ≈ 1.29 GB (dense, under
    /// the 2 GB budget). Callers should size against available RAM before
    /// invoking; `debug_assert!` guards against accidental allocations
    /// above ~1 G cells (≈ 144 GB, almost certainly a typo).
    pub fn generate(rows: usize, cols: usize, layers: usize, cell_size_um: f64, seed: u64) -> Self {
        // Memory guard — catches "rows = 1000" typos in tests and CI.
        // Active only in debug builds; release callers are expected to
        // size against their own hardware. 10^9 cells × 144 B ≈ 144 GB
        // is well past any realistic spheroid sim and almost certainly
        // an off-by-orders-of-magnitude error.
        //
        // `saturating_mul` is used here (not for the caller's benefit) to
        // avoid `usize` wraparound on hostile inputs that could make the
        // check pass when it shouldn't.
        let total_cells = rows.saturating_mul(cols).saturating_mul(layers);
        debug_assert!(
            total_cells <= 1_000_000_000,
            "TumorGrid3D::generate: rows*cols*layers = {total_cells} exceeds 1e9 — likely a typo"
        );
        let mut rng = StdRng::seed_from_u64(seed);
        let center_r = rows as f64 / 2.0;
        let center_c = cols as f64 / 2.0;
        let center_l = layers as f64 / 2.0;
        let tumor_radius = (rows.min(cols).min(layers) as f64) * TUMOR_RADIUS_FRACTION;
        let core_radius = tumor_radius * 0.6;

        // Generate persister cluster centers uniformly distributed by
        // *volume* inside the tumor. Spherical-coordinate sampling:
        //   θ ~ U(0, 2π)              (azimuth)
        //   cos(φ) ~ U(-1, 1)         (polar; uniform-area on sphere)
        //   r = cbrt(U(0, 1)) * R     (uniform-volume in ball)
        // Without the cbrt, samples bias toward the center (analogous to
        // 2D where sqrt(rand) gives uniform-area; cbrt(rand) is 3D's
        // uniform-volume).
        //
        // Axis convention: `r` is the polar (vertical) axis, `(c, l)` form
        // the azimuthal plane. So a cluster at φ = 0 sits on the r axis
        // (highest row offset), and θ rotates within the (c, l) plane.
        // Choice is arbitrary; documented here because the asymmetric
        // r vs c/l usage is non-obvious from the math.
        let n_clusters = 10 + (rng.gen_range(0..11) as usize);
        let cluster_centers: Vec<(f64, f64, f64)> = (0..n_clusters)
            .map(|_| {
                let theta = rng.gen::<f64>() * std::f64::consts::TAU;
                let cos_phi = 1.0 - 2.0 * rng.gen::<f64>();
                let sin_phi = (1.0 - cos_phi * cos_phi).sqrt();
                let dist = rng.gen::<f64>().cbrt() * tumor_radius * 0.9;
                (
                    center_r + dist * cos_phi,
                    center_c + dist * sin_phi * theta.cos(),
                    center_l + dist * sin_phi * theta.sin(),
                )
            })
            .collect();
        // cluster_radius=4.0 cells gives ~268 cells per cluster in 3D
        // (4/3·π·4³) vs ~50 in 2D (π·4²), so persister clusters are ~5x
        // larger relative to tumor volume than the 2D analog. A
        // volume-equivalent retune (cluster_radius ~= 4·(50/268)^(1/3) ~= 2.4,
        // giving ~50 cells/cluster) would keep the 2D/3D census proportions
        // comparable. Left at 4.0 for v1 to match the 2D code shape literally;
        // the retune is a deliberate matrix change tracked in #311 (#194 /
        // sim-spatial-3d was closed as superseded by sim-tme-3d).
        let cluster_radius = 4.0;

        let mut cells = Vec::with_capacity(rows * cols * layers);

        for r in 0..rows {
            for c in 0..cols {
                for l in 0..layers {
                    let dr = r as f64 - center_r;
                    let dc = c as f64 - center_c;
                    let dl = l as f64 - center_l;
                    let dist = (dr * dr + dc * dc + dl * dl).sqrt();

                    let in_cluster = cluster_centers.iter().any(|(cr, cc, cl)| {
                        let d = ((r as f64 - cr).powi(2)
                            + (c as f64 - cc).powi(2)
                            + (l as f64 - cl).powi(2))
                        .sqrt();
                        d <= cluster_radius
                    });

                    let (phenotype, is_tumor) = if dist > tumor_radius {
                        (Phenotype::Stromal, false)
                    } else if in_cluster {
                        (Phenotype::Persister, true)
                    } else if dist <= core_radius {
                        let roll: f64 = rng.gen();
                        if roll < 0.80 {
                            (Phenotype::Glycolytic, true)
                        } else if roll < 0.95 {
                            (Phenotype::OXPHOS, true)
                        } else {
                            (Phenotype::Persister, true)
                        }
                    } else {
                        let roll: f64 = rng.gen();
                        if roll < 0.70 {
                            (Phenotype::OXPHOS, true)
                        } else if roll < 0.90 {
                            (Phenotype::Glycolytic, true)
                        } else if roll < 0.98 {
                            (Phenotype::Persister, true)
                        } else {
                            (Phenotype::PersisterNrf2, true)
                        }
                    };

                    let cell = gen_cell(phenotype, &mut rng);
                    let state = CellState {
                        gsh: cell.gsh,
                        gpx4: cell.gpx4,
                        fsp1: cell.fsp1,
                        mufa_protection: 0.0,
                        lp: 0.0,
                        dead: false,
                        death_step: None,
                        exo_ros_peak: 0.0,
                        persister_fraction: 0.0,
                        persister_reversible: 0.0,
                        persister_locked: 0.0,
                        persister_cum_exposure: 0.0,
                        escrt_budget_used: 0.0,
                    };
                    cells.push(GridCell {
                        cell,
                        phenotype,
                        state,
                        is_tumor,
                        extra_iron: 0.0,
                        lp_at_grace_end: 0.0,
                        newly_dead: false,
                    });
                }
            }
        }

        TumorGrid3D {
            cells,
            rows,
            cols,
            layers,
            cell_size_um,
        }
    }

    /// Generate an all-tumor **slab** block (#240, Option A): every cell is
    /// tumor (no spheroid surface, no stromal border), representing a chunk of
    /// bulk tumor at some depth in a larger virtual tumor. Phenotypes follow
    /// the bulk "core" mix (glycolytic-dominant, no spatial clusters / radial
    /// structure). The consumer (sim-tme-3d slab mode) layers a planar
    /// depth-graded O2/drug supply on top to represent the slab's depth.
    ///
    /// Distinct from [`generate`](Self::generate) (which carves a sphere); only
    /// reached in the opt-in slab mode, so the default matrix is unaffected.
    pub fn generate_slab(
        rows: usize,
        cols: usize,
        layers: usize,
        cell_size_um: f64,
        seed: u64,
    ) -> Self {
        let total_cells = rows.saturating_mul(cols).saturating_mul(layers);
        debug_assert!(
            total_cells <= 1_000_000_000,
            "TumorGrid3D::generate_slab: rows*cols*layers = {total_cells} exceeds 1e9 — likely a typo"
        );
        let mut rng = StdRng::seed_from_u64(seed);
        let mut cells = Vec::with_capacity(total_cells);
        for _ in 0..total_cells {
            // Bulk-tumor phenotype mix (the `generate` core distribution).
            let roll: f64 = rng.gen();
            let phenotype = if roll < 0.80 {
                Phenotype::Glycolytic
            } else if roll < 0.95 {
                Phenotype::OXPHOS
            } else {
                Phenotype::Persister
            };
            let cell = gen_cell(phenotype, &mut rng);
            let state = CellState {
                gsh: cell.gsh,
                gpx4: cell.gpx4,
                fsp1: cell.fsp1,
                mufa_protection: 0.0,
                lp: 0.0,
                dead: false,
                death_step: None,
                exo_ros_peak: 0.0,
                persister_fraction: 0.0,
                persister_reversible: 0.0,
                persister_locked: 0.0,
                persister_cum_exposure: 0.0,
                escrt_budget_used: 0.0,
            };
            cells.push(GridCell {
                cell,
                phenotype,
                state,
                is_tumor: true,
                extra_iron: 0.0,
                lp_at_grace_end: 0.0,
                newly_dead: false,
            });
        }
        TumorGrid3D {
            cells,
            rows,
            cols,
            layers,
            cell_size_um,
        }
    }

    /// Flat index into `cells` for `(r, c, l)`. Canonical source of
    /// truth for the row-major (C-order) storage layout
    /// `r·cols·layers + c·layers + l` with strides `(cols·layers, layers, 1)`.
    ///
    /// External modules ([`crate::stromal`] etc.) that need to write into
    /// a `Vec<T>` of length `cells.len()` aligned with `cells` should use
    /// this method rather than reimplementing the formula — same
    /// silent-divergence concern as [`TUMOR_RADIUS_FRACTION`]. If the
    /// storage layout ever changes (layer-major, padding, etc.), only
    /// this one method needs updating.
    ///
    /// **Not bounds-checked** (matches `get`/`get_mut` convention).
    #[inline]
    pub fn flat_index(&self, r: usize, c: usize, l: usize) -> usize {
        r * self.cols * self.layers + c * self.layers + l
    }

    /// Inverse of [`flat_index`](Self::flat_index): map a flat cell index
    /// back to `(row, col, layer)`. Row-major layout, so this and
    /// `flat_index` must change together. Not bounds-checked.
    #[inline]
    pub fn coords(&self, idx: usize) -> (usize, usize, usize) {
        let l = idx % self.layers;
        let c = (idx / self.layers) % self.cols;
        let r = idx / (self.cols * self.layers);
        (r, c, l)
    }

    /// Access cell at (row, col, layer).
    #[inline]
    pub fn get(&self, r: usize, c: usize, l: usize) -> &GridCell {
        &self.cells[self.flat_index(r, c, l)]
    }

    /// Mutable access to cell at (row, col, layer).
    #[inline]
    pub fn get_mut(&mut self, r: usize, c: usize, l: usize) -> &mut GridCell {
        let idx = self.flat_index(r, c, l);
        &mut self.cells[idx]
    }

    /// Return indices of 3D Moore neighborhood (26-neighbors) for cell
    /// (r, c, l). Respects grid boundaries (no wrapping). Zero-allocation:
    /// uses a stack-allocated fixed-size array. Use `&result[..count]`
    /// to iterate.
    ///
    /// Counts by position type:
    /// - Interior cell: 26 neighbors (3³ − 1)
    /// - Face cell (one coordinate at the boundary): 17 (2·3·3 − 1)
    /// - Face-edge cell (two coordinates at boundary): 11 (2·2·3 − 1)
    /// - Corner cell (all three at boundary): 7 (2³ − 1)
    pub fn neighbors(&self, r: usize, c: usize, l: usize) -> ([(usize, usize, usize); 26], usize) {
        let mut result = [(0usize, 0usize, 0usize); 26];
        let mut count = 0;
        for dr in [-1_i64, 0, 1] {
            for dc in [-1_i64, 0, 1] {
                for dl in [-1_i64, 0, 1] {
                    if dr == 0 && dc == 0 && dl == 0 {
                        continue;
                    }
                    let nr = r as i64 + dr;
                    let nc = c as i64 + dc;
                    let nl = l as i64 + dl;
                    if nr >= 0
                        && nr < self.rows as i64
                        && nc >= 0
                        && nc < self.cols as i64
                        && nl >= 0
                        && nl < self.layers as i64
                    {
                        result[count] = (nr as usize, nc as usize, nl as usize);
                        count += 1;
                    }
                }
            }
        }
        (result, count)
    }

    /// Distribute iron from newly dead cells to their living neighbors.
    /// Each living neighbor receives `neighbor_fraction` of the released
    /// iron.
    ///
    /// **Note for callers:** 2D `TumorGrid::diffuse_iron` uses
    /// `neighbor_fraction = 0.1` against 8 Moore neighbors, so up to 80%
    /// of released iron is distributed. In 3D with 26 Moore neighbors,
    /// the same `0.1` would distribute up to 260% — non-physical. The
    /// natural 3D analog is `0.1 * 8 / 26 ≈ 0.0308`, but the actual value is
    /// left to the caller (sim-tme-3d uses `IRON_DIFFUSE_FRACTION_3D`; #194 was
    /// closed as superseded). It is uncalibrated; see
    /// `simulations/calibration/CALIBRATION_STATUS.md` for the per-layer
    /// calibration-tier framework.
    pub fn diffuse_iron(&mut self, iron_per_death: f64, neighbor_fraction: f64) {
        // Hoist dimensions so the closures don't try to capture `&mut self`.
        let (rows, cols, layers) = (self.rows, self.cols, self.layers);
        let dead_positions: Vec<(usize, usize, usize)> = (0..rows)
            .flat_map(|r| (0..cols).flat_map(move |c| (0..layers).map(move |l| (r, c, l))))
            .filter(|&(r, c, l)| self.get(r, c, l).newly_dead)
            .collect();

        for (r, c, l) in dead_positions {
            let (neighbors, count) = self.neighbors(r, c, l);
            for &(nr, nc, nl) in &neighbors[..count] {
                let neighbor = self.get_mut(nr, nc, nl);
                if !neighbor.state.dead {
                    neighbor.extra_iron += iron_per_death * neighbor_fraction;
                }
            }
            self.get_mut(r, c, l).newly_dead = false;
        }
    }

    /// Count cells by phenotype and alive/dead status. Reuses
    /// [`GridCensus`] from the 2D model.
    pub fn census(&self) -> GridCensus {
        let mut census = GridCensus::default();
        for gc in &self.cells {
            if !gc.is_tumor {
                census.stromal += 1;
                continue;
            }
            census.total_tumor += 1;
            if gc.state.dead {
                census.total_dead += 1;
                match gc.phenotype {
                    Phenotype::Glycolytic => census.glycolytic_dead += 1,
                    Phenotype::OXPHOS => census.oxphos_dead += 1,
                    Phenotype::Persister => census.persister_dead += 1,
                    Phenotype::PersisterNrf2 => census.persister_nrf2_dead += 1,
                    Phenotype::Stromal => {}
                }
            }
            match gc.phenotype {
                Phenotype::Glycolytic => census.glycolytic += 1,
                Phenotype::OXPHOS => census.oxphos += 1,
                Phenotype::Persister => census.persister += 1,
                Phenotype::PersisterNrf2 => census.persister_nrf2 += 1,
                Phenotype::Stromal => {}
            }
        }
        census
    }

    /// Signed radial depth from the spheroid surface in micrometers.
    ///
    /// `depth = (tumor_radius_lattice − distance_from_center) × cell_size_um`
    ///
    /// Sign convention: **positive inside the sphere, negative outside, zero
    /// at the surface.** The deepest interior cell has the largest positive
    /// value (the sphere center); cells far from the tumor (corners of the
    /// bounding box) return negative values.
    ///
    /// **Geometry:** matches [`TumorGrid3D::generate`] — sphere center at
    /// `(rows/2, cols/2, layers/2)`, lattice-centered coords (no voxel
    /// offset), and `tumor_radius = min(rows, cols, layers) × TUMOR_RADIUS_FRACTION`
    /// (both `generate` and this method share the same constant, so the
    /// generated geometry and the depth-from-surface reference can't drift).
    ///
    /// **Intended use:** pair with [`crate::physics::local_ros_multiplier_3d`]
    /// for spheroid PDT/SDT energy deposition.
    ///
    /// **Physical caveat — first-order nearest-surface approximation.** This
    /// returns the *radial* depth from the spheroid surface, which models
    /// energy entering from the nearest surface point and attenuating along
    /// a 1-D radial path. That is the standard first-order approximation
    /// used in spheroid PDT/SDT models, but it is **not** the exact fluence
    /// profile for isotropic surface illumination: a full solution would
    /// integrate chord-length contributions from every surface point and
    /// account for diffuse back-scatter buildup near the boundary (which
    /// can push near-surface fluence above `I₀`). For uncalibrated v1
    /// modelling this is fine; calibration against experimental depth-kill
    /// curves is data-gated (see `simulations/calibration/CALIBRATION_STATUS.md`;
    /// #194 was closed as superseded by sim-tme-3d).
    ///
    /// **Not yet bounds-checked:** caller is expected to pass `(r, c, l)`
    /// within the grid (matching the no-bounds-check convention of
    /// [`get`](Self::get) and [`get_mut`](Self::get_mut)). Out-of-range
    /// indices give nonsense distances but won't panic.
    ///
    /// **Perf note (#289):** the four dimension-only constants (`center_{r,c,l}`,
    /// `tumor_radius`) used to be recomputed on every call. A per-cell sweep
    /// (the `oxygen`/`ph` radial fields over ~10⁵ to 10⁶ cells) now hoists them
    /// once via [`RadialDepthGeom`], which this method delegates to, so the
    /// geometry math lives in exactly one place and the hoisted field loops
    /// stay bit-for-bit identical to calling this per cell. (Re-homed from the
    /// now-closed #194; was previously deferred to sim-spatial-3d.)
    #[inline]
    pub fn radial_depth_um(&self, r: usize, c: usize, l: usize) -> f64 {
        RadialDepthGeom::new(self).depth_um(r, c, l)
    }
}

/// Hoisted geometry for the 3D radial-depth field (#289). The four
/// dimension-only constants (`center_{r,c,l}`, `tumor_radius`) plus
/// `cell_size_um` are computed **once** in [`new`](Self::new); [`depth_um`]
/// then does only the per-cell arithmetic. A per-cell sweep builds this once
/// outside the loop instead of recomputing the constants every call.
///
/// **Byte-identity:** [`depth_um`] performs the exact same operations, in the
/// same order, as [`TumorGrid3D::radial_depth_um`] (which delegates here), so
/// hoisting it changes timing only, never a single output bit. The
/// `summary.json` matrix is unaffected.
#[derive(Clone, Copy, Debug)]
pub(crate) struct RadialDepthGeom {
    center_r: f64,
    center_c: f64,
    center_l: f64,
    tumor_radius: f64,
    cell_size_um: f64,
}

impl RadialDepthGeom {
    /// Compute the dimension-only geometry constants once for `grid`.
    #[inline]
    pub(crate) fn new(grid: &TumorGrid3D) -> Self {
        RadialDepthGeom {
            center_r: grid.rows as f64 / 2.0,
            center_c: grid.cols as f64 / 2.0,
            center_l: grid.layers as f64 / 2.0,
            tumor_radius: (grid.rows.min(grid.cols).min(grid.layers) as f64)
                * TUMOR_RADIUS_FRACTION,
            cell_size_um: grid.cell_size_um,
        }
    }

    /// Radial depth (µm, positive inside) of cell `(r, c, l)`: the per-cell
    /// arithmetic only. Identical float ops/order to
    /// [`TumorGrid3D::radial_depth_um`].
    #[inline]
    pub(crate) fn depth_um(&self, r: usize, c: usize, l: usize) -> f64 {
        let dr = r as f64 - self.center_r;
        let dc = c as f64 - self.center_c;
        let dl = l as f64 - self.center_l;
        let dist = (dr * dr + dc * dc + dl * dl).sqrt();
        (self.tumor_radius - dist) * self.cell_size_um
    }
}

#[cfg(test)]
mod tests_3d {
    use super::*;

    /// Index round-trip at several positions including corners and the
    /// last cell. Catches off-by-one in `r * cols * layers + c * layers + l`.
    #[test]
    fn index_round_trip() {
        let g = TumorGrid3D::generate(5, 7, 11, 20.0, 42);
        // Probe diverse positions.
        let probes: &[(usize, usize, usize)] = &[
            (0, 0, 0),
            (4, 6, 10), // last cell
            (2, 3, 5),  // interior
            (0, 6, 0),  // edge
            (4, 0, 10), // opposite corner
        ];
        for &(r, c, l) in probes {
            let flat_manual = r * g.cols * g.layers + c * g.layers + l;
            let flat_method = g.flat_index(r, c, l);
            assert_eq!(
                flat_manual, flat_method,
                "flat_index({r},{c},{l}) diverged from inline formula"
            );
            assert_eq!(
                &g.cells[flat_method] as *const _,
                g.get(r, c, l) as *const _,
                "(r={r}, c={c}, l={l}) → flat={flat_method} doesn't round-trip"
            );
        }
        // Total cell count matches.
        assert_eq!(g.cells.len(), 5 * 7 * 11);
    }

    /// 26-Moore neighbor counts by position type. The exact counts catch
    /// boundary off-by-ones in any direction.
    #[test]
    fn neighbor_counts_at_boundary_types() {
        let g = TumorGrid3D::generate(5, 5, 5, 20.0, 42);

        // Interior (all three coords strictly inside): 26
        let (_, n_interior) = g.neighbors(2, 2, 2);
        assert_eq!(n_interior, 26, "interior cell should have 26 neighbors");

        // Face (one coord on boundary, others interior): 17 = 2·3·3 − 1
        let (_, n_face) = g.neighbors(0, 2, 2);
        assert_eq!(n_face, 17, "face cell should have 17 neighbors");
        let (_, n_face_b) = g.neighbors(2, 4, 2);
        assert_eq!(n_face_b, 17, "opposite-face cell should also have 17");

        // Face-edge (two coords on boundary, one interior): 11 = 2·2·3 − 1
        let (_, n_edge) = g.neighbors(0, 0, 2);
        assert_eq!(n_edge, 11, "face-edge cell should have 11 neighbors");

        // Corner (all three on boundary): 7 = 2³ − 1
        let (_, n_corner) = g.neighbors(0, 0, 0);
        assert_eq!(n_corner, 7, "corner cell should have 7 neighbors");
        let (_, n_corner_b) = g.neighbors(4, 4, 4);
        assert_eq!(n_corner_b, 7, "opposite corner should also have 7");
    }

    /// Neighbor positions are always within bounds and never include the
    /// cell itself. Catches an off-by-one that would include or skip the
    /// center.
    #[test]
    fn neighbors_are_valid_and_exclude_self() {
        let g = TumorGrid3D::generate(5, 5, 5, 20.0, 42);
        let (neighbors, count) = g.neighbors(2, 2, 2);
        for &(nr, nc, nl) in &neighbors[..count] {
            assert!(nr < g.rows && nc < g.cols && nl < g.layers);
            assert!(
                !(nr == 2 && nc == 2 && nl == 2),
                "neighbors must not include self"
            );
        }
    }

    /// `diffuse_iron` distributes to all valid neighbors of a newly-dead
    /// interior cell. Picks a cell guaranteed to be tumor (center) so
    /// neighbors are tumor too.
    #[test]
    fn diffuse_iron_distributes_to_all_26_interior_neighbors() {
        let mut g = TumorGrid3D::generate(10, 10, 10, 20.0, 42);

        // Pick an interior cell. Sphere center may or may not be alive;
        // either way, mark a known interior position as newly-dead and
        // verify diffusion fans out to all 26 neighbors that aren't
        // already-dead.
        let (r, c, l) = (5, 5, 5);
        g.get_mut(r, c, l).newly_dead = true;
        // Ensure no neighbors are already-dead before the call.
        let (positions, count) = g.neighbors(r, c, l);
        for &(nr, nc, nl) in &positions[..count] {
            g.get_mut(nr, nc, nl).state.dead = false;
            g.get_mut(nr, nc, nl).extra_iron = 0.0;
        }
        assert_eq!(count, 26, "interior cell must have 26 neighbors");

        let iron_per_death = 2.0;
        let neighbor_fraction = 0.0308; // 3D-natural fraction per docstring
        let expected = iron_per_death * neighbor_fraction;
        g.diffuse_iron(iron_per_death, neighbor_fraction);

        for &(nr, nc, nl) in &positions[..count] {
            // Assert the *magnitude* — not just presence — so a bug that
            // applied neighbor_fraction twice or swapped iron_per_death
            // for a constant is caught. IEEE-exact: only one multiply, no
            // libm-dependent ops, so strict equality is safe.
            assert_eq!(
                g.get(nr, nc, nl).extra_iron,
                expected,
                "neighbor ({nr},{nc},{nl}) extra_iron should equal iron_per_death × neighbor_fraction"
            );
        }
        assert!(
            !g.get(r, c, l).newly_dead,
            "newly_dead flag should be cleared after diffusion"
        );
    }

    /// Generate is deterministic from seed: same seed → same per-cell
    /// assignment (not just same aggregate census).
    ///
    /// The original version only compared `census()` counts, which would
    /// pass even if phenotype assignments were permuted across the cells
    /// vec (e.g. a bug that swapped the order of cluster checks but kept
    /// the same totals). This stronger version walks every cell and
    /// compares `(phenotype, is_tumor)` pairwise — a true bit-level
    /// determinism check on `generate`'s output.
    #[test]
    fn generate_is_deterministic() {
        let g1 = TumorGrid3D::generate(20, 20, 20, 20.0, 42);
        let g2 = TumorGrid3D::generate(20, 20, 20, 20.0, 42);

        assert_eq!(g1.cells.len(), g2.cells.len());
        for (i, (a, b)) in g1.cells.iter().zip(g2.cells.iter()).enumerate() {
            assert_eq!(
                a.phenotype, b.phenotype,
                "phenotype divergence at flat index {i}"
            );
            assert_eq!(
                a.is_tumor, b.is_tumor,
                "is_tumor divergence at flat index {i}"
            );
        }
    }

    /// Spherical tumor: census has both tumor and stromal cells, and
    /// the center of a sufficiently large grid is tumor while a corner
    /// is stromal.
    #[test]
    fn spherical_geometry_sanity() {
        let g = TumorGrid3D::generate(20, 20, 20, 20.0, 42);
        let census = g.census();
        assert!(census.total_tumor > 0, "should have some tumor cells");
        assert!(census.stromal > 0, "should have some stromal cells");
        // Total = volume of grid
        assert_eq!(census.total_tumor + census.stromal, 20 * 20 * 20);
        // Center cell is inside the tumor sphere (tumor_radius = 20*0.45 = 9.0)
        assert!(g.get(10, 10, 10).is_tumor, "center cell should be tumor");
        // Corner is well outside (distance from center ≈ 17.3 > 9.0)
        assert!(!g.get(0, 0, 0).is_tumor, "corner cell should be stromal");
    }

    /// `diffuse_iron` correctly handles a corner cell (count=7, not 26).
    /// Catches a hypothetical "iterate `&neighbors[..26]` unconditionally"
    /// bug — the interior test alone wouldn't notice that, since at
    /// interior cells count *is* 26. We override `is_tumor` on the corner
    /// and its 7 neighbors so the diffusion path isn't gated by phenotype.
    #[test]
    fn diffuse_iron_distributes_to_only_7_corner_neighbors() {
        let mut g = TumorGrid3D::generate(10, 10, 10, 20.0, 42);

        let (r, c, l) = (0, 0, 0); // grid corner
                                   // Force the corner to be a fresh tumor cell that just died.
        let gc = g.get_mut(r, c, l);
        gc.is_tumor = true;
        gc.state.dead = true;
        gc.newly_dead = true;
        gc.extra_iron = 0.0;

        // Record neighbor identity + force them to be alive tumor.
        let (positions, count) = g.neighbors(r, c, l);
        assert_eq!(count, 7, "corner should have 7 neighbors");
        for &(nr, nc, nl) in &positions[..count] {
            let nb = g.get_mut(nr, nc, nl);
            nb.is_tumor = true;
            nb.state.dead = false;
            nb.extra_iron = 0.0;
        }

        let iron_per_death = 2.0;
        let neighbor_fraction = 0.0308;
        let expected = iron_per_death * neighbor_fraction;
        g.diffuse_iron(iron_per_death, neighbor_fraction);

        // All 7 valid neighbors received exactly the right magnitude
        // (catches a "iterate ..26 unconditionally" bug — out-of-bounds
        // would panic — AND a "wrong multiplier" bug).
        for &(nr, nc, nl) in &positions[..count] {
            assert_eq!(
                g.get(nr, nc, nl).extra_iron,
                expected,
                "corner neighbor ({nr},{nc},{nl}) extra_iron should equal expected"
            );
        }
        assert!(!g.get(r, c, l).newly_dead, "newly_dead should be cleared");
    }

    /// `layers = 1` collapses TumorGrid3D to a single-slab grid: index
    /// math becomes `r * cols + c` (same as 2D), and neighbor counts
    /// fall back to 8-Moore in the (r,c) plane since dl ∈ {0} only.
    /// Locks down the useful "TumorGrid3D-as-2D-fallback" emergent
    /// property — anything that breaks this is a regression in the
    /// general index/neighbor formulas.
    #[test]
    fn layers_eq_1_degenerates_to_2d() {
        let g = TumorGrid3D::generate(5, 5, 1, 20.0, 42);

        // Index math: r * 5 * 1 + c * 1 + 0 == r * 5 + c
        for r in 0..5 {
            for c in 0..5 {
                let flat = r * g.cols * g.layers + c * g.layers;
                assert_eq!(flat, r * 5 + c, "layers=1 index should collapse to 2D");
            }
        }

        // Interior cell at (2, 2, 0): 8 neighbors (Moore in (r,c) plane;
        // dl ∈ {0} only since layers=1).
        let (_, n_interior) = g.neighbors(2, 2, 0);
        assert_eq!(
            n_interior, 8,
            "interior cell with layers=1 should have 8 Moore neighbors (2D fallback)"
        );

        // Corner at (0, 0, 0): 3 neighbors ({0,1}×{0,1} - self = 3).
        let (_, n_corner) = g.neighbors(0, 0, 0);
        assert_eq!(
            n_corner, 3,
            "corner with layers=1 should have 3 neighbors (2D-corner fallback)"
        );

        // Edge at (0, 2, 0): 5 neighbors ({0,1}×{1,2,3} - self = 5).
        let (_, n_edge) = g.neighbors(0, 2, 0);
        assert_eq!(
            n_edge, 5,
            "edge with layers=1 should have 5 neighbors (2D-edge fallback)"
        );
    }

    /// Census on a fresh grid has no dead cells.
    #[test]
    fn fresh_grid_has_no_dead_cells() {
        let g = TumorGrid3D::generate(10, 10, 10, 20.0, 42);
        let census = g.census();
        assert_eq!(census.total_dead, 0);
        assert_eq!(census.glycolytic_dead, 0);
        assert_eq!(census.oxphos_dead, 0);
        assert_eq!(census.persister_dead, 0);
        assert_eq!(census.persister_nrf2_dead, 0);
    }

    /// Radial depth at the geometric center equals tumor_radius × cell_size.
    /// For a 20×20×20 grid the center is at (10,10,10) and the cell at
    /// (10,10,10) lies offset by exactly (0,0,0) from the center, so depth
    /// is `tumor_radius_lattice × cell_size_um = (20·0.45) × 20`.
    ///
    /// `0.45` is *not* exact in IEEE 754 (its binary expansion is
    /// repeating), but the f64 round-to-nearest result of `20.0 × 0.45`
    /// happens to land on exactly `9.0` (the rounding error in `0.45`'s
    /// nearest-double is well under half-ULP at 9.0), so the assertion
    /// `(20·0.45) × 20 == 9.0 × 20.0 = 180.0` holds bit-exact. Strict
    /// equality is safe here because of that rounding-friendly arithmetic,
    /// not because it's provably exact rationally.
    #[test]
    fn radial_depth_at_center_is_max() {
        let g = TumorGrid3D::generate(20, 20, 20, 20.0, 42);
        // center coord is rows/2 = 10.0; cell (10,10,10) has dr=dc=dl=0
        // (since 10 - 10.0 = 0 exactly in f64).
        assert_eq!(g.radial_depth_um(10, 10, 10), 9.0 * 20.0);
    }

    /// Cells well outside the spheroid (grid corners) return negative depth.
    /// For a 20×20×20 grid with cell_size=20, the corner (0,0,0) is at
    /// distance sqrt(3·10²) ≈ 17.32 lattice units from center; tumor
    /// radius is 9.0 lattice units, so depth ≈ (9.0 - 17.32) × 20 ≈ -166 µm.
    #[test]
    fn radial_depth_outside_sphere_is_negative() {
        let g = TumorGrid3D::generate(20, 20, 20, 20.0, 42);
        let depth = g.radial_depth_um(0, 0, 0);
        assert!(
            depth < 0.0,
            "corner cell should have negative radial depth, got {depth}"
        );
        // Sanity-bound the magnitude. Hand-derived: dist = sqrt(300), depth =
        // (9 - sqrt(300)) * 20 ≈ -166.4 µm.
        let expected = (9.0 - 300.0_f64.sqrt()) * 20.0;
        assert!(
            (depth - expected).abs() < 1e-9,
            "depth = {depth}, expected {expected}"
        );
    }

    /// Anisotropic grid: tumor radius is set by the *smallest* dimension,
    /// so a (20, 20, 5) grid has `tumor_radius = 5·0.45 = 2.25` lattice
    /// units. Verifies the radial geometry doesn't accidentally use the
    /// wrong dimension (e.g. rows when it should be min).
    #[test]
    fn radial_depth_anisotropic_grid() {
        let g = TumorGrid3D::generate(20, 20, 5, 10.0, 42);
        // Center of layer axis is layers/2 = 2.5, so cell at l=2 is 0.5
        // off-center in the l direction. (10, 10, 2): dr=0, dc=0, dl=-0.5,
        // dist=0.5, depth = (2.25 - 0.5) * 10 = 17.5 µm.
        let depth = g.radial_depth_um(10, 10, 2);
        assert_eq!(depth, (2.25 - 0.5) * 10.0);
        // Far corner is outside the (very small) sphere.
        let corner = g.radial_depth_um(0, 0, 0);
        assert!(
            corner < 0.0,
            "corner should be outside spheroid, got {corner}"
        );
    }

    /// Determinism check: same grid, same indices, same depth. Cheap
    /// regression guard for any future refactor that introduces RNG or
    /// caching into the depth path.
    #[test]
    fn radial_depth_is_deterministic() {
        let g1 = TumorGrid3D::generate(10, 10, 10, 20.0, 42);
        let g2 = TumorGrid3D::generate(10, 10, 10, 20.0, 42);
        for &(r, c, l) in &[(0, 0, 0), (5, 5, 5), (9, 9, 9), (3, 7, 2)] {
            assert_eq!(g1.radial_depth_um(r, c, l), g2.radial_depth_um(r, c, l));
        }
    }

    /// A cell sitting exactly on the spheroid boundary returns depth = 0.
    /// Defends the sign-convention contract: `depth = 0` at the surface,
    /// positive inside, negative outside.
    ///
    /// For a `(20, 20, 20)` grid: center = (10, 10, 10), tumor_radius
    /// = 20 × TUMOR_RADIUS_FRACTION. As noted in
    /// `radial_depth_at_center_is_max`, `0.45` is not exact in IEEE 754
    /// but `20.0 × 0.45` rounds to exactly `9.0`. Cell (10, 10, 19) is
    /// 9.0 lattice units offset from center along the `l` axis;
    /// `sqrt(81.0) = 9.0` is IEEE-required-correct (perfect square →
    /// exact result), so `tumor_radius - dist = 9.0 - 9.0 = 0.0` exactly
    /// and `0.0 × cell_size = 0.0` exactly. The assertion is bit-exact
    /// because of these rounding-friendly inputs, not provable
    /// rationally.
    #[test]
    fn radial_depth_at_sphere_surface_is_zero() {
        let g = TumorGrid3D::generate(20, 20, 20, 20.0, 42);
        let on_surface = g.radial_depth_um(10, 10, 19);
        assert_eq!(on_surface, 0.0);
    }

    /// Guards against silent geometry drift: the generated tumor and the
    /// reference sphere used by `radial_depth_um` must use the same radius.
    /// If a future refactor changed one side without the other (e.g. tweaks
    /// `generate` to use a different fraction inline), this test catches it.
    ///
    /// Walks every cell in a small grid and asserts:
    /// - `is_tumor == true`  →  `radial_depth_um >= 0` (cell is at or
    ///   inside the depth-reference sphere)
    /// - `is_tumor == false` →  `radial_depth_um < 0`  (cell is outside)
    ///
    /// Holds exactly *because* both code paths reference
    /// `TUMOR_RADIUS_FRACTION` — the test breaks the moment they diverge.
    #[test]
    fn radial_depth_sign_agrees_with_generated_is_tumor() {
        let g = TumorGrid3D::generate(10, 10, 10, 20.0, 42);
        for r in 0..g.rows {
            for c in 0..g.cols {
                for l in 0..g.layers {
                    let depth = g.radial_depth_um(r, c, l);
                    let is_tumor = g.get(r, c, l).is_tumor;
                    if is_tumor {
                        assert!(
                            depth >= 0.0,
                            "tumor cell ({r},{c},{l}) has negative depth {depth}; \
                             generate/radial_depth_um drifted"
                        );
                    } else {
                        assert!(
                            depth < 0.0,
                            "stromal cell ({r},{c},{l}) has non-negative depth {depth}; \
                             generate/radial_depth_um drifted"
                        );
                    }
                }
            }
        }
    }

    // ============================================================
    // 2D radial_depth_um (TumorGrid). Mirrors the 3D coverage above so
    // a refactor that diverges the 2D and 3D depth functions is caught
    // here. Lifted from sim-tme's binary-local `compute_depth_map` and
    // the inline copies in oxygen/ph cross-geometry tests (#224 item 1a).
    // ============================================================

    /// 2D analog of `radial_depth_at_center_is_max`. For a (20, 20) disc,
    /// `tumor_radius = 20 × 0.45 = 9.0` lattice units. Cell (10, 10) is
    /// at distance 0 from center, so `depth = 9.0 × cell_size`.
    #[test]
    fn radial_depth_2d_at_center_is_max() {
        let g = TumorGrid::generate(20, 20, 20.0, 42);
        let depth = g.radial_depth_um(10, 10);
        assert_eq!(depth, 9.0 * 20.0);
    }

    /// Sign convention: depth is signed, with corners of the bounding
    /// box outside the disc producing a negative value. Mirrors
    /// `radial_depth_outside_sphere_is_negative` for 3D.
    #[test]
    fn radial_depth_2d_outside_disc_is_negative() {
        let g = TumorGrid::generate(20, 20, 20.0, 42);
        let corner = g.radial_depth_um(0, 0);
        assert!(corner < 0.0, "corner should be outside disc, got {corner}");
    }

    /// 2D version of the `is_tumor` / sign agreement guard: every tumor
    /// cell must have non-negative depth, every non-tumor cell must
    /// have negative depth. Catches drift between `TumorGrid::generate`
    /// and `radial_depth_um` (both reference `TUMOR_RADIUS_FRACTION`).
    #[test]
    fn radial_depth_2d_sign_agrees_with_generated_is_tumor() {
        let g = TumorGrid::generate(40, 40, 20.0, 42);
        for r in 0..g.rows {
            for c in 0..g.cols {
                let depth = g.radial_depth_um(r, c);
                let is_tumor = g.get(r, c).is_tumor;
                if is_tumor {
                    assert!(
                        depth >= 0.0,
                        "tumor cell ({r},{c}) has negative depth {depth}; \
                         generate/radial_depth_um drifted"
                    );
                } else {
                    assert!(
                        depth < 0.0,
                        "stromal cell ({r},{c}) has non-negative depth {depth}; \
                         generate/radial_depth_um drifted"
                    );
                }
            }
        }
    }

    /// Bit-identical to sim-tme's binary-local `compute_depth_map` math
    /// after `.max(0.0)` clamp + non-tumor zero. Locks the lift so a
    /// future refactor of either side can't diverge silently.
    #[test]
    fn radial_depth_2d_matches_sim_tme_compute_depth_map_formula() {
        let g = TumorGrid::generate(40, 40, 20.0, 42);
        let center_r = g.rows as f64 / 2.0;
        let center_c = g.cols as f64 / 2.0;
        let tumor_radius = (g.rows.min(g.cols) as f64) * TUMOR_RADIUS_FRACTION;
        for r in 0..g.rows {
            for c in 0..g.cols {
                let dr = r as f64 - center_r;
                let dc = c as f64 - center_c;
                let dist = (dr * dr + dc * dc).sqrt();
                let expected = (tumor_radius - dist) * g.cell_size_um;
                assert_eq!(g.radial_depth_um(r, c), expected);
            }
        }
    }

    #[test]
    fn coords_3d_roundtrips_with_flat_index() {
        // Non-cubic dims to catch axis-order bugs (rows≠cols≠layers).
        let g = TumorGrid3D::generate(7, 5, 9, 20.0, 42);
        for idx in 0..g.cells.len() {
            let (r, c, l) = g.coords(idx);
            assert!(r < g.rows && c < g.cols && l < g.layers);
            assert_eq!(
                g.flat_index(r, c, l),
                idx,
                "coords/flat_index must be inverses"
            );
        }
    }
}
