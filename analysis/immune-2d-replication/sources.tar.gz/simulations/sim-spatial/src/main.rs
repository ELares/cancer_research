//! Spatial Tumor Simulation with Energy Physics
//!
//! Validates the paper's core claims:
//! 1. "Physical modalities restrict ROS to a defined tumor volume"
//! 2. "Ultrasound penetrates centimeters; light penetrates millimeters"
//!
//! Simulates a 2D heterogeneous tumor with depth-dependent energy deposition
//! from PDT (Beer-Lambert), SDT (acoustic attenuation), and RSL3 (uniform).

use std::path::PathBuf;

use clap::Parser;
use rand::prelude::*;

use ferroptosis_core::biochem::{sim_cell_step, CellState};
use ferroptosis_core::cell::{norm, Treatment};
use ferroptosis_core::grid::{death_heatmap, depth_kill_curve, TumorGrid};
use ferroptosis_core::io::{write_depth_curves_csv, write_heatmap_csv, write_json};
use ferroptosis_core::params::{Params, RadiationConfig, SpatialParams};
use ferroptosis_core::photosensitizer_pk::{validate_dli_h, Photosensitizer};
use ferroptosis_core::physics::local_ros_multiplier;
use ferroptosis_core::radiation;

#[derive(Parser)]
#[command(name = "sim-spatial", about = "Spatial tumor ferroptosis simulation")]
struct Args {
    /// Grid size (rows = cols).
    #[arg(long, default_value_t = 500)]
    grid_size: usize,

    /// Cell size in micrometers.
    #[arg(long, default_value_t = 20.0)]
    cell_size: f64,

    /// Random seed.
    #[arg(long, default_value_t = 42)]
    seed: u64,

    /// Output directory.
    /// Radiation dose in Gy for the `Radiation` arm (#726). `0` disables the
    /// arm entirely and reproduces this binary's pre-radiation output
    /// byte-for-byte. The default 2.0 Gy is the conventional single
    /// fraction, and the one PMID 32307022's SF2 is quoted at.
    #[arg(long, default_value_t = 2.0)]
    radiation_dose_gy: f64,

    /// Exogenous-ROS peak produced per effective gray. UNCALIBRATED -- the
    /// radiation-ferroptosis literature gives a direction and no conversion
    /// (see `CALIBRATION_STATUS.md`). Default 0 keeps the ferroptosis channel
    /// OFF, so the depth curve shows the DNA channel alone unless asked.
    #[arg(long, default_value_t = 0.0)]
    radiation_ros_per_gy: f64,

    #[arg(long, default_value = "output/spatial")]
    output_dir: PathBuf,

    /// Number of biochemistry timesteps per cell.
    #[arg(long, default_value_t = 180)]
    n_steps: u32,

    /// Photosensitizer PK model for PDT light scaling. Spec format
    /// (case-insensitive):
    ///
    ///   uniform[=N]                    constant fraction (default 1)
    ///   porfimer[=t_half[,t_dist[,phi]]]  single-exponential decay
    ///                                  with saturating distribution phase
    ///                                  and relative singlet-O₂ yield
    ///
    /// Porfimer defaults: t_half=504 h (Bellnier 2006), t_dist=0 h
    /// (legacy "light at peak"; set ~24–48 h to model porfimer absorption
    /// rise), phi=1.0 (porfimer-equivalent yield baseline). Examples:
    ///
    ///   --photosensitizer porfimer=504           t_half only (legacy)
    ///   --photosensitizer porfimer=504,36        t_half + t_dist
    ///   --photosensitizer porfimer=504,0,0.5     t_half + phi (half-yield via 3-positional)
    ///   --photosensitizer porfimer=504,0,0.65    porfimer absolute phi (≈ tissue baseline)
    ///   --photosensitizer "uniform=2"            enrichment hook (>1)
    ///
    /// Values >1.0 for `uniform` and `phi` are intentionally permitted
    /// (enrichment / sensitizer-engineered variants). Parsed via
    /// `Photosensitizer`'s `FromStr` impl, so clap validates at flag-
    /// parse time and reports errors via clap's standard formatter.
    #[arg(long, default_value_t = Photosensitizer::default())]
    photosensitizer: Photosensitizer,

    /// Drug-light interval in hours: time to light delivery. With the
    /// default `Porfimer.t_distribution_h = 0` (legacy "light at peak"),
    /// this is interpreted as time from post-distribution peak. With
    /// `t_distribution_h > 0`, the model holds drug at peak for the
    /// first `t_distribution_h` hours and then begins decay — so this
    /// flag can be the clinical DLI from injection. Validated as finite
    /// and ≥ 0.
    #[arg(long, default_value_t = 0.0)]
    dli_h: f64,
}

fn run_spatial(
    grid: &mut TumorGrid,
    tx: Treatment,
    params: &Params,
    spatial_params: &SpatialParams,
    rad: &RadiationConfig,
    n_steps: u32,
    seed: u64,
) {
    let base_ros = match tx {
        Treatment::SDT => params.sdt_ros,
        Treatment::PDT => params.pdt_ros,
        Treatment::RSL3 | Treatment::Control => 0.0,
        // Radiation's exogenous ROS is dose-driven, so the "base" here is the
        // ferroptosis channel's yield at full dose; the depth term arrives
        // through `local_ros_multiplier` exactly as it does for SDT and PDT.
        Treatment::Radiation => rad.ros_per_gy * rad.dose_gy,
        // Not wired into this binary. `sim-modality-panel` runs these arms;
        // stated explicitly rather than as a `_ =>` catch-all, which would
        // absorb every future variant too.
        Treatment::Chemotherapy
        | Treatment::Immunotherapy
        | Treatment::AdoptiveCell
        | Treatment::OncolyticVirus
        | Treatment::Ablation
        | Treatment::AntibodyDrugConjugate => 0.0,
    };

    let rows = grid.rows;
    let cols = grid.cols;
    let cell_size = grid.cell_size_um;

    // Initialize cell states with depth-dependent ROS
    for r in 0..rows {
        let ros_multiplier = local_ros_multiplier(r, cell_size, tx, spatial_params);
        for c in 0..cols {
            let exo_ros_peak = if tx == Treatment::Control || tx == Treatment::RSL3 {
                0.0
            } else {
                let mut rng = StdRng::seed_from_u64(seed.wrapping_add((r * cols + c) as u64));
                let peak = base_ros * ros_multiplier;
                norm(&mut rng, peak, peak * 0.2).max(0.0)
            };

            let gc = grid.get_mut(r, c);
            gc.state = CellState::from_cell_with_ros(&gc.cell, tx, params, exo_ros_peak);
            // RADIATION'S SECOND CHANNEL, and the reason this is not just
            // another exogenous-ROS arm. The dominant lethal lesion is the DNA
            // double-strand break, which does not pass through `CellState` at
            // all: it is a one-shot survival roll against the linear-quadratic
            // model at the dose this cell actually receives. Depth enters
            // through `intensity_at_depth`; oxygen through the same OER the
            // SDT path uses. `dose_gy = 0` leaves the roll untaken, so a
            // default config is byte-identical.
            if tx == Treatment::Radiation && rad.dose_gy > 0.0 {
                let z_um = r as f64 * cell_size;
                // 2D spatial model has no O2 field; full supply is the
                // documented assumption here, matching the other arms.
                let lethality = radiation::dna_lethality(rad, 1.0, z_um);
                let mut rng =
                    StdRng::seed_from_u64(seed.wrapping_add(0x5AD_u64 + (r * cols + c) as u64));
                if rng.gen::<f64>() < lethality {
                    gc.state.dead = true;
                    gc.state.death_step = Some(0);
                }
            }
            gc.extra_iron = 0.0;
            gc.newly_dead = false;
            gc.lp_at_grace_end = 0.0;
        }
    }

    // Run simulation: 180 timesteps with interleaved diffusion
    for step in 0..n_steps {
        // Biochemistry step for each cell
        for r in 0..rows {
            for c in 0..cols {
                let idx = r * cols + c;
                if !grid.cells[idx].is_tumor {
                    continue;
                }
                if grid.cells[idx].state.dead {
                    if let Some(ds) = grid.cells[idx].state.death_step {
                        if step >= ds + params.post_death_steps {
                            continue;
                        }
                    } else {
                        continue;
                    }
                }

                // Seed incorporates a large offset to avoid collision with init seeds
                let mut rng = StdRng::seed_from_u64(
                    seed.wrapping_add(500_000)
                        .wrapping_add(idx as u64)
                        .wrapping_add(step as u64 * 1_000_000),
                );

                // Consume extra_iron this step, then reset (iron is consumed by Fenton reaction)
                let extra_iron = grid.cells[idx].extra_iron;
                grid.cells[idx].extra_iron = 0.0;

                let gc = &mut grid.cells[idx];
                let died =
                    sim_cell_step(&mut gc.state, &gc.cell, params, step, extra_iron, &mut rng);

                if died {
                    gc.newly_dead = true;
                    gc.lp_at_grace_end = gc.state.lp;
                }
                // Update lp_at_grace_end during grace period
                if gc.state.dead {
                    gc.lp_at_grace_end = gc.state.lp;
                }
            }
        }

        // Diffusion step: distribute iron from newly dead cells
        grid.diffuse_iron(
            spatial_params.iron_release_per_death,
            spatial_params.neighbor_iron_fraction,
        );

        // Progress reporting every 30 steps
        if (step + 1) % 30 == 0 {
            let census = grid.census();
            eprintln!(
                "  Step {}/{}: {}/{} tumor cells dead ({:.1}%)",
                step + 1,
                n_steps,
                census.total_dead,
                census.total_tumor,
                if census.total_tumor > 0 {
                    census.total_dead as f64 / census.total_tumor as f64 * 100.0
                } else {
                    0.0
                }
            );
        }
    }
}

fn main() {
    let args = Args::parse();

    // #585 seed-aliasing guard. The per-cell RNG seed is the additive
    // `seed + offset + idx + step*1e6` scheme (plus the init stream `seed + idx`);
    // its first aliasing onset is the init stream colliding with the biochem
    // step-0 stream once `idx` reaches 500_000 — i.e. `n_cells = grid_size² >
    // 500_000` (grid_size > 707). Unlike sim-tme's compile-time const, `grid_size`
    // is a CLI argument, so a user can drive it into the aliasing regime; warn
    // loudly rather than silently produce per-cell draws that repeat across steps.
    // The real fix (the sim-tme-3d SplitMix64 hash mix, #578) is tracked in #585.
    if (args.grid_size as u64) * (args.grid_size as u64) >= 500_000 {
        eprintln!(
            "WARNING (#585): grid_size={} → {} cells (> 500k seed-collision-free max); \
             the per-cell additive RNG seed streams alias, so per-cell stochastic draws \
             repeat across steps. Determinism holds, but do NOT trust large-grid \
             stochastic output until the SplitMix64 seed (#578) is ported.",
            args.grid_size,
            (args.grid_size as u64) * (args.grid_size as u64),
        );
    }

    // `--photosensitizer` is parsed and validated by clap via the
    // `Photosensitizer` `FromStr` impl, so by the time we reach here
    // `args.photosensitizer` is a valid enum value. Only `--dli-h`
    // (an `f64`) needs explicit validation — clap accepts NaN/inf/neg.
    if let Err(e) = validate_dli_h(args.dli_h) {
        eprintln!("error: --dli-h: {e}");
        std::process::exit(2);
    }

    eprintln!("=== Spatial Tumor Ferroptosis Simulation ===");
    eprintln!(
        "Grid: {}×{} cells ({:.1}mm × {:.1}mm tissue)",
        args.grid_size,
        args.grid_size,
        args.grid_size as f64 * args.cell_size / 1000.0,
        args.grid_size as f64 * args.cell_size / 1000.0,
    );
    eprintln!("Cell size: {} µm", args.cell_size);
    eprintln!("Seed: {}", args.seed);
    eprintln!(
        "Photosensitizer: {}, DLI: {} h\n",
        args.photosensitizer, args.dli_h
    );

    let params = Params::default();
    let spatial_params = SpatialParams {
        cell_size_um: args.cell_size,
        photosensitizer: args.photosensitizer,
        t_drug_light_interval_h: args.dli_h,
        ..Default::default()
    };

    // The linear-quadratic parameters are the published GBM parameterisation
    // (PMID 32307022) that `radiation.rs` round-trips: alpha from SF2 = 0.5445
    // at alpha/beta = 10.
    let rad = RadiationConfig {
        dose_gy: args.radiation_dose_gy,
        alpha_per_gy: radiation::ALPHA_GBM_PARAMETERISATION_PER_GY,
        beta_per_gy2: radiation::ALPHA_GBM_PARAMETERISATION_PER_GY
            / radiation::ALPHA_BETA_TUMOUR_GY,
        ros_per_gy: args.radiation_ros_per_gy,
        ..RadiationConfig::default()
    };

    let mut treatments: Vec<(Treatment, &str)> = vec![
        (Treatment::Control, "Control"),
        (Treatment::RSL3, "RSL3"),
        (Treatment::SDT, "SDT"),
        (Treatment::PDT, "PDT"),
    ];
    // Appended rather than inserted, and only when a dose is set: at
    // `--radiation-dose-gy 0` this binary's output is byte-for-byte what it
    // was before radiation existed, and the four existing curves keep their
    // order and their RNG stream either way.
    if args.radiation_dose_gy > 0.0 {
        treatments.push((Treatment::Radiation, "Radiation"));
    }

    // Create output directory
    std::fs::create_dir_all(&args.output_dir).expect("Failed to create output directory");

    let mut all_depth_curves = Vec::new();
    let mut all_summaries = Vec::new();

    for (tx, tx_name) in &treatments {
        eprintln!("--- Treatment: {} ---", tx_name);

        // Generate fresh grid for each treatment (same seed = same tumor)
        let mut grid =
            TumorGrid::generate(args.grid_size, args.grid_size, args.cell_size, args.seed);

        let census_before = grid.census();
        eprintln!(
            "  Tumor composition: {} glycolytic, {} OXPHOS, {} persister, {} persister+NRF2, {} stromal",
            census_before.glycolytic,
            census_before.oxphos,
            census_before.persister,
            census_before.persister_nrf2,
            census_before.stromal,
        );

        // Run spatial simulation
        run_spatial(
            &mut grid,
            *tx,
            &params,
            &spatial_params,
            &rad,
            args.n_steps,
            args.seed.wrapping_add((*tx as u64) * 10_000_000),
        );

        let census_after = grid.census();
        eprintln!(
            "  Final: {}/{} dead ({:.1}%)",
            census_after.total_dead,
            census_after.total_tumor,
            if census_after.total_tumor > 0 {
                census_after.total_dead as f64 / census_after.total_tumor as f64 * 100.0
            } else {
                0.0
            }
        );
        eprintln!(
            "    Glycolytic: {}/{} dead, OXPHOS: {}/{} dead, Persister: {}/{} dead, NRF2: {}/{} dead",
            census_after.glycolytic_dead, census_after.glycolytic,
            census_after.oxphos_dead, census_after.oxphos,
            census_after.persister_dead, census_after.persister,
            census_after.persister_nrf2_dead, census_after.persister_nrf2,
        );
        eprintln!();

        // Save death heatmap
        let heatmap = death_heatmap(&grid);
        let heatmap_path = args
            .output_dir
            .join(format!("spatial_death_{}.csv", tx_name.to_lowercase()));
        write_heatmap_csv(&heatmap_path, &heatmap).expect("Failed to write heatmap");

        // Compute depth-kill curve
        let curve = depth_kill_curve(&grid);
        all_depth_curves.push((tx_name.to_string(), curve));

        // Summary
        all_summaries.push(serde_json::json!({
            "treatment": tx_name,
            "total_tumor": census_after.total_tumor,
            "total_dead": census_after.total_dead,
            "overall_death_rate": census_after.total_dead as f64 / census_after.total_tumor.max(1) as f64,
            "glycolytic": { "total": census_after.glycolytic, "dead": census_after.glycolytic_dead },
            "oxphos": { "total": census_after.oxphos, "dead": census_after.oxphos_dead },
            "persister": { "total": census_after.persister, "dead": census_after.persister_dead },
            "persister_nrf2": { "total": census_after.persister_nrf2, "dead": census_after.persister_nrf2_dead },
        }));
    }

    // Save depth-kill curves (all treatments in one CSV)
    let curves_path = args.output_dir.join("depth_kill_curves.csv");
    write_depth_curves_csv(&curves_path, &all_depth_curves).expect("Failed to write depth curves");

    // Save summary JSON
    let summary_path = args.output_dir.join("spatial_summary.json");
    write_json(&summary_path, &all_summaries).expect("Failed to write summary");

    eprintln!("=== Output saved to {} ===", args.output_dir.display());
    eprintln!("  depth_kill_curves.csv — death rate by depth for all treatments");
    eprintln!("  spatial_death_{{treatment}}.csv — 2D death heatmaps");
    eprintln!("  spatial_summary.json — aggregate statistics");
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Spec / DLI parsers and their edge-case rejection logic live in
    /// `ferroptosis_core::photosensitizer_pk`; their unit tests live with
    /// them. The remaining test here covers the only binary-specific
    /// concern: that clap's `default_value_t` attributes still map to
    /// `SpatialParams::default()`. Without this, the parser-level
    /// invariant could pass while the clap defaults silently drifted.
    #[test]
    fn default_args_match_default_spatial_params() {
        let args = Args::parse_from(["sim-spatial"]);
        let default_sp = SpatialParams::default();
        assert_eq!(args.photosensitizer, default_sp.photosensitizer);
        assert_eq!(args.dli_h, default_sp.t_drug_light_interval_h);
    }
}
